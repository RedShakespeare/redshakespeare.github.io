void dndstore (void);

void oschool (void);

void obank (void);
void obank2 (void);

void ointerest (void);

void otradepost (void);

void olrs (void);

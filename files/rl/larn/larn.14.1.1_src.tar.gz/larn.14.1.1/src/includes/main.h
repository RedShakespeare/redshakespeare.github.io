void parse2 (void);

int readnum (int);

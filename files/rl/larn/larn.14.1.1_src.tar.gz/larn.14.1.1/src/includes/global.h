void raiselevel (void);

void loselevel (void);

void raiseexperience (long);

void loseexperience (long);

void losehp (int);

void losemhp (int);

void raisehp (int);

void raisemhp (int);

void raisemspells (int);

void losemspells (int);

int makemonst (int);

void positionplayer (void);

void recalc (void);

void quit (void);

int more (char);

void enchantarmor (void);

void enchweapon (void);

int nearbymonst (void);

int stealsomething (void);

int emptyhanded (void);

void creategem (void);

void adjustcvalues (int, int);

int getpassword (void);

char getyn (void);

int packweight (void);

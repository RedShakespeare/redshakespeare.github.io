void movemonst (void);

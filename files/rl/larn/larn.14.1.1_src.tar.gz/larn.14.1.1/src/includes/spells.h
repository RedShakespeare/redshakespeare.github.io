void cast (void);

int fullhit (int);

void godirect (int, int, char *, int, char);

void ifblind (int, int);

int dirsub (int *, int *);

void annihilate (void);

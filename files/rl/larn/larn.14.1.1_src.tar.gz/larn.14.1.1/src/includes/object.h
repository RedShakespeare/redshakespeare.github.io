void lookforobject (char, char, char);

void oteleport (int);

void quaffpotion (int, int);

void adjtimel (int);

void read_scroll (int);

void readbook (int);

void ohome (void);

void iopts (void);

void ignore (void);

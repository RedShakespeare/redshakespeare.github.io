void act_remove_gems (int);

void act_sit_throne (int);

void act_up_stairs (void);

void act_down_stairs (void);

void act_drink_fountain (void);

void act_wash_fountain (void);

void act_down_shaft (void);

void act_up_shaft (void);

void act_desecrate_altar (void);

void act_donation_pray (void);

void act_just_pray (void);

void act_ignore_altar (void);

void act_open_chest (int, int);

int act_open_door (int, int);

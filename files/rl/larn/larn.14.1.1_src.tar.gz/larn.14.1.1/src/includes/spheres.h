int newsphere (int, int, int, int);

int rmsphere (int, int);

void movsphere (void);

void readmail (int);

int display_help_text(void);
void welcome(void);
void retcont(void);
void return_to_game(void);

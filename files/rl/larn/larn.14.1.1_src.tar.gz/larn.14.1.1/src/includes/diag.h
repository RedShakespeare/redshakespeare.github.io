#ifdef EXTRA
int diag (void);
void diagdrawscreen (void);
#endif

int savegame (char *);
void restoregame (char *);

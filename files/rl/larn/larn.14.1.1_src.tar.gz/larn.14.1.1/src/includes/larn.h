/* File created by Gibbon.
 *
 * This file is not complete.  It will take time to correctly place
 * required headers here.  It isn't just copy and paste.
 *
*/

/* global includes by all systems */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <setjmp.h>

/* includes of other header files */
#include "larncons.h"
#include "larndata.h"
#include "larnfunc.h"
#include "ansiterm.h"

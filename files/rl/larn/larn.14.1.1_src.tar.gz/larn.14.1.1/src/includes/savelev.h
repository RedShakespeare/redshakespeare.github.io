void savelevel (void);

void getlevel (void);

int yylex (void);
void sethard (int);


void init_inventory (void);

int showstr (char);

int showwear (void);

int showwield (void);

int showread (void);

int showeat (void);

int showquaff (void);

void show1 (int);

int show3 (int);

int take (int, int);

int drop_object (int);

int pocketfull (void);

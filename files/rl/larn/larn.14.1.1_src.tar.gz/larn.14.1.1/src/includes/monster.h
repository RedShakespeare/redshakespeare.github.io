void checkloss (int);

void createitem (int, int);

void createmonster (int);

void dropgold (int);

int hitm (int, int, int);

void hitmonster (int, int);

void hitplayer (int, int);

int newobject (int, int *);

void something (int);

int vxy (int *, int *);

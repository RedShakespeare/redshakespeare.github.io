void oaltar (void);

void othrone (int);

void odeadthrone (void);

void ochest (void);

void ofountain (void);

void fntchange (int);

void drink_fountain (void);

void wash_fountain (void);

void enter (void);

void remove_gems (void);

void sit_on_throne (void);

void up_stairs (void);

void down_stairs (void);

void open_something (void);

void close_something (void);

void desecrate_altar (void);

void pray_at_altar (void);

void specify_object (void);

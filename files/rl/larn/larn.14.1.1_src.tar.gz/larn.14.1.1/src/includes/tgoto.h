const char *atgoto (const char *, int, int);

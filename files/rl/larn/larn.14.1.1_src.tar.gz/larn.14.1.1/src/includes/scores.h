int makeboard (void);

int hashewon (void);

void checkmail (void);

int paytaxes (int);

void showscores (void);

void showallscores (void);

void died (int);

void diedlog (void);

int getplid (char *);

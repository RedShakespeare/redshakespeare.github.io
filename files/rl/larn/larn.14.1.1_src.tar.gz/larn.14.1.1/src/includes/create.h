void makeplayer (void);
void newcavelevel (int);
void eat (int, int);
int fillmonst (int);

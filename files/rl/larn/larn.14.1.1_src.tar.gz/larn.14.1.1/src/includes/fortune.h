void outfortune (void);

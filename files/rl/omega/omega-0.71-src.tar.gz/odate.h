/* omega copyright (C) by Laurence Raphael Brothers, 1987,1988 */
/* odate.h */

#define LAST_OMEGA_EDIT_DATE "Sun Jul 10 22:22:19 EDT 1988"


/*
 * object.h
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  This notice shall not be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */

#define boolean char

#define NOTHING		((unsigned short)     0)
#define OBJECT		((unsigned short)    01)
#define MONSTER		((unsigned short)    02)
#define STAIRS		((unsigned short)    04)
#define HORWALL		((unsigned short)   010)
#define VERTWALL	((unsigned short)   020)
#define DOOR		((unsigned short)   040)
#define FLOOR		((unsigned short)  0100)
#define TUNNEL		((unsigned short)  0200)
#define TRAP		((unsigned short)  0400)
#define HIDDEN		((unsigned short) 01000)

#define ARMOR		((unsigned short)   01)
#define WEAPON		((unsigned short)   02)
#define SCROLL		((unsigned short)   04)
#define POTION		((unsigned short)  010)
#define GOLD		((unsigned short)  020)
#define FOOD		((unsigned short)  040)
#define WAND		((unsigned short) 0100)
#define RING		((unsigned short) 0200)
#define AMULET		((unsigned short) 0400)
#define ALL_OBJECTS	((unsigned short) 0777)

#define LEATHER 0
#define RINGMAIL 1
#define SCALE 2
#define CHAIN 3
#define BANDED 4
#define SPLINT 5
#define PLATE 6
#define ARMORS 7

#define BOW 0
#define DART 1
#define ARROW 2
#define DAGGER 3
#define SHURIKEN 4
#define MACE 5
#define LONG_SWORD 6
#define TWO_HANDED_SWORD 7
#define WEAPONS 8

#define MAX_PACK_COUNT 24

#define PROTECT_ARMOR 0
#define HOLD_MONSTER 1
#define ENCH_WEAPON 2
#define ENCH_ARMOR 3
#define IDENTIFY 4
#define TELEPORT 5
#define SLEEP 6
#define SCARE_MONSTER 7
#define REMOVE_CURSE 8
#define CREATE_MONSTER 9
#define AGGRAVATE_MONSTER 10
#define MAGIC_MAPPING 11
#define SCROLLS 12

#define INCREASE_STRENGTH 0
#define RESTORE_STRENGTH 1
#define HEALING 2
#define EXTRA_HEALING 3
#define POISON 4
#define RAISE_LEVEL 5
#define BLINDNESS 6
#define HALLUCINATION 7
#define DETECT_MONSTER 8
#define DETECT_OBJECTS 9
#define CONFUSION 10
#define LEVITATION 11
#define HASTE_SELF 12
#define SEE_INVISIBLE 13
#define POTIONS 14

#define TELE_AWAY 0
#define SLOW_MONSTER 1
#define CONFUSE_MONSTER 2
#define INVISIBILITY 3
#define POLYMORPH 4
#define HASTE_MONSTER 5
#define PUT_TO_SLEEP 6
#define MAGIC_MISSILE 7
#define CANCELLATION 8
#define DO_NOTHING 9
#define WANDS 10

#define STEALTH 0
#define R_TELEPORT 1
#define REGENERATION 2
#define SLOW_DIGEST 3
#define ADD_STRENGTH 4
#define SUSTAIN_STRENGTH 5
#define DEXTERITY 6
#define ADORNMENT 7
#define R_SEE_INVISIBLE 8
#define MAINTAIN_ARMOR 9
#define SEARCHING 10
#define RINGS 11

#define RATION 0
#define FRUIT 1

#define NOT_USED		((unsigned short)   0)
#define BEING_WIELDED	((unsigned short)  01)
#define BEING_WORN		((unsigned short)  02)
#define ON_LEFT_HAND	((unsigned short)  04)
#define ON_RIGHT_HAND	((unsigned short) 010)
#define ON_EITHER_HAND	((unsigned short) 014)
#define BEING_USED		((unsigned short) 017)

#define NO_TRAP -1
#define TRAP_DOOR 0
#define BEAR_TRAP 1
#define TELE_TRAP 2
#define DART_TRAP 3
#define SLEEPING_GAS_TRAP 4
#define RUST_TRAP 5
#define TRAPS 6

#define STEALTH_FACTOR 3
#define R_TELE_PERCENT 8

#define UNIDENTIFIED ((unsigned short) 00)	/* MUST BE ZERO! */
#define IDENTIFIED ((unsigned short) 01)
#define CALLED ((unsigned short) 02)

#define DROWS 24
#define DCOLS 80
#define MAX_TITLE_LENGTH 30
#define MORE "-more-"
#define MAXSYLLABLES 40
#define MAX_METAL 14
#define WAND_MATERIALS 30
#define GEMS 14

#define GOLD_PERCENT 46

struct id {
	short value;
	char title[128];
	char real[128];
	unsigned short id_status;
};

/* The following #defines provide more meaningful names for some of the
 * struct object fields that are used for monsters.  This, since each monster
 * and object (scrolls, potions, etc) are represented by a struct object.
 * Ideally, this should be handled by some kind of union structure.
 */

#define m_damage damage
#define hp_to_kill quantity
#define m_char ichar
#define first_level is_protected
#define last_level is_cursed
#define m_hit_chance class
#define stationary_damage identified
#define drop_percent which_kind
#define trail_char d_enchant
#define slowed_toggle quiver
#define moves_confused hit_enchant
#define nap_length picked_up
#define disguise what_is
#define next_monster next_object

struct obj {				/* comment is monster meaning */
	unsigned long m_flags;	/* monster flags */
	char *damage;			/* damage it does */
	short quantity;			/* hit points to kill */
	short ichar;			/* 'A' is for aquatar */
	short kill_exp;			/* exp for killing it */
	short is_protected;		/* level starts */
	short is_cursed;		/* level ends */
	short class;			/* chance of hitting you */
	short identified;		/* 'F' damage, 1,2,3... */
	unsigned short which_kind; /* item carry/drop % */
	short o_row, o_col, o;	/* o is how many times stuck at o_row, o_col */
	short row, col;			/* current row, col */
	short d_enchant;		/* room char when detect_monster */
	short quiver;			/* monster slowed toggle */
	short trow, tcol;		/* target row, col */
	short hit_enchant;		/* how many moves is confused */
	unsigned short what_is;	/* imitator's charactor (?!%: */
	short picked_up;		/* sleep from wand of sleep */
	unsigned short in_use_flags;
	struct obj *next_object;	/* next monster */
};

typedef struct obj object;

#define INIT_HP 12

struct fight {
	object *armor;
	object *weapon;
	object *left_ring, *right_ring;
	short hp_current;
	short hp_max;
	short str_current;
	short str_max;
	object pack;
	long gold;
	short exp;
	long exp_points;
	short row, col;
	short fchar;
	short moves_left;
};

typedef struct fight fighter;

struct dr {
	short oth_room;
	short oth_row,
	      oth_col;
	short door_row,
		  door_col;
};

typedef struct dr door;

struct rm {
	char bottom_row, right_col, left_col, top_row;
	door doors[4];
	unsigned short is_room;
};

typedef struct rm room;

#define MAXROOMS 9
#define BIG_ROOM 10

#define NO_ROOM -1

#define PASSAGE -3		/* cur_room value */

#define AMULET_LEVEL 26

#define R_NOTHING	((unsigned short) 01)
#define R_ROOM		((unsigned short) 02)
#define R_MAZE		((unsigned short) 04)
#define R_DEADEND	((unsigned short) 010)
#define R_CROSS		((unsigned short) 020)

#define MAX_EXP_LEVEL 21
#define MAX_EXP 10000000L
#define MAX_GOLD 900000
#define MAX_ARMOR 99
#define MAX_HP 800
#define MAX_STRENGTH 99
#define LAST_DUNGEON 99

#define STAT_LEVEL 01
#define STAT_GOLD 02
#define STAT_HP 04
#define STAT_STRENGTH 010
#define STAT_ARMOR 020
#define STAT_EXP 040
#define STAT_HUNGER 0100
#define STAT_LABEL 0200
#define STAT_ALL 0377

#define PARTY_TIME 10	/* one party somewhere in each 10 level span */

#define MAX_TRAPS 10	/* maximum traps per level */

#define HIDE_PERCENT 12

struct tr {
	short trap_type;
	short trap_row, trap_col;
};

typedef struct tr trap;

extern fighter rogue;
extern room rooms[];
extern trap traps[];
extern unsigned short dungeon[DROWS][DCOLS];
extern object level_objects;

extern struct id id_scrolls[];
extern struct id id_potions[];
extern struct id id_wands[];
extern struct id id_rings[];
extern struct id id_weapons[];
extern struct id id_armors[];

extern object mon_tab[];
extern object level_monsters;

#define MONSTERS 26

#define HASTED					01L
#define SLOWED					02L
#define INVISIBLE				04L
#define ASLEEP				   010L
#define WAKENS				   020L
#define WANDERS				   040L
#define FLIES				  0100L
#define FLITS				  0200L
#define CAN_FLIT			  0400L		/* can, but usually doesn't, flit */
#define CONFUSED	 		 01000L
#define RUSTS				 02000L
#define HOLDS				 04000L
#define FREEZES				010000L
#define STEALS_GOLD			020000L
#define STEALS_ITEM			040000L
#define STINGS			   0100000L
#define DRAINS_LIFE		   0200000L
#define DROPS_LEVEL		   0400000L
#define SEEKS_GOLD		  01000000L
#define FREEZING_ROGUE	  02000000L
#define RUST_VANISHED	  04000000L
#define CONFUSES		 010000000L
#define IMITATES		 020000000L
#define FLAMES			 040000000L
#define STATIONARY		0100000000L		/* damage will be 1,2,3,... */
#define NAPPING			0200000000L		/* can't wake up for a while */
#define ALREADY_MOVED	0400000000L

#define SPECIAL_HIT		(RUSTS|HOLDS|FREEZES|STEALS_GOLD|STEALS_ITEM|STINGS|DRAINS_LIFE|DROPS_LEVEL)

#define WAKE_PERCENT 45
#define FLIT_PERCENT 33
#define PARTY_WAKE_PERCENT 75

#define HYPOTHERMIA 1
#define STARVATION 2
#define POISON_DART 3
#define QUIT 4
#define WIN 5

#define UP 0
#define UPRIGHT 1
#define RIGHT 2
#define RIGHTDOWN 3
#define DOWN 4
#define DOWNLEFT 5
#define LEFT 6
#define LEFTUP 7
#define DIRS 8

#define ROW1 7
#define ROW2 15

#define COL1 26
#define COL2 52

#define MOVED 0
#define MOVE_FAILED -1
#define STOPPED_ON_SOMETHING -2
#define CANCEL '\033'
#define LIST '*'

#define HUNGRY 300
#define WEAK 150
#define FAINT 20
#define STARVE 0

#define MIN_ROW 1

struct rogue_time {
	short year;		/* >= 1987 */
	short month;	/* 1 - 12 */
	short day;		/* 1 - 31 */
	short hour;		/* 0 - 23 */
	short minute;	/* 0 - 59 */
	short second;	/* 0 - 59 */
};

/*
 *  external routine declarations.
 */

/*
 * hit.c
 */
extern void mon_hit(object *, char *, boolean);
extern void get_dir_rc(short, short *, short *, short);
extern void rogue_hit(object *, boolean);
extern int get_number(char *);
extern void fight(boolean);
extern long lget_number(char *);
extern short get_hit_chance(object *);
extern short get_weapon_damage(object *);
extern int mon_damage(object *, short);
extern int get_damage(char *, boolean);

/*
 * init.c
 */
extern void byebye(int);
extern void onintr(int);
extern void error_save(int);
extern void clean_up(char *);
extern int init(int, char *[]);

/*
 * instruct.c
 */
extern void Instructions(void);

/*
 * inventory.c
 */
extern void mix_colors(void);
extern void get_wand_and_ring_materials(void);
extern void make_scroll_titles(void);
extern void get_desc(object *, char *);
extern void inventory(object *, unsigned short);
extern struct id * get_id_table(object *);
extern void inv_armor_weapon(boolean);
extern void single_inv(short);

/*
 * level.c
 */
extern void add_exp(int, boolean);
extern void clear_level(void);
extern void make_level(void);
extern void put_player(short);
extern int drop_check(void);
extern int check_up(void);
extern void show_average_hp(void);
extern int hp_raise(void);

/*
 * machdep.c
 */
extern char * md_gln(void);
extern void md_heed_signals(void);
extern int md_gseed(void);
extern void md_exit(int);
extern void md_control_keybord(short);
extern void md_ignore_signals(void);
extern char * md_getenv(char *);
extern char * md_malloc(int);
extern void md_slurp(void);
extern int md_get_file_id(char *);
extern void md_gct(struct rogue_time *);
extern boolean md_df(char *);
extern int md_link_count(char *fname);
extern void md_gfmt(char *, struct rogue_time *);
extern void md_sleep(int);

/*
 * main.c
 */
extern void turn_into_games(void);
extern void turn_into_user(void);

/*
 * message.c
 */
extern void message(char *, boolean);
extern void print_stats(int);
extern int rgetchar(void);
extern void sound_bell(void);
extern void check_message(void);
extern int r_index(char *, int, boolean);
extern short get_input_line(char *, char *, char *, char *, boolean, boolean);
extern void remessage(void);
extern boolean is_digit(short);

/*
 * monster.c
 */
extern char * mon_name(object *);
extern void wake_up(object *);
extern void wake_room(short, boolean, short, short);
extern char gmc_row_col(int, int);
extern void put_mons(void);
extern void wanderer(void);
extern void mv_mons(void);
extern void party_monsters(int, int);
extern void mv_aquatars(void);
extern void show_monsters(void);
extern boolean mon_sees(object *, int, int);
extern int rogue_can_see(int, int);
extern int mon_can_go(object *, short, short);
extern void move_mon_to(object *, short, short);
extern void mv_monster(object *, short, short);
extern short rogue_is_around(int, int);
extern void create_monster(void);
extern void aggravate(void);
extern char gr_obj_char(void);
extern object * gr_monster(object *, int);
extern char gmc(object *);

/*
 * move.c
 */
extern boolean is_direction(char);
extern int can_move(int, int, int, int);
extern int one_move_rogue(short, short);
extern int is_passable(int, int);
extern boolean reg_move(void);
extern void rest(int);
extern void multiple_move_rogue(int);
extern void move_onto(void);

/*
 * object.c
 */
extern int get_armor_class(object *);
extern void free_object(object *);
extern object * object_at(object *, short, short);
extern object * alloc_object(void);
extern void get_food(object *, boolean);
extern char * name_of(object *);
extern object * get_letter_object(short);
extern void put_amulet(void);
extern void put_objects(void);
extern void put_stairs(void);
extern void free_stuff(object *);
extern void place_at(object *, int, int);
extern void show_objects(void);
extern void new_object_for_wizard(void);
extern object * gr_object(void);

/*
 * pack.c
 */
extern void take_from_pack(object *, object *);
extern object * add_to_pack(object *, object *, int);
extern void do_wear(object *);
extern void do_wield(object *);
extern void wait_for_ack(void);
extern short pack_letter(char *, unsigned short);
extern boolean has_amulet(void);
extern object * pick_up(int, int, short *);
extern short pack_count(object *);
extern void drop(void);
extern void take_off(void);
extern void wear(void);
extern void wield(void);
extern void call_it(void);
extern void kick_into_pack(void);
extern void unwield(object *);
extern void unwear(object *);

/*
 * play.c
 */
extern void play_level(void);

/*
 * random.c
 */
extern int rand_percent(int);
extern int get_rand(int, int);
extern void srrandom(int);
extern int coin_toss(void);

/*
 * ring.c
 */
extern void ring_stats(boolean);
extern void gr_ring(object *, boolean);
extern void un_put_on(object *);
extern void put_on_ring(void);
extern void remove_ring(void);
extern void inv_rings(void);
extern void do_put_on(object *, boolean);

/*
 * room.c
 */
extern char get_dungeon_char(int, int);
extern int is_all_connected(void);
extern void gr_row_col(short *, short *, unsigned short);
extern short get_room_number(int, int);
extern void light_up_room(int);
extern void light_passage(int row, int col);
extern void dr_course(object *, boolean, short, short);
extern void darken_room(short);
extern short gr_room(void);
extern short party_objects(int);
extern char get_mask_char(unsigned short);
extern void draw_magic_map(void);

/*
 * save.c
 */
extern void restore(char *);
extern void save_into_file(char *);
extern void save_game(void);

/*
 * score.c
 */
extern void killed_by(object *, short);
extern void put_scores(object *, short);
extern void quit(boolean);
extern int is_vowel(short);
extern void win(void);
extern long xxx(boolean);
extern void xxxx(char *, short);

/*
 * spec_hit.c
 */
extern void special_hit(object *);
extern int check_imitator(object *);
extern void check_gold_seeker(object *);
extern void cough_up(object *);
extern int imitating(short, short);
extern int m_confuse(object *);
extern int flame_broil(object *);
extern int seek_gold(object *);
extern void rust(object *);

/*
 * throw.c
 */
extern void rand_around(short, short *, short *);
extern void throw(void);

/*
 * trap.c
 */
extern void add_traps(void);
extern void trap_player(short, short);
extern void search(short, boolean);
extern void show_traps(void);
extern void id_trap(void);

/*
 * use.c
 */
extern void tele(void);
extern void unhallucinate(void);
extern void hallucinate(void);
extern void unblind(void);
extern void unconfuse(void);
extern void vanish(object *, short, object *);
extern void eat(void);
extern void quaff(void);
extern void read_scroll(void);
extern void relight(void);
extern void confuse(void);
extern void take_a_nap(void);

/*
 * zap.c
 */
extern void wizardize(void);
extern void zapp(void);
extern void zap_monster(object *, unsigned short);



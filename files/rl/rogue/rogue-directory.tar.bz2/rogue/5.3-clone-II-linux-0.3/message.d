message.o message.d : message.c rogue.h init.h level.h machdep.h message.h object.h \
  pack.h

machdep.o machdep.d : machdep.c

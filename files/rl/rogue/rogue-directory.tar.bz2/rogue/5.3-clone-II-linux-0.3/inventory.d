inventory.o inventory.d : inventory.c rogue.h init.h inventory.h message.h object.h \
  pack.h random.h score.h

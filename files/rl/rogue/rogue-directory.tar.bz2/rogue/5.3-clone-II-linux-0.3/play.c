/*
 * play.c
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  No portion of this notice shall be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */

#include <ncurses.h>
#include "rogue.h"
#include "hit.h"
#include "instruct.h"
#include "inventory.h"
#include "level.h"
#include "message.h"
#include "monster.h"
#include "move.h"
#include "object.h"
#include "pack.h"
#include "play.h"
#include "ring.h"
#include "room.h"
#include "save.h"
#include "score.h"
#include "throw.h"
#include "trap.h"
#include "use.h"
#include "zap.h"

boolean interrupted = 0;
char *unknown_command = "Unknown command.";

// extern short party_room, bear_trap;
extern char hit_message[];
extern boolean wizard, trap_door;
extern fighter rogue;
extern object level_objects;

void whatisit(void)
{
	int ch;
	char *msg;
	char messbuf[80];
	extern char *m_names[];

	check_message();
	message("What character would you like to know?", 0);
	do
	{
		ch = getchar();
		if (isprint(ch) && !iscntrl(ch))
			break;
		if (ch == CANCEL)
			break;
		sound_bell();
	} while (1);
	if (isupper(ch))
	{
		char *article;
		msg = m_names[ch - 'A'];
		switch (*msg)
		{
			case 'A':
			case 'a':
			case 'E':
			case 'e':
			case 'I':
			case 'i':
			case 'O':
			case 'o':
			case 'U':
			case 'u':
				article = "an";
				break;
			default:
				article = "a";
				break;
		}
		sprintf(messbuf, "<%c> is %s %s", ch, article, msg);
		msg = messbuf;
	}
	else
	{
		switch (ch)
		{
			case CANCEL:
				check_message();
				return;
				break;
			case '|':
			case '-':
				msg = "the wall";
				break;
			case '+':
				msg = "a door";
				break;
			case '#':
				msg = "a tunnel";
				break;
			case '.':
				msg = "a floor tile";
				break;
			case '!':
				msg = "a potion";
				break;
			case '?':
				msg = "a scroll";
				break;
			case ')':
				msg = "a weapon";
				break;
			case ']':
				msg = "a suit of armour";
				break;
			case '*':
				msg = "some gold";
				break;
			case ':':
				msg = "some food";
				break;
			case '/':
				msg = "a wand or staff";
				break;
			case '=':
				msg = "a ring";
				break;
			case ',':
				msg = "The Amulet of Yendor";
				break;
			case '^':
				msg = "a trap";
				break;
			case '%':
				msg = "stairs";
				break;
			case '@':
				msg = "you";
				break;
			default:
				msg = messbuf;
				sprintf(messbuf, "I don't know what <%c> is either", ch);
				break;
		}
		if (msg != messbuf)
		{
			sprintf(messbuf, "<%c> is %s", ch, msg);
			msg = messbuf;
		}
	}
	check_message();
	message(msg, 0);
}

void play_level(void)
{
	short ch;
	int count;

	for (;;)
	{
		interrupted = 0;
		if (hit_message[0])
		{
			message(hit_message, 1);
			hit_message[0] = 0;
		}
		if (trap_door)
		{
			trap_door = 0;
			return;
		}
		move(rogue.row, rogue.col);
		refresh();

		ch = rgetchar();
		check_message();
		count = 0;
CH:
		switch(ch)
		{
		case '?':
			Instructions();
			break;
		case '.':
			rest((count > 0) ? count : 1);
			break;
		case 's':
			search(((count > 0) ? count : 1), 0);
			break;
		case 'i':
			inventory(&rogue.pack, ALL_OBJECTS);
			break;
		case 'f':
			fight(0);
			break;
		case 'F':
			fight(1);
			break;
		case 'h':
		case 'j':
		case 'k':
		case 'l':
		case 'y':
		case 'u':
		case 'n':
		case 'b':
			(void) one_move_rogue(ch, 1);
			break;
		case 'H':
		case 'J':
		case 'K':
		case 'L':
		case 'B':
		case 'Y':
		case 'U':
		case 'N':
		case '\010':
		case '\012':
		case '\013':
		case '\014':
		case '\031':
		case '\025':
		case '\016':
		case '\002':
			multiple_move_rogue(ch);
			break;
		case 'e':
			eat();
			break;
		case 'q':
			quaff();
			break;
		case 'r':
			read_scroll();
			break;
		case 'm':
			move_onto();
			break;
		case 'd':
			drop();
			break;
		case 'P':
			put_on_ring();
			break;
		case 'R':
			remove_ring();
			break;
		case '\020':
			remessage();
			break;
		case '\027':
			wizardize();
			break;
		case '>':
			if (drop_check())
			{
				return;
			}
			break;
		case '<':
			if (check_up())
			{
				return;
			}
			break;
		case ')':
		case ']':
			inv_armor_weapon(ch == ')');
			break;
		case '=':
			inv_rings();
			break;
		case '^':
			id_trap();
			break;
		case 'I':
			single_inv(0);
			break;
		case 'T':
			take_off();
			break;
		case 'W':
			wear();
			break;
		case 'w':
			wield();
			break;
		case 'c':
			call_it();
			break;
		case 'z':
			zapp();
			break;
		case 't':
			throw();
			break;
		case 'v':
			message("LinuxRogue v0.2.x -- A rogue clone for Linux. (Ashwin N was here)", 0);
			break;
		case 'Q':
			quit(0);
		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			move(rogue.row, rogue.col);
			refresh();
			do
			{
				if (count < 100)
				{
					count = (10 * count) + (ch - '0');
				}
				ch = rgetchar();
			} while (is_digit(ch));
			if (ch != CANCEL)
			{
				goto CH;
			}
			break;
		case ' ':
			break;
		case '\011':
			if (wizard)
			{
				inventory(&level_objects, ALL_OBJECTS);
			}
			else
			{
				message(unknown_command, 0);
			}
			break;
		case '\023':
			if (wizard)
			{
				draw_magic_map();
			}
			else
			{
				message(unknown_command, 0);
			}
			break;
		case '\024':
			if (wizard)
			{
				show_traps();
			}
			else
			{
				message(unknown_command, 0);
			}
			break;
		case '\017':
			if (wizard)
			{
				show_objects();
			}
			else
			{
				message(unknown_command, 0);
			}
			break;
		case '\001':
			show_average_hp();
			break;
		case '\177':
			if (wizard)
			{
				new_object_for_wizard();
			}
			else
			{
				message(unknown_command, 0);
			}
			break;
		case '\015':
			if (wizard)
			{
				show_monsters();
			}
			else
			{
				message(unknown_command, 0);
			}
			break;
		case 'S':
			save_game();
			break;
		case ',':
			kick_into_pack();
			break;
		case '/':
			whatisit();
			break;
		default:
			message(unknown_command, 0);
			break;
		}
	}
}

Relay-Version: version B 2.10 5/3/83; site utzoo.UUCP
Posting-Version: version B 2.10.2 (Tek) 9/28/84 based on 9/17/84; site zeus.UUCP
From: tims@zeus.UUCP (Tim Stoehr)
Newsgroups: net.sources.games
Subject: rogue 5.3 clone source, shell archive enclosed.
Message-ID: <6@zeus.UUCP>
Date: Wed, 26-Feb-86 12:57:14 EST
Article-I.D.: zeus.6
Posted: Wed Feb 26 12:57:14 1986
Date-Received: Fri, 28-Feb-86 03:53:27 EST
Distribution: na
Organization: Tektronix, Beaverton OR
Lines: 6193


I recently posted an article asking if anyone would like the source
to a rogue 5.3 look-alike that I wrote.  There was sufficient response
to post it.  I wrote this code out of disgust for the inexcusable number
of bugs that rogue 5.3 is famous for.  I wrote this to eliminate the
bugs as well as to get rid of some other things I didn't care for.
Except for the list of differences below, this game plays remarkably
like 5.3.

Major differences from 5.3

  1.)  No traps or hidden doors/passages.
  2.)  Save game not implemented.
  3.)  ROGUEOPTS not implemented.
  4.)  You cannot throw anything besides weapons.
  5.)  All unidentified scrolls/potions will identify themselves after use.
  6.)  There is only one scroll of identify and it works on anything.
  7.)  Some of the wands are different.
  8.)  ALL rooms, except when blind, light up when you enter, and darken
       when you leave.
  9.)  It's more winnable, you can change the monster characteristics and
       magic-items-per-level numbers to make it more or less difficult.

I would welcome any comments/questions/suggestions.
Mail to tektronix!zeus!tims
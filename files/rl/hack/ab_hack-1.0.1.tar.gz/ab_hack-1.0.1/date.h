
char datestring[] = "Mon Jan 21 1985";

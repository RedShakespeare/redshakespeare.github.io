
char datestring[] = "Sun Apr 14 1985";

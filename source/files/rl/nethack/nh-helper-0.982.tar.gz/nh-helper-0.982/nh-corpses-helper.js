
//
// Nethack Price Calculation
// (c) 2k5 by HiSPeed
//
// Offline usage and tinkering with the actual code is strictly allowed.
//
// Have fun.
//

// Corpse Helper

// the user selects a monster from the list / an intrinsics / an effect he wants info about.
// the helper will show the monster info / a list of monsters providing the wanted effect.
//

//
// TODO: None
//

// Done: - AND/OR search for the corpse list.. in other words:
//   <tomp@#nethack> Being able to find monsters that give poison resistance that are NOT poisonous would be useful
//
//       - differ between selection via <select> event (dont croak if first line selected) and button click (always croak if first line selected)
//

var corpse_starting = (0==0);


function corpses_start()
{
  if (!corpse_starting)
  {
    var selection = corpses_getselection();
	 
	 var corpses_text = "";
    if (selection['cmd'] == "monsterinfo")
      corpses_text = corpses_getmonsterinfo (selection['what']);
    else if (selection['cmd'] == "findcorpse")
      corpses_text = corpses_getlistofmonsters (selection);
    else
    {
      if (document.corpseform.clicked.value == "monsterinfo")
        alert ("Please choose a monster you want info about!");
  	   else if (document.corpseform.clicked.value == "findcorpse")
  	     alert ("Please choose an intrinsic/effect/min or max nutrition you want to find monsters for!");
  	   else
  	     alert ("Huh? What? Where am I?!\n\nIn other words: Send feedback via the feedback form, explain what you did to get here, what browser you are using, etc.");
    }
  
    if (selection['cmd'] == 'monsterinfo')
    {
      var el = document.getElementById("resinfo");
      el.innerHTML = corpses_text;
		el = document.getElementById("resinfoheader");
		el.innerHTML = "<b>Info about "+selection['what']+ "</b>";
    }
    else if (selection['cmd'] == "findcorpse")
    {
    }
  } // end if not starting atm
} // end func corpses_start


function corpses_getselection()
{
  var arrSelection = new Array();
  var foo = document.corpseform;
  var foo2 = document.corpseform2;
  var foo3 = document.corpseform3;

  arrSelection ['cmd'] = "";				// default for error checking on shown frames which shouldnt be shown.

  if (foo.clicked.value == "monsterinfo")
  {
    if (foo.clicked2.value == "mon")
	 {
      if ((foo.corpsechosenmonster.selectedIndex >= 0) && (foo.corpsechosenmonster[foo.corpsechosenmonster.selectedIndex].value != ""))
      {
        arrSelection ['cmd'] = "monsterinfo";
        arrSelection ['what'] = foo.corpsechosenmonster[foo.corpsechosenmonster.selectedIndex].value;
      }
	 }
	 else
	 {
	  if (foo.clicked2.value == "mon2")
	  {
      if ((foo2.corpsechosenmonster.selectedIndex >= 0) && (foo2.corpsechosenmonster[foo2.corpsechosenmonster.selectedIndex].value != ""))
      {
        arrSelection ['cmd'] = "monsterinfo";
        arrSelection ['what'] = foo2.corpsechosenmonster[foo2.corpsechosenmonster.selectedIndex].value;
      }
	  }
	 }
  }
  else if (foo.clicked.value == "findcorpse")
  {
    arrSelection ['cmd'] = "findcorpse";
	 arrSelection ['mod1'] = foo3.corpsemod1[foo3.corpsemod1.selectedIndex].value;
	 arrSelection ['mod2'] = foo3.corpsemod2[foo3.corpsemod2.selectedIndex].value;
	 arrSelection ['intrnot'] = foo3.corpseintrnot[foo3.corpseintrnot.selectedIndex].value;
	 arrSelection ['effnot'] = foo3.corpseeffnot[foo3.corpseeffnot.selectedIndex].value;
	 arrSelection ['i'] = foo3.corpsechosenintr[foo3.corpsechosenintr.selectedIndex].value;
	 arrSelection ['e'] = foo3.corpsechoseneff[foo3.corpsechoseneff.selectedIndex].value;
	 arrSelection ['nmin'] = foo3.nutrmin.value;
	 arrSelection ['nmax'] = foo3.nutrmax.value;
//    alert ("findcorpses:\n" +arrSelection['intrnot']+ " * intr "+arrSelection['i']+ "\n" +arrSelection['mod1']+ "\n" +arrSelection['effnot']+ " * eff " +arrSelection['e']+ "\n" +arrSelection['mod2']+ "\n nutr min " +arrSelection['nmin']+ ", max " +arrSelection['nmax']+ "\n");
  }
  else
  {
    arrSelection['cmd'] = "Huh? what? where am i?!";
  }

  return (arrSelection);
} // end func corpses_getselection



function corpses_init()
{
  document.corpseform.clicked.value = "";
  document.corpseform.clicked2.value = "";
  corpses_reset();
  corpses_toggledark();
} // end func corpses_init


function corpses_reset()
{
  corpse_starting = (0==0);
  
  var c2 = document.corpseform.clicked2.value;

  var i=1;
  var newline = new Option ("Choose a monster", "", true, false);   document.corpseform.corpsechosenmonster[0] = newline;
  for (name in corpses)
  {
    newline = new Option (name, name, false, false);
    document.corpseform.corpsechosenmonster[i] = newline;
    i++;
  }
  document.corpseform.corpsechosenmonster.selectedIndex = 0;

  document.corpseform3.corpsemod1.selectedIndex = 1;
  document.corpseform3.corpsemod2.selectedIndex = 1;
  document.corpseform3.corpseeffnot.selectedIndex = 0;
  document.corpseform3.corpseintrnot.selectedIndex = 0;

  i = 1;
  newline = new Option ("Choose an intrinsic", "", true, false);   document.corpseform3.corpsechosenintr[0] = newline;
  for (name in intrinsics)
  {
    newline = new Option (name, name, false, false);
    document.corpseform3.corpsechosenintr[i] = newline;
    i++;
  }
  document.corpseform3.corpsechosenintr.selectedIndex = 0;
  
  i = 1;
  newline = new Option ("Choose an effect", "", true, false);   document.corpseform3.corpsechoseneff[0] = newline;
  for (name in effects)
  {
    newline = new Option (name, name, false, false);
    document.corpseform3.corpsechoseneff[i] = newline;
    i++;
  }
  document.corpseform3.corpsechoseneff.selectedIndex = 0;
  
  document.corpseform3.nutrmin.value = "";
  document.corpseform3.nutrmax.value = "";

  gui_clearselect (document.corpseform2.corpsechosenmonster);
  corpses__setcorpsehead ("");
  corpses__setcorpseres (0);

  corpse_starting = (0==1);
} // end func corpses_reset




function corpses_setclicked (val, val2)
{
  document.corpseform.clicked.value = val;
  document.corpseform.clicked2.value = val2;
}




function corpses_getlistofmonsters (sel)
{
  var results = new Array();
  var dbg = "";
  
//    alert ("findcorpses:\n" +sel['intrnot']+ " * intr "+sel['i']+ "\n" +sel['mod1']+ "\n" +sel['effnot']+ " * eff " +sel['e']+ "\n" +sel['mod2']+ "\n nutr min " +sel['nmin']+ ", max " +sel['nmax']+ "\n");

  var cnt = 0;
  
  for (mon in corpses)
  {
    var c = corpses[mon];

	 var intrhit = 0;
	 var effhit = 0;
	 var nminhit = 0;
	 var nmaxhit = 0;

	 if (sel['i'] != "")
	 {
	   if (sel['intrnot'] == 1)			// true => has
	   {
	     intrhit = corpses__has_intr (c, sel['i']);
	   }
		else								// false => has not
		{
		  intrhit = ((corpses__has_intr (c, sel['i']) == 1) ? 0 : 1);
		}
	 }
	 else
	 {
	   intrhit = -1;		// no do op
	 }
	 
	 if (sel['e'] != "")
	 {
	   if (sel['effnot'] == 1)			// true => has
	   {
		  effhit = corpses__has_eff (c, sel['e']);
	   }
		else								// false => has not
		{
		  effhit = ((corpses__has_eff (c, sel['e']) == 1) ? 0 : 1);
		}
	 }
	 else
	 {
	   effhit = -1;			// no do op
	 }

	 if (sel['nmin'] != "")
	 {
	   nminhit = (c['nutr'] >= sel['nmin']) ? 1 : 0;
	 }
	 else
	 {
	   nminhit = -1;
	 }
	 
	 if (sel['nmax'] != "")
	 {
	   nmaxhit = (c['nutr'] <= sel['nmax']) ? 1 : 0;
	 }
	 else
	 {
	   nmaxhit = -1;
	 }

	 var got_hit = 0;
	 
//	 dbg += ( (! ((intrhit == -1) && (effhit == -1))) ? c['name'] +" => i " +intrhit+ ", e " +effhit+ ", nmin " +nminhit+ ", nmax " +nmaxhit+ " || " : "");
//	 dbg += ( (++cnt % 4) == 0) ? "\n" : "";
	
	 var nhit = -1;
	 if ((nminhit == -1) && (nmaxhit == -1))  nhit = 1;
	 if ((nminhit == 1) && (nmaxhit == -1)) nhit = nminhit;
	 if ((nminhit == -1) && (nmaxhit == 1)) nhit = nmaxhit;
	 if ((nminhit == 1) && (nmaxhit == 1)) nhit = 1;
	 if ((nminhit == 0) && (nmaxhit == -1)) nhit = nminhit;
	 if ((nminhit == -1) && (nmaxhit == 0)) nhit = nmaxhit;
	 if ((nminhit == 0) && (nmaxhit == 1)) nhit = 0;
	 if ((nminhit == 1) && (nmaxhit == 0)) nhit = 0;
	 if ((nminhit == 0) && (nmaxhit == 0)) nhit = 0;

//	 dbg += c['name'] +" => n " +c['nutr']+ ": nmin "+nminhit+", nmax "+nmaxhit+ " ==> "+nhit+ " || ";
//	 dbg += ( (++cnt % 4) == 0) ? "\n" : "";
	 
	 var foo1 = (
	      ((intrhit != -1) && (effhit != -1))
			?
	      (
	        (sel['mod1'] == "AND")
			  &&
			  ((intrhit == 1) && (effhit == 1))
         )
			||
         (
			  (sel['mod1'] == "OR")
			  &&
			  ((intrhit == 1) || (effhit == 1))
			)
		  :
		  ((effhit != -1)
		   ?
			(effhit == 1)
			:
			((intrhit != -1)
			 ?
			 (intrhit == 1)
			 :
			 1
			)
		  )
		 ) ? 1 : 0;

    var foo2 = (
	   ((intrhit != -1) || (effhit != -1))
		?
		(
	    (
		  (sel['mod2'] == "AND")
		  &&
		  (
		    (foo1 == 1)
			 &&
		    ((nhit != -1) ? (nhit == 1) : 1)
		  )
		 )
		 ||
		 (
		  (sel['mod2'] == "OR")
		  &&
		  (
		    (foo1 == 1)
			 ||
			 ((nhit != -1) ? (nhit == 1) : 1)
		  )
		 )
		)
		:
		((nhit != 1) ? (nhit == 1) : 1)
    ) ? 1 : 0;
		
	 if (
	      (foo1 == 1)
			&&
			(foo2 == 1)
		 )
      got_hit = 1;

//	 dbg += c['name'] +" => nhit " +nhit+ ";; foo1 " +foo1+", foo2 "+foo2+ " || ";
//	 dbg += ( (++cnt % 4) == 0) ? "\n" : "";

	 if (got_hit == 1)
	 {
	   results[results.length] = c['name'];
	 }
	 
  } // end foreach corpse in db


//alert (dbg);


  //
  // now the output
  //

  if (results.length > 0)
  {
	 var headstr = "List of " +(results.length)+ " monster" +((results.length > 1) ? "s":"") + " ";
	 headstr    += ((sel['i'] != "") || (sel['e'] != "") || (sel['nmin'] != "") || (sel['nmax'] != "")) ? " with " : " (=all).";
	 headstr    += (
	                 (sel['i'] != "")
						  ?
						    "intrinsic " +((sel['intrnot'] == 1) ? "" : "not ")+ sel['i']+ " "
						  :
						    ""
						);

	 headstr    += (
	                 ((sel['i'] != "") && (sel['e'] != ""))
						  ?
						  ( (sel['mod1'] == "AND") ? "and":"or" ) + " "
						  :
						  ""
						);
	 
	 headstr    += (
	                 (sel['e'] != "")
						  ?
						  "effect " +((sel['effnot'] == 1) ? "" : "not ")+ sel['e'] +" "
						  :
						  ""
						);
	 headstr    += (
	                 ((sel['nmin'] != "") || (sel['nmax'] != ""))
	                 ?
	                   ((sel['e'] != "") ? ( (sel['mod2'] == "AND") ? "and":"or" ) : "") +
						    " nutrition"+ ((sel['nmin'] != "") ? " min "+sel['nmin'] : "") +((sel['nmax'] != "") ? " max "+sel['nmax'] : "")
						  : ""
						);
	 headstr    += "<br>\n";
	 corpses__setcorpsehead (headstr);

	 var monlist = document.corpseform2.corpsechosenmonster;
    gui_clearselect (monlist);
	 corpses__setcorpseres (1);

	 var newentry = new Option ("Choose a monster!", "", true, false);
	 monlist[0] = newentry;
    for (var i = 0; i < results.length; i++)
	 {
	   newentry = new Option (results[i], results[i], false, false);
		monlist[i+1] = newentry;
	 }

  }
  else
  {
    corpses__setcorpsehead ("No monsters found for that combination.");
	 corpses__setcorpseres (0);
	 gui_clearselect (document.corpseform2.corpsechosenmonster);
  }
} // end func corpses_getlistofmonsters



function corpses__setcorpseres (what)
{
  var el = document.getElementById("corpseres");
  if (el)
  {
    el.style.visibility = ((what == 0) ? "hidden" : "visible");
    el.style.display    = ((what == 0) ? "none" : "");
  }
} // end func corpses__setcorpseres


function corpses__setcorpsehead (what)
{
  var el = document.getElementById("corpseresheader");
  if (el)
  {
    el.innerHTML = what;
	 _show_element (el, (0==0));
  }
} // end func corpses__setcorpsehead


function corpses__has_intr (c, intr)
{
  if (intr != "")
  {
    for (var o in c['intrinsics'])
    {
      if (o == intr) return 1;
    }
  }
  return 0;
} // end func corpses_has_intr


function corpses__has_eff (c, eff)
{
  if (eff != "")
  {
    for (var effname in c['effects-init'])
    {
      if (effname == eff) return 1;
    }
    for (var effname in c['effects-final'])
    {
      if (effname == eff) return 1;
    }
  }
  return 0;
} // end func corpses__has_eff



function corpses_getmonsterinfo (name)
{
  if (!name) return ("");

  var output = "";

  // first some inner tables
  var out_intr = "  <table cellspacing=0 cellpadding=2 border=0 width=100%>\n";
  var foo = 0;
  for (var k in corpses[name]['intrinsics'])
  {
    if (corpses[name]['intrinsics'][k])
	 {
      out_intr += "   <tr class='resfgcol'><td class='resfgcol' width=10% id='resrow2'>" +k+ "</td><td width=90% id='resrow2'>" +corpses[name]['intrinsics'][k]+ " %</td></tr>\n";
		foo++;
	 }
  }
  if (foo == 0) out_intr += "   <tr class='resfgcol'><td class='resfgcol' width=100% colspan=2 id='resrow2'><b>None</b></td></tr>\n";
  out_intr += "  </table>\n";
  
  var out_effinit = "  <table cellspacing=0 cellpadding=2 border=0 width=100%>\n";
  foo = 0;
  for (var k in corpses[name]['effects-init'])
  {
    if (corpses[name]['effects-init'][k])
    {
      out_effinit += "   <tr class='resfgcol'><td class='resfgcol' width=100% id='resrow2'>" +k+ ": " +corpses[name]['effects-init'][k]+ "%</td></tr>\n";
	   foo++;
    }
  }
  if (foo == 0) out_effinit += "   <tr class='resfgcol'><td class='resfgcol' width=100% id='resrow2'><b>None</b></td></tr>\n";
  out_effinit += "  </table>\n";
  
  var out_efffin = "  <table cellspacing=0 cellpadding=2 border=0 width=100%>\n";
  foo = 0;
  for (var k in corpses[name]['effects-final'])
  {
    if (corpses[name]['effects-final'][k])
	 {
	   out_efffin += "   <tr class='resfgcol'><td class='resfgcol' width=100% id='resrow2'>" +k+ ": " +corpses[name]['effects-final'][k]+ "%</td></tr>\n";
		foo++;
    }
  }
  if (foo == 0) out_efffin += "   <tr class='resfgcol'><td class='resfgcol' width=100% id='resrow2'><b>None</b></td></tr>\n";
  out_efffin += "  </table>\n";
	

  output += "<table cellspacing=0 cellpadding=1 border=0 width=100%>\n";

  // now the actual creation of output
  for (var k in corpses[name])
  {
    if ((k != "intrinsics") && (k != "effects-init") && (k != "effects-final"))
	 {
	   var outname = "";   var outval = "";
		if (k == "name") outname = "Name";
		if (k == "nutr") outname = "Nutrition";
		if (k == "veggy") outname = "Vegetarian food?";
		if (k == "vegan") outname = "Vegan food?";
		if ((k == "name") || (k == "nutr")) outval = corpses[name][k];
		else outval = ((corpses[name][k] == 0) ? "No" : "Yes");
      output += "<tr class='resfgcol'><td class='resfgcol' width=15% colspan=2 id='resheader2'><b>" +outname+ "</b></td><td width=85% id='resrow'>" +outval+ "</td></tr>\n";
	 }
  }
  output += "<tr height=5><td height=5 colspan=3 width=100%></td></tr>\n";
  output += "<tr class='resfgcol'><td class='resfgcol' width=100% colspan=3 id='resheader2'><b>Inital effects:</b></td></tr>\n";
  output += "<tr class='resfgcol'><td class='resfgcol' width=2%></td><td class='resfgcol' width=98% colspan=2 id='resrow'>\n" +out_effinit+ "\n</td></tr>\n";;
  output += "<tr class='resfgcol'><td class='resfgcol' width=100% colspan=3 id='resheader2'><b>Final effects:</b></td></tr>\n";
  output += "<tr class='resfgcol'><td class='resfgcol' width=2%></td><td class='resfgcol' width=98% colspan=2 id='resrow'>\n" +out_efffin+ "\n</td></tr>\n";;
  output += "<tr class='resfgcol'><td class='resfgcol' width=100% colspan=3 id='resheader2'><b>Intrinsics:</b></td></tr>\n";
  output += "<tr class='resfgcol'><td class='resfgcol' width=2%></td><td class='resfgcol' width=98% colspan=2 id='resrow'>\n" +out_intr+ "\n</td></tr>\n";;
  output += "</table>\n";

  return (output);
} // end func corpses_getmonsterinfo





// 
// some gui stuff
//

function corpses_toggledark()
{
  var f = document.corpseform3;
  var i = f.corpsechosenintr[f.corpsechosenintr.selectedIndex].value;
  var e = f.corpsechoseneff[f.corpsechoseneff.selectedIndex].value;
  var nmin = f.nutrmin.value;
  var nmax = f.nutrmax.value;

  if (i != "")
  {
    corpses__settogglelight ("intrline1");
  }
  else
  {
    corpses__settoggledark ("intrline1");
  }

  if (e != "")
  {
    corpses__settogglelight ("effline3");
  }
  else
  {
    corpses__settoggledark ("effline3");
  }

  if ((nmin != "") || (nmax != ""))
  {
    corpses__settogglelight ("nutrline5");
    corpses__settogglelight ("nutrline6");
  }
  else
  {
    corpses__settoggledark ("nutrline5");
    corpses__settoggledark ("nutrline6");
  }

  if ((i != "") && (e != ""))
  {
    corpses__settogglelight ("modline2");
  }
  else
  {
    corpses__settoggledark ("modline2");
  }

  if ( ((i != "") || (e != "")) && ((nmin != "") || (nmax != "")) )
  {
    corpses__settogglelight ("modline4");
  }
  else
  {
    corpses__settoggledark ("modline4");
  }
} // end func corpses_toggledark


function corpses__settogglelight(el)
{
  // originally: #99B
  var col = "corpseslight winfgcol";
  var e1 = document.getElementById(el+ "1");
  var e2 = document.getElementById(el+ "2");
  if (e1) e1.className = col;
  if (e2) e2.className = col;
} // end func corpses__settogglelight


function corpses__settoggledark(el)
{
  var col = "corpsesdark winfgcol";
  var e1 = document.getElementById(el+ "1");
  var e2 = document.getElementById(el+ "2");
  if (e1) e1.className = col;
  if (e2) e2.className = col;
} // end func corpses__settoggledark





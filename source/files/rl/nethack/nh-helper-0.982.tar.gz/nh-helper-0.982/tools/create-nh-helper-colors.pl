#!perl -w




# definitions
my @colnames = qw (bodybgcol bodyfgcol winbgcol winfgcol resbgcol resfgcol corpsesdark licensecol);
my %html_colornames = map { $_ => 1 } qw (aliceblue antiquewhite aqua aquamarine azure beige bisque black blanchedalmond blue blueviolet brown burlywood cadetblue chartreuse chocolate coral cornflowerblue cornsilk crimson cyan darkblue darkcyan darkgoldenrod darkgray darkgreen darkkhaki darkmagenta darkolivegreen darkorange darkorchid darkred darksalmon darkseagreen darkslateblue darkslategray darkturquoise darkviolet deeppink deepskyblue dimgray dodgerblue feldspar firebrick floralwhite forestgreen fuchsia gainsboro ghostwhite gold goldenrod gray green greenyellow honeydew hotpink indianred indigo ivory khaki lavender lavenderblush lawngreen lemonchiffon lightblue lightcoral lightcyan lightgoldenrodyellow lightgrey lightgreen lightpink lightsalmon lightseagreen lightskyblue lightslateblue lightslategray lightsteelblue lightyellow lime limegreen linen magenta maroon mediumaquamarine mediumblue mediumorchid mediumpurple mediumseagreen mediumslateblue mediumspringgreen mediumturquoise mediumvioletred midnightblue mintcream mistyrose moccasin navajowhite navy oldlace olive olivedrab orange orangered orchid palegoldenrod palegreen paleturquoise palevioletred papayawhip peachpuff peru pink plum powderblue purple red rosybrown royalblue saddlebrown salmon sandybrown seagreen seashell sienna silver skyblue slateblue slategray snow springgreen steelblue tan teal thistle tomato turquoise violet violetred wheat white whitesmoke yellow yellowgreen);

# our css elements
my @hc = (
  # color 0 = body bg color
  {
    '.bodybgcol' => 'background-color: ',
	 '.corpseslight' => 'background-color: ',
	 '.tabcontentborder' => 'border: 1px solid ',
  },
  # color 1 = body fg color
  {
    '.bodyfgcol' => 'color: ',
	 'a:link' => 'color: ',
	 'a:visited' => 'color: ',
	 'a:hover' => 'color: ',
	 'a:active' => 'color: ',
  },
  # color 2 = win bg color
  {
    '.winbgcol' => 'background-color: ',
    '.winfgbgcol' => 'color: ',
    '.itembgcol' => 'background-color: ',
	 '.menuheadborder' => [ 'border-left: 1px solid ', 'border-bottom: 1px solid ', 'border-right: 1px solid ' ],
	 '.menuheadselborder' => [ 'border-left: 1px solid ', 'border-right: 1px solid ' ],
  },
  # color 3 = win fg color
  {
    '.winfgcol' => 'color: ',
    '.winbgfgcol' => 'background-color: ',
    '.itemfgcol' => 'color: ',
  },
  # color 4 = res bg color
  {
    '.resbgcol' => 'background-color: ',
    '.resfgbgcol' => 'color: ',
	 '.formsbgcol' => 'background-color: ',
  },
  # color 5 = res fg color
  {
    '.resfgcol' => 'color: ',
    '.resbgfgcol' => 'background-color: ',
	 '.formsfgcol' => 'color: ',
	 '.formsborder' => 'border: 1px solid ',
	 '.resborder' => 'border: 1px solid ',
  },
  # color 6 = corpses dark bg color
  {
    '.corpsesdark' => 'background-color: ',				# color like bodybgcol, just darker ;)
  },
  # color 7 = license fg color
  {
    '.licensecol' => 'color: ',
    '#licensecol' => 'color: ',
  }
  
);






# input parsing
my $newcreate_ok = ($#ARGV > 6);
my $recreate_ok = ((defined($ARGV[0])) and ($ARGV[0] eq "-r") and ($#ARGV == 1));


if ((!$newcreate_ok) and (!$recreate_ok))
{
  print "\nusage to create a new colorscheme:\n";
  print "$0 <bodybgcol> <bodyfgcol> <winbgcol> <winfgcol> <resbgcol> <resfgcol> <corpsesdark> <licensecol>\n\n";
  print "to re-create an old colorscheme to the new format:\n";
  print "$0 -r <oldcssfilename>\n";
  print "\n";  
  exit (0);
}


my @cols = ();
if ($newcreate_ok)
{
  @cols = @ARGV;
}
elsif ($recreate_ok)
{
  if (open (A, "<$ARGV[1]"))
  {
    my $endofheader_found = (0==1);
	 
    while ((!$endofheader_found) and (defined(my $inp = <A>)))
	 {
	   chomp ($inp);
		if ($inp =~ /^\s*$/i)
		{
		  $endofheader_found = (0==0);
		}
		elsif ($inp =~ /^\d+\./)
		{
		  my @t = split /\s+/, $inp;
		  $cols[$t[0]] = $t[2];
		}
		# else just skip / next
	 }
    close(A);
  }
  else
  {
    print "Couldn't open old css file '$ARGV[1]'\n\n";
	 exit (0);
  }
  
}





my $found_undefined_htmlcolor = (0==1);
for (my $i=0; $i <= $#cols; $i++)
{
  if ($cols[$i] =~ /^#?[0-9a-f]+$/ig)								# if is hexcode color
  {
    if ($cols[$i] =~ /^#?(?:[0-9a-f]{3}|[0-9a-f]{6})$/i)
    {
      $cols[$i] = "#$cols[$i]" if ($cols[$i] =~ /^(?:[0-9a-f]{3}|[0-9a-f]{6})$/i);		# add # if needed
	 }
	 else
	 {
	   print "Incorrect html color '$cols[$i]'.\n";
	   $found_undefined_htmlcolor = (0==0);
	 }
  }
  else																		# else if real html color name
  {
    if ((!defined($html_colornames {lc($cols[$i])})) or ($html_colornames {lc($cols[$i])} != 1))
    {
	   print "Unknown html color '$cols[$i]'.\n";
	   $found_undefined_htmlcolor = (0==0);
	 }
  }
}

if ($found_undefined_htmlcolor)
{
  print "\nExitting...\n\n";
  exit (0);
}










print "/*\n";
for (my $i=0; $i <= $#cols; $i++)
{
  print "$i. $colnames[$i] $cols[$i]\n";
}
print "*/\n\n";


my %out = ();

for (my $i=0; $i <= $#cols; $i++)
{
  my %h = %{$hc[$i]};
  foreach my $k (sort keys %h)
  {
    my $tmp = "$k {\n";
    if (ref($h{$k}) eq "ARRAY")
	 {
	   foreach my $k2 (sort @{$h{$k}})
		{
	     $tmp .= "  $k2 $cols[$i];\n";
		}
	 }
	 else
	 {
	   $tmp .= "  $h{$k} $cols[$i];\n";
	 }
    $tmp .= "}\n\n";

	 $out{$k} = $tmp;
  }
}

foreach my $k (sort keys %out)
{
  print $out{$k};
}





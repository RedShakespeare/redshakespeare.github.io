


var helper_infos = new Array( "about", "links", "troubleshooting", "appearance", "potion", "res" );
var helper_tabs = new Array( "feedback", "alchemy", "corpses", "prefs" );

/* new design */
var menu_headers = new Array ('', 'nh_basicstatstab', 'nh_priceidtab', 'nh_spbktab', 'nh_corpsestab', 'nh_alchemytab', 'nh_generalinfotab', 'nh_prefstab', 'nh_feedbacktab', 'nh_uldltab');
var menu_headers_init = new Array ('', '', '', '', 'corpses', 'alchemy', '', 'prefs', 'feedback', '');

var sel_menu_header = -1;


var myxres = (screen) && (screen.width) ? screen.width : 0;		/* used here (pricing-gui) and alchemy. */



/* these are default defaults.. overwritten by our cookies */
var prefs = new Array();
/* unused till ... */
prefs['newbiemode'] = "yes";
prefs['priceidonly'] = "no";
/* here! */
prefs['pricetooltip'] = "yes";
prefs['showtextitems'] = "yes";
prefs['showcolorselector'] = "yes";
prefs['csscolor'] = "Matte Yellowish";

var prefs_dflt = new Array();
prefs_dflt['newbiemode'] = "yes";
prefs_dflt['priceidonly'] = "no";
prefs_dflt['pricetooltip'] = "no";
prefs_dflt['showtextitems'] = "yes";
prefs_dflt['showcolorselector'] = "yes";
prefs_dflt['csscolor'] = "Matte Yellowish";



var nonpriceid = new Array();
nonpriceid [nonpriceid.length] = "spbk_table";
nonpriceid [nonpriceid.length] = "menu_leftspan";
nonpriceid [nonpriceid.length] = "menu_rightspan";
nonpriceid [nonpriceid.length] = "download_span";
nonpriceid [nonpriceid.length] = "xl_span";
nonpriceid [nonpriceid.length] = "int_span";

var css_colchosen = "Matte Yellowish";
var css_coldefault = "Matte Yellowish";
var css_numcol = 10;
var css_colstart = 0;

var annoy_pic_max = 4;


var obj_csscolor = new Array();
var obj_sortname = new Array();
var obj_nameid   = new Array();




var nhhelper_niceinit_done = 0;

function helper_nice_init()
{
  if (typeof nhhelper_niceinit_done != "number") return;

  if (nhhelper_loaded == true) return;

  if (nhhelper_niceinit_done == 0)
    if (document.getElementById("resinfo"))
    {
      var el = document.getElementById("resinfo");
      el.innerHTML = "<br><br><br>";
	   nhhelper_niceinit_done++;
    }

  if (nhhelper_niceinit_done == 1)
    if (typeof menu_headerclick == "function")
    {
      menu_headerclick (document.getElementById("menuhead1"));
	   nhhelper_niceinit_done++;
    }

  if (nhhelper_niceinit_done == 2)
    if (typeof startup_feedback == "function")
    {
      startup_feedback();
	   nhhelper_niceinit_done++;
    }
  else nhhelper_niceinit_done++;		/* i.e. if no feedback is present, like currently ;-) */
	 
  if (nhhelper_niceinit_done == 3)
    if (typeof helper_init == "function")
    {
      helper_init();
	   nhhelper_niceinit_done++;
    }

  if (nhhelper_niceinit_done == 4)
    if (typeof clippy_init == "function")
    {
      clippy_init();
	   nhhelper_niceinit_done++;
    }
	 
  if (nhhelper_niceinit_done == 5)
    if (typeof corpses_init == "function")
    {
      corpses_init();
	   nhhelper_niceinit_done++;
    }
	 
  if (nhhelper_niceinit_done == 6)
    if (typeof initFileUploads == "function")
    {
      initFileUploads();
	   nhhelper_niceinit_done++;
    }

/*  alert ("initdone: '" +nhhelper_niceinit_done+ "'"); */
  if (nhhelper_niceinit_done >= 7) nhhelper_loaded = true;
  else window.setTimeout("helper_nice_init();", 50);
}






function helper_init()
{
  var annoyance = new Array();
  annoyance[annoyance.length] = "a verbose help for nethack shopping (and much more)";
  annoyance[annoyance.length] = "Your number one stop for nethack help (well not really, but it sounds nice :P)";
  annoyance[annoyance.length] = "This line for rent.";
  annoyance[annoyance.length] = "Going stronger since 2005.";
  annoyance[annoyance.length] = "Leave me alone.. I'm busy here, can't you see?";
  annoyance[annoyance.length] = "Finally a fruit of perfection (or why no feedback?)";
  annoyance[annoyance.length] = "Join us at irc.freenode.net, channel #nethack .";
  annoyance[annoyance.length] = "See you on nethack.alt.org .";
  annoyance[annoyance.length] = "Did you notice the layout is optimized for 1280x1024? ;)";
  annoyance[annoyance.length] = "<Eidolos> Because we can't all be marvin. (Requested)";
  annoyance[annoyance.length] = "Did you know you can simply hover over the price results to update the tooltip?";
  annoyance[annoyance.length] = "Did you know that the 'x' in the clippy helper doesn't turn it off permanently?";
  annoyance[annoyance.length] = "Check out the preferences. You can change the shown color scheme there, too.";
  annoyance[annoyance.length] = "Don't like the available color schemes ? Create your own and upload it :)";
  annoyance[annoyance.length] = "Running the helper on your computer in Internet Explorer only works if you allow active scripting!";

  // set blah randomly
  var el = document.getElementById("blaspan");
  el.innerHTML = annoyance[Math.round(Math.random()*annoyance.length -.5)];
  // clear res window because of the pics
  var el = document.getElementById("resinfo");
  el.innerHTML = "";

  /*
  {
    for (var i=css_colstart; i < css_numcol+css_colstart; i++)
    {
      document.getElementsByTagName('link')[i].disabled = ((i-css_colstart == css_coldefault) ? false : true);
    }
  }
*/
  /* fill the document.css_selector.sel_css with our filenames (partially) */
  var x = get_css_links();
  obj_csscolor = x['objs'];
  obj_sortname = x['sortnames'];
  obj_nameid = x['ids'];

  /* and fill the select box */
  gui_clearselect (document.css_selector.sel_css);
  var cnt = 0;
  for (var entry in obj_sortname)
  {
    var fname = obj_sortname[entry];
	 var id = obj_nameid[fname];
	 var obj = obj_csscolor[id];
    document.css_selector.sel_css[cnt++] = new Option (fname, id, ((fname == css_coldefault) ? true : false), ((fname == css_coldefault) ? true : false));
  }

  /* if it's mozilla  disable all stylesheets except the default (last) one */
  if (document.getElementsByTagName)
  {
    for (var fname in obj_nameid)
	 {
	   var id = obj_nameid[fname];
	   obj_csscolor[id].disabled = (( fname == css_coldefault ) ? false : true);
	 }
  }

  /* and set color as saved in cookie */
  css_colchosen = cookie_getset ("csscolor", "", css_coldefault);
  changeCSS (obj_nameid[css_colchosen]);

  if (document.location.href.indexOf ("\/nh-helper-dev\/") >= 0)
  {
    var el = document.getElementById ("devcry");
	 if (el)
	 {
	   _show_element (el, (0==0));
      var cur_annoypic = hsp_parseint(Math.random(annoy_pic_max) * (annoy_pic_max-1)) +1;
		var imgel1 = document.getElementById("img_annoying1");
		var imgel2 = document.getElementById("img_annoying2");
		if ((imgel1) && (imgel2))
		{
		  imgel1.src = imgcommon +"annoy_uc"+cur_annoypic+".gif";
		  imgel2.src = imgcommon +"annoy_uc"+cur_annoypic+".gif";
		}
	 }
  }

  for (var i in prefs)
  {
    if (i != "")
	 {
	   prefs[i] = cookie_getset(i, "", prefs[i]);
	 }
  }
 
  var myxres = get_xres();

  var mylinuxfftest = /Mozilla.*X11.*Linux.*Firefox/.test(navigator.userAgent);
  var mylinuxoperatest = /Opera.*X11.*Linux/.test(navigator.userAgent);

  var wordtoadd = "";
  if ((mylinuxfftest == true) || (mylinuxoperatest == true))
  {
    wordtoadd = "linuxfirefox";
  }
  if (ie == true)
  {
    wordtoadd = "ie";
  }

  if (myxres == 1280)
  {
    myxres = "";
	 if (ie == true) wordtoadd = "";
  }
	 
  var els = document.getElementsByTagName("select");
  if (els)
  {
    for (var i=0; i <= els.length; i++)
    {
      if ((els[i]) && (els[i].name.substr (0,6) == "potion"))
      {
        els[i].className = "forms formsalchemy" +wordtoadd+myxres+ " formsbgcol formsfgcol formsborder";
      }
		if ((els[i]) && (els[i].name.substr (0,6) == "corpse"))
		{
		  els[i].className = "forms formscorpse" +wordtoadd+myxres+ " formsbgcol formsfgcol formsborder";
		}
    }
  }

  update_allprefs();
}



function get_xres()
{
  var res = new Array();
  res['screen'] = (screen) && (screen.width) ? screen.width : 0;
  res['doc'] = 0;
  if (nn4 || moz) res['doc'] = (window) && (window.innerWidth) ? window.innerWidth : 0;
  if (ie)
  {
    res['doc'] = document.body.clientWidth;
  }
  
  var retx = 0;
  if ((res['screen'] - ((ie)?4:0) - res['doc']) == 0)			/* if we have fullscreen window */
  {
    retx = res['screen'];
  }
  else																		/* else find nearest size that doesn't cause redrawing in alchemy/corpse */
  {
    if (res['doc'] > 1207)
	 {
	   retx = 1280;
	 }
	 else if (res['doc'] > 1105)
	 {
	   retx = 1152;
	 }
	 else
	 {
	   retx = 1024;
	 }
  }
  /* alert (retx +" @ " +res['doc']+ " => " +retx); */
  return (retx);
}




var W3CDOM = (document.createElement && document.getElementsByTagName);

var cssupload_old_fname = "";
/* save clicked once after page load.. in case the browser decides to insert former stuff into the upload box which triggers onChange although the user did nothing */
var cssupload_clicked_already = false;


function initFileUploads()
{
	if (!W3CDOM) return;
	var fakeFileUpload = document.createElement('div');
	fakeFileUpload.className = 'fakefile';
	fakeFileUpload.appendChild(document.createElement('input'));
	var image = document.createElement('img');
	image.src='imgs/common/button_select.gif';
	fakeFileUpload.appendChild(image);
	var x = document.getElementsByTagName('input');
	for (var i=0;i<x.length;i++)
	{
		if (x[i].type != 'file') continue;
		if (x[i].parentNode.className != 'cssfileul') continue;
		x[i].className = 'file hidden';
		var clone = fakeFileUpload.cloneNode(true);
		x[i].parentNode.appendChild(clone);
		x[i].relatedElement = clone.getElementsByTagName('input')[0];
		x[i].onchange = x[i].onmouseout = function () {
			this.relatedElement.value = this.value;
			if ((cssupload_clicked_already == true) && (cssupload_old_fname != this.value))		/* dont resubmit the last file we submitted already */
			{
			  if (this.form.submit)
			  {
			    this.form.submit();
			  }
			  else
			  {
             var foo = find_accompanying_form_oldschool (this);
			    if (foo.submit) foo.submit();
			  }
			  cssupload_old_fname = this.value;
			}
		}
	}
}



function find_accompanying_form_oldschool (el)
{
  var forms = document.getElementsByTagName ("FORM");
  if ((forms) && (forms.length > 0))
  {
    for (var i=0; i < forms.length; i++)
	 {
	   var f = forms[i];
	   if ((f.elements) && (f.elements.length > 0))
		{
	     for (var j=0; j < f.elements.length; j++)
		  {
		    if (f.elements[j] == el) return (f);
		  }
		}
	 }
  }
  return (-1);
}




function get_css_links()
{
  var linklist;
  if (document.getElementsByTagName)
  {
    linklist = document.getElementsByTagName("link");
  }
  else if (document.all)
  {
    linklist = document.all.tags("link");
  }
  else   /* sorry no go */
  {
    alert ("Report to HiSPeed how you got here (get_css_links: no tagname list).");
  }

  /* can't easily sort a collection of elements.. fun fun! */
  var retarr_id = new Array();
  var retarr_sortname = new Array();
  var retarr_obj = new Array();
  for (var i=css_colstart; i < css_colstart + css_numcol; i++)
  {
    if (linklist[i])
	 {
      var foo = linklist[i].href;
      var fname = foo.substring(foo.lastIndexOf("/nh-colors-")+11, foo.lastIndexOf(".css"));   fname = fname.replace (/_/, " ");
      retarr_id [fname] = i;
		retarr_obj [i] = linklist[i];
		retarr_sortname [retarr_sortname.length] = fname;
	 }
  }

  retarr_sortname.sort();

  var foo = new Array();
  foo['ids'] = retarr_id;
  foo['objs'] = retarr_obj;
  foo['sortnames'] = retarr_sortname;

  return (foo);
}


function changeCSS (reqid)
{
  for (var fname in obj_nameid)
  {
    var id = obj_nameid[fname];
    var obj = obj_csscolor[id];

    if (obj)    /* never check for existance of obj.disabled via (obj.disabled), but typeof(obj.disabled) != "undefined" ... *sigh* i want that hour of my life back now!!!11oneoneleven :) */
    {
	   obj.disabled = (( id == reqid ) ? false : true);

		if (id == reqid)
		{
		  css_colchosen = fname;
        set_selectedindex_css(fname);
		  cookie_getset ("csscolor", css_colchosen, css_colchosen);
		}
    }
  }

}



function set_selectedindex_css (fname)
{
  for (var i=0; i < obj_sortname.length; i++)
  {
    if (obj_sortname[i] == fname)
	 {
      document.css_selector.sel_css.selectedIndex = i;
		break;
	 }
  }
}










var ie_workaround = 0;

function permanent_tooltip(price, forceshowing)
{
  if (prefs['pricetooltip'] != "yes") return;
  if (!forceshowing) forceshowing = 0;

  ie_workaround = 1;
  if (forceshowing == 1)
  {
	 var to = document.getElementById ("dhtmltooltip");
	 if (to)
	 {
	   var butt = document.getElementById("nh_getprice");
      var selx  = gettipx(butt);
	   var sely  = gettipy(butt);
      var selsx = gettipsx(butt);
		var selsy = gettipsy(butt);
	   var selxs = selx;   var selxe = selx+selsx;
      var selys = sely;   var selye = sely+selsy;

		_show_element (to, (0==0));
	 }
	 
    _show_tooltip  (price);
	 adjust_tipobj (price);

    if (to)
	 {
      to.style.top = selys-10 - gettipsy(to) - ((ie) ? 10 : 0);
	   to.style.left = hsp_parseint(selxs + selsx/2 - (tooltip_width / 2));
	 }
	
	 if (ie) window.setTimeout ("hide_selects()", 50);

	 tooltip_permanent = 1;
    tooltip_notmove = 1;
  }

  else

  {
    if (enabletip)
    {
      if (tooltip_permanent == 1)
      {
        tooltip_permanent = 0;
	     tooltip_notmove = 0;
        ie_workaround = 0;				/* allow hiding of the tooltip here */
        hide_tooltip();
      }
      else
      {
        show_tooltip(price);
	     tooltip_permanent = 1;
        tooltip_notmove = 1;
      }
    }
	 if (ie) window.setTimeout ("hide_selects()", 50);
  }
  
  ie_workaround = 0;
}



function reset_tooltip()		/* a more forceful version of hide_tooltip() */
{
  tooltip_notmove = 0;
  tooltip_permanent = 0;
  hide_tooltip();
  clippy_setpos (clippy_lastchosenpos, 0);			/* reset current selection */
  hide_selects();
}



function hide_tooltip()
{
  if ((prefs['pricetooltip'] != "yes") || (ie_workaround == 1)) return;		/* stop hiding while permanent_tooltip() is running */

  if (tipobj == null)
  {
    if (ie||ns6)
    {
      tipobj = (document.all ? document.all["dhtmltooltip"] : (document.getElementById ? document.getElementById("dhtmltooltip") : "") );
    }
  }

  if ((enabletip) && (tooltip_permanent == 0))			/* yep we do want && here */
  {
    hideddrivetip();
  }
} /* end hide_tooltip */





function hide_spbk_tooltip()
{
  /* ie workaround not needed here */
  if (tipobj == null)
  {
    if (ie||ns6)
    {
      tipobj = (document.all ? document.all["dhtmltooltip"] : (document.getElementById ? document.getElementById("dhtmltooltip") : "") );
    }
  }
  
  if ((enabletip) || (tooltip_permanent == 0))			/* yep we do want || here */
  {
    hideddrivetip();
  }
}



/***********************************************
* Cool DHTML tooltip script- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

/* was: xoffset -60, yoffset 20 */
var offsetxpoint=-Math.floor(tooltip_width/2); /* Customize x offset of tooltip */
var offsetypoint=20; /* Customize y offset of tooltip */
var ie=document.all;
var ns6=document.getElementById && !document.all;
var enabletip=false;
var tipobj = null;





function ietruebody()
{
  return ((document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body);
}

function ddrivetip(thetext, thewidth)
{
  if (ns6||ie)
  {
/*    if (typeof thecolor!="undefined" && thecolor!="") tipobj.style.backgroundColor=thecolor; */
    if ((thewidth) && (thewidth != 0)) tipobj.style.width=thewidth+"px";
    if ((thetext) && (thetext != "")) tipobj.innerHTML=thetext;
    enabletip=true;
/*
	 if ((tipobj.style.visibility == "hidden") || (tipobj.style.display == "none"))
	 {
	   tipobj.style.visibility = "visible";
	   tipobj.style.display = "";
	 }
*/	 
	 tipobj.onmousedown = getmousedown;
	 tipobj.onmouseup   = getmouseup;
    return false;
  }
}


function getcurx(e)    { return ((ns6) ? e.pageX : event.clientX+ietruebody().scrollLeft); }
function getcury(e)    { return ((ns6) ? e.pageY : event.clientY+ietruebody().scrollLeft); }
function gettipy(el)   { if (el != null) { return ( findPosY(el) ); } }
function gettipx(el)   { if (el != null) { return ( findPosX(el) ); } }
function gettipsx(el)  { if (el != null) { return ((ns6) ? el.offsetWidth : el.offsetWidth); } }
function gettipsy(el)  { if (el != null) { return ((ns6) ? el.offsetHeight : el.offsetHeight); } }
function gettippar(el) { if (el != null) { return ((ns6) ? el.parent : el.offsetParent); } }



if (document.layers) document.captureEvents (Event.MOUSEMOVE);  /* NN4 */

document.onmousemove = function (e)
{
/*if (enabletip) alert ("perm? " +((tooltip_permanent)?"yes":"NO")+ ", notmove? " +((tooltip_notmove)?"yes":"NO"));*/
  if (enabletip && (tooltip_notmove == 0))
  {
    var curX=getcurx(e);
    var curY=getcury(e);
/*	 dbg += "set tip 1 from " +curY+","+curX+"\n"; */
    /* Find out how close the mouse is to the corner of the window */
    var rightedge=ie&&!window.opera? ietruebody().clientWidth-event.clientX-offsetxpoint : window.innerWidth-e.clientX-offsetxpoint-20;
    var bottomedge=ie&&!window.opera? ietruebody().clientHeight-event.clientY-offsetypoint : window.innerHeight-e.clientY-offsetypoint-20;

    var leftedge= ((offsetxpoint<0)? offsetxpoint*(-1) : -1000);

	 if (tooltip_permanent == 0)
	 {
/*	   dbg += "non permanent tip mode\n"; */
      /* if the horizontal distance isn't enough to accomodate the width of the context menu */
/*
      if (rightedge<tipobj.offsetWidth)
		{
        //move the horizontal position of the menu to the left by it's width
        tipobj.style.left=ie? ietruebody().scrollLeft+event.clientX-tipobj.offsetWidth+"px" : window.pageXOffset+e.clientX-tipobj.offsetWidth+"px";
		  dbg += "rightedge < tip-offsetwidth\n";
		}
      else if (curX<leftedge)
		{
        tipobj.style.left="5px";
		  dbg += "curx < leftedge\n";
		}
      else
*/
		{
        /* position the horizontal position of the menu where the mouse is positioned */
        tipobj.style.left=curX+offsetxpoint+"px";
/*		  dbg += "else\n"; */
		}
		
      /* same concept with the vertical position */
      if (bottomedge<tipobj.offsetHeight)
        tipobj.style.top=ie? ietruebody().scrollTop+event.clientY-tipobj.offsetHeight-offsetypoint+"px" : window.pageYOffset+e.clientY-tipobj.offsetHeight-offsetypoint+"px";
      else
        tipobj.style.top=curY+offsetypoint+"px";

      tipobj.style.display="";
      tipobj.style.visibility="visible";
	 }
	 else				/* is permanent, thus adjust only from diff from last known pos */
	 {
	   var curx = getcurx(e);
	   var cury = getcury(e);
		var tipx = gettipx(tipobj);
		var tipy = gettipy(tipobj);
		var tipsx = gettipsx(tipobj);
		var tipsy = gettipsy(tipobj);

/*		dbg += "permanent tip mode\n"; */

      /* XXX IE/Konqueror (not mozilla!) doesn't send the mouseup event when cursor exceeds min top of viewport => stop. */
/*		if (((tipy > cury) || (tipx > curx) || (tipx+tipsx < curx) || (tipy+tipsy < cury))) */
		if ((cury < 0) || (curx < 0))
		{
/*		  dbg += "stopping drag for IE/Konq with tip " +tipy+","+tipx+" ;; cur " +cury+","+curx+"\n"; */
		  getmouseup(null);
		  return;
		}

		if ((lastx != -1) && (lasty != -1))		/* only do sth if we got a last pos */
		{
/*		  dbg += "set tip 2 from " +tipy+","+tipx+" by "+(cury-lasty)+","+(curx-lastx); */
		  
		  var newy = tipy + (cury-lasty);
		  var newx = tipx + (curx-lastx);
		  if (newy >= 0) tipobj.style.top = newy +"px";
		  if (newx >= 0) tipobj.style.left = newx + "px";
/*		  dbg += " to current " +gettipy(tipobj)+ ", "+gettipx(tipobj)+"\n"; */
		}
		
		lastx = curx;
		lasty = cury;
		
	 }

	 hide_selects();
  }

}




function hideddrivetip()
{
  if (ns6||ie)
  {
    enabletip=false;
    tipobj.style.display="none";
    tipobj.style.visibility="hidden";
    tipobj.style.top="-1000px";
    tipobj.style.backgroundColor='';
/*    tipobj.style.width='0px'; */
  }
}


function toggle_checkbox(el, what)
{
  var state = false;
  if (el)
  {
    if (what == -1) el.checked = (el.checked == true) ? false : true;
	 else el.checked = what;
  }
  state = el.checked;
  return (state);
}


function togglenotmove()
{
  if (enabletip && (tooltip_permanent == 1))
  {
    tooltip_notmove = (tooltip_notmove == 1 ? 0 : 1);
  }
}



function getmousedown(e)
{
  var curx= getcurx(e);   var cury = getcury(e);
  var elid="";
  if (ie) e = window.event;

  /* we can't check the existance of event (mozilla) or window.event (IE5+) without bailing out?! WTF?! */
  var gotourtarget = (0==1);
  if ((nn4) || (moz)) gotourtarget = ((e) && (e.target) && (e.target.id) && (e.target.id == "dhtml_movebar"));
  if (ie) gotourtarget = ((e) && (e.srcElement) && (e.srcElement.id) && (e.srcElement.id == "dhtml_movebar"));

  if ((gotourtarget) && enabletip && (tooltip_permanent == 1))
  {
/*    dbg += "mouse down " +cury+ "," +curx+ "\n"; */
	 
    lastx = curx;
	 lasty = cury;
    tooltip_notmove = 0;
  }
}

function getmouseup(e)
{
  var curx = -1;    var cury = -1;
  if (e != null)
  {
    curx = getcurx(e);	cury = getcury(e);
  }

  if (enabletip && (tooltip_permanent == 1))
  {
/*    dbg += "mouse up " +cury+ "," +curx+ "\n"; */
    tooltip_notmove = 1;
	 lastx = -1;
	 lasty = -1;
  }
}


function adjust_tipobj(price)
{
  var tip_posx = gettipx(tipobj);
  var tip_posy = gettipy(tipobj);
  var tip_sizex = gettipsx(tipobj);
  var tip_sizey = gettipsy(tipobj);

  var adjusted = false;


  if (tip_posy < 0)		/* pos too high */
  {
/*    var par_sizey = gettipsy (gettippar(tipobj));
//    if (tip_sizey > par_sizey)	// too big window to show on screen
//	 {
*/
	   var last_shown = "";
	   for (qwer in tooltip_currentlyshown_itemclasses)
		{
		  if (tooltip_currentlyshown_itemclasses[qwer] == true)  last_shown = qwer;
		}
		tooltip_currentlyshown_itemclasses[last_shown] = false;

		adjusted = true;
/*	 } */

	 tipobj.style.top = 0;
  }

  if (adjusted) _show_tooltip(price);
  else
  {
    if (adjust_tooltip != 0)
	 {
	   window.clearInterval (adjust_tooltip);
		adjust_tooltip = 0;
	 }
    adjust_tooltip_running = false;
  }
  
  return (adjusted);
}






function hide_selects()
{
  var tipx = gettipx(tipobj);
  var tipy = gettipy(tipobj);
  var tipsx = gettipsx(tipobj);
  var tipsy = gettipsy(tipobj);
  var tipxs = tipx;   var tipxe = tipx+tipsx;
  var tipys = tipy;   var tipye = tipy+tipsy;

/*  var dbg = "hide_selects:<br>\n";
    dbg += "tipy " +tipy+ ", tipx "+tipx +", tipsy "+tipsy+", tipsx "+tipsx+" => tipxs " +tipxs+ ", tipxe "+tipxe+"<br>\n";
*/

  var tiphidden = ((tipobj) && (tipobj.style.visibility == 'hidden'));

  var shown_alch = (document.getElementById("nh_alchemytab").style.display != "none");
  var shown_corps = (document.getElementById("nh_corpsestab").style.display != "none");

  for (var i=0; i < selects.length; i++)
  {
    var sel = selects[i];
    var selx  = gettipx(sel);
    var sely  = gettipy(sel);
    var selsx = gettipsx(sel);
    var selsy = gettipsy(sel);

    var selxs = selx;   var selxe = selx+selsx;
    var selys = sely;   var selye = sely+selsy;

/*    dbg += "checking " +i+ ". " +sel.name+ " ("+selys+","+selxs+" => "+selye+","+selxe+")<br>\n"; */

    var x_matched = x_matches (selxs, selxe, tipxs, tipxe);
    var y_matched = y_matches (selys, selye, tipys, tipye);

    var matched = ((!tiphidden) && (x_matched) && (y_matched));
    if (matched)                         /* hide this ! */
    {
		_show_element (sel, (0==1));
    }
    else											/* show this ! */
    {
      if (!
       ( (sel.name.indexOf("corpse") >= 0) && (!shown_corps) )
      ||
       ( (sel.name.indexOf("potion") >= 0) && (!shown_alch) )
 	   )
      {
        _show_element (sel, (0==0));
 	   }
    }
  }

/*  document.getElementById("clippy_debug").innerHTML = dbg; */
}


function x_matches (x1s, x1e, x2s, x2e)
{
  var gotmatch = true;
  if (x1s < x2s)
  {
    if (x1e < x2s)
	 {
	   gotmatch = false;
	 }
	 else
	 {
	   gotmatch = true;
	 }
  }
  else
  {
    if (x1s < x2e)
	 {
	   gotmatch = true;
	 }
	 else
	 {
	   gotmatch = false;
	 }
  }
  return (gotmatch);
}



function y_matches (y1s, y1e, y2s, y2e)
{
  var gotmatch = true;
  if (y1s < y2s)
  {
    if (y1e < y2s)
	 {
	   gotmatch = false;
	 }
	 else
	 {
	   gotmatch = true;
	 }
  }
  else
  {
    if (y1s < y2e)
	 {
	   gotmatch = true;
	 }
	 else
	 {
	   gotmatch = false;
	 }
  }
  return (gotmatch);
}







function findPosX(obj)
{
	var curleft = 0;
	if (obj.offsetParent)
	{
		while (obj.offsetParent)
		{
			curleft += obj.offsetLeft;
			obj = obj.offsetParent;
		}
	}
	else if (obj.x)
	{
		curleft += obj.x;
   }

	return curleft;
}


function findPosY(obj)
{
	var curtop = 0;
	if (obj.offsetParent)
	{
		while (obj.offsetParent)
		{
			curtop += obj.offsetTop;
			obj = obj.offsetParent;
		}
	}
	else if (obj.y)
	{
		curtop += obj.y;
   }


	return curtop;
}




function toggle_info(whi, what)
{
  /* XXX set to always show for the time being */
  what = 1;

  _hide_all_infos_and_tabs (whi);

  var selected = document.getElementById(whi +"info");
  var seldisp = selected.style.display;
  var selvis = selected.style.visibility;

  var shown = ((seldisp == "") && (selvis == "visible"));
  var doshow = (0==0);
  if (what == null)
    doshow = !shown;
  else if (what == 0)
    doshow = (0==1);
  else
    doshow = (0==0);

  /* show the bugger we were called for */
  _show_element (document.getElementById (whi +"info"), doshow);
  _show_element (document.getElementById (whi +"infoheader"), doshow);

  /* dont show corpsesinfo if not shown, corpsres if not filled */
  var show_corps = ((whi == "corpses") ? doshow : (0==1));
  var show_corpsres = show_corps;					/*((show_corps) && (document.corpseform2.corpsechosenmonster.length > 0));*/

  /* hide corpseres until it is filled with sth */
  _show_element (document.getElementById("corpseres"), show_corpsres);
  _show_element (document.getElementById("corpseresheader"), show_corpsres);
  
  if (whi == "appearance") setup_appearanceinfo (whi);
}


function _hide_all_infos_and_tabs (whi)
{
  /* unshow all non selected */
  for (var i=0; i < helper_infos.length; i++)
  {
    _show_element (document.getElementById(helper_infos[i] +"info"), (helper_infos[i] == whi));
    _show_element (document.getElementById(helper_infos[i] +"infoheader"), (helper_infos[i] == whi));
  }
  
  /* unshow all non selected */
  for (var i=0; i < helper_tabs.length; i++)
  {
    _show_element (document.getElementById("nh_" +helper_tabs[i] +"tab"), (helper_tabs[i] == whi));
  }
}


function toggle_tab(whi, what)
{
  if (whi == "") return;

  _hide_all_infos_and_tabs (whi);

  var selected = document.getElementById("nh_" +whi +"tab");
  var seldisp = selected.style.display;
  var selvis = selected.style.visibility;

  var shown = ((seldisp == "") && (selvis == "visible"));
  var doshow = (0==0);
  if (what == null)
    doshow = !shown;
  else if (what == 0)
    doshow = (0==1);
  else
    doshow = (0==0);

  /* show the bugger we were called for */
  _show_element (document.getElementById ("nh_" +whi+ "tab"), doshow);

  _show_element (document.getElementById ("resinfo"), doshow);
  _show_element (document.getElementById ("resinfoheader"), doshow);

  /* now the starting stuff if needed */
  if (whi == "alchemy") alchemy_updatelines();
  else if (whi == "corpses") hide_selects();
  else if ((whi == "feedback") && (doshow)) setup_feedback();
  else if ((whi == "prefs") && (doshow)) setup_prefs();
  
}



function _show_element (el, what)
{
  if (el)
  {
	 el.style.visibility = (what == (0==0)) ? "visible" : "hidden";
	 el.style.display    = (what == (0==0)) ? "inline" : "none";
  }
}



function setup_prefs()
{
/*
  if ((prefs) && (prefs['newbiemode'])) toggle_checkbox (document.prefform.pref_newbiemode, (prefs['newbiemode'] == "yes"));
  if ((prefs) && (prefs['priceidonly'])) toggle_checkbox (document.prefform.pref_priceidonly, (prefs['priceidonly'] == "yes"));
*/
  if ((prefs) && (prefs['pricetooltip'])) toggle_checkbox (document.prefform.pref_pricetooltip, (prefs['pricetooltip'] == "yes"));
  if ((prefs) && (prefs['showtextitems'])) toggle_checkbox (document.prefform.pref_showtextitems, (prefs['showtextitems'] == "yes"));
  if ((prefs) && (prefs['showcolorselector'])) toggle_checkbox (document.prefform.pref_showcolorselector, (prefs['showcolorselector'] == "yes"));
}


function toggle_pref (what, setcheck)
{
  var el = -1;

  if (what == "newbiemode")
  {
    el = document.prefform.pref_newbiemode;
	 var gotstate = getset_checkbox (el, setcheck);
    prefs['newbiemode'] = gotstate;
  }
  else if (what == "priceidonly")
  {
    el = document.prefform.pref_priceidonly;
	 var gotstate = getset_checkbox (el, setcheck);
    prefs['priceidonly'] = gotstate;
  }
  else if (what == "pricetooltip")
  {
    el = document.prefform.pref_pricetooltip;
	 var gotstate = getset_checkbox (el, setcheck);
	 reset_tooltip();
    prefs['pricetooltip'] = gotstate;
  }
  else if (what == "showtextitems") 
  {
    el = document.prefform.pref_showtextitems;
	 var gotstate = getset_checkbox (el, setcheck);
    prefs['showtextitems'] = gotstate;
  }
  else if (what == "showcolorselector")
  {
    el = document.prefform.pref_showcolorselector;
	 var gotstate = getset_checkbox (el, setcheck);
    prefs['showcolorselector'] = gotstate;
  }
  else if (what == "resetaskforupdate")
  {
    cookie_getset ("askedforversion", 0, 0);		/* reset askedforversion */
	 alert ("Updatecheck reset!");
  }
  else
  {
    alert ("MSG HiSPeed@Freenode and tell him how you ended up here (toggle_pref, what '"+what+"', el '" +el+ "')");
  }

  if (el != -1)
  {
    var setval = "";
    if (prefs[what]) setval = ((prefs[what] == true) ? "yes" : ((prefs[what] == false) ? "no" : prefs[what]));
	 if ((clippy_dontsavenewbiemode == true) && (what == "newbiemode")) setval = "";
	 if (setval != "")
	 {
      cookie_getset (what, setval, setval);
	 }
	 clippy_dontsavenewbiemode = false;
	 update_allprefs();
  }
}



function reset_prefs()
{
  for (var i in prefs_dflt)
  {
    prefs[i] = prefs_dflt[i];
	 cookie_getset (i, prefs[i], prefs[i]);
  }
  setup_prefs();
  update_allprefs();
}


function update_allprefs()
{
  update_colorselector();
  update_priceidonly();
  clippy_update();
}



function getset_checkbox (el, setcheck)
{
  var gotstate = false;
  if (setcheck == 1) gotstate = toggle_checkbox (el, -1);
  else gotstate = el.checked;
  var s = "gotstate  "+gotstate+" => ";
  gotstate = ((gotstate == true) ? "yes":"no");
  s += gotstate;
  return (gotstate);
}


function update_priceidonly()
{
  /* XXX workaround.. just in case we want it back lateron */
  prefs['priceidonly'] = "no";

  for (var i=0; i < nonpriceid.length; i++)
  {
    if (nonpriceid[i] != "")
    {
	 var el = document.getElementById (nonpriceid[i]);
    if (el)
    {
      el.style.visibility = ((prefs['priceidonly'] == "no") ? "visible" : "hidden");
      el.style.display    = ((prefs['priceidonly'] == "no") ? "" : "none");
    }
	 }
  }
}


function update_colorselector()
{
  var el = document.getElementById("colsel");
  if (el)
  {
    el.style.visibility = ((prefs['showcolorselector'] == "yes") ? "visible" : "hidden");
    el.style.display    = ((prefs['showcolorselector'] == "yes") ? "" : "none");
  }
}


function cookie_getset (name, value, defaultvalue)
{
  var tmp = getCookie(name);
  var found_cookie = false;
  found_cookie = ((tmp) && (tmp != "") && (tmp != "null")) ? true : false;

  var doset = false;
  if (found_cookie == false) doset = true;
  if ((found_cookie == false) && (value == "")) value = defaultvalue;
  if (value != "") doset = true;

  if (doset)
  {
    var foobared = new Date();  foobared.setFullYear (foobared.getFullYear()+5);
    setCookie(name, value, foobared);
	 tmp = value;
  }
  else value = tmp;

  return (tmp);
}




function setup_appearanceinfo(whi)
{
  if (! appearanceinfo_setup)
  {
    var first_row = (0==0);
	 
    var textEl = document.getElementById(whi+"infocell");
    var str = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";

    var itemclasses = new Array();
	 for (var foo in itemsinfo)
	 {
	   itemclasses[itemclasses.length] = foo;
	 }
    itemclasses.sort();
	 
    for (var j=0; j < itemclasses.length; j++)
    {
	   var foo = itemclasses[j];
	   if (!first_row)
		{
		  str  += "<tr height='2'><td height='2' colspan='5'></td></tr>\n";
		}
      str    += "<tr><td colspan='5' class='itemhead resfgcol'><u>Appearance for " +foo+ "</u></td></tr>\n";
		str  += "<tr height='3'><td height='3' colspan='5'></td></tr>\n";

      for (var i = 0; i < itemsinfo[foo].length; i+=2)
      {
        var curentries = itemsinfo[foo][i].split ("\|");
		  var curentries_next = new Array ("", "");

        var mytmpimage = "";
        if (prefs['showtextitems'] == false)
        {
          mytmpimage = "<img src='" +imgnethack+ curentries[0]+ "' alt='" +curentries[1]+ "' width='8' height='12'>";
        }
        else
        {
          var searchy = curentries[0].substr( curentries[0].indexOf("_")+1 );
			 if (searchy != "")
			 {
            var nhsymcol = "nhsym" +itemscolinfo [searchy];
            mytmpimage = "<span class='objsym " +nhsymcol+ "'><b>" +curentries[2]+ "</b></span>";
			 }
        }
		  
		  curentries[0] = "<table width='30' border='0' cellspacing='0' cellpadding='0' style='margin: 0px; padding: 0px;'><tr class='itemrow resfgcol' width='30'><td class='itemrow resfgcol' width='30' align='center'>"+mytmpimage+"</td></tr></table>";
		  curentries[1] = "<table border='0' cellspacing='0' cellpadding='4' style='margin: 0px; padding: 0px;'><tr class='itemrow resfgcol'><td align='center' class='itemrow resfgcol'> "+curentries[1]+ "</td></tr></table>";

		  if (itemsinfo[foo][i+1]) curentries_next = itemsinfo[foo][i+1].split ("\|");
		  
        mytmpimage = "";
        if (prefs['showtextitems'] == false)
        {
          mytmpimage = "<img src='" +imgnethack+ curentries_next[0]+ "' alt='" +curentries_next[1]+ "' width='8' height='12'>";
        }
        else
        {
          var searchy = curentries_next[0].substr( curentries_next[0].indexOf("_")+1 );
			 if (searchy != "")
			 {
            var nhsymcol = "nhsym" +itemscolinfo [searchy];
            mytmpimage = "<span class='objsym " +nhsymcol+ "'><b>" +curentries_next[2]+ "</b></span>";
			 }
        }
		  
		  if (curentries_next[0] != "")
		  {
		    curentries_next[0] = "<table width='30' border='0' cellspacing='0' cellpadding='0' style='margin: 0px; padding: 0px;'><tr width='30' class='itemrow resfgcol'><td width='30' class='itemrow resfgcol' align='center'>" +mytmpimage+ "</td></tr></table>";
		    curentries_next[1] = "<table border='0' cellspacing='0' cellpadding='4' style='margin: 0px; padding: 0px;'><tr class='itemrow resfgcol'><td align='center' class='itemrow resfgcol'> "+curentries_next[1]+ "</td></tr></table>";
		  }
		  else
		  {
		    curentries_next[0] = curentries_next[1] = "";
		  }
		  
	     str += "<tr>\n";
		  str += "  <td width='2%'></td>\n";
		  str += "  <td width='18' align='center' valign='middle' style='background-color: " +app_picbg+ "'>" +curentries[0]+ "</td>\n";
		  str += "  <td width='48%' valign='top'>" +curentries[1]+ "</td>\n";
		  var blackbg = ((curentries_next[0] != "") ? " style='background-color: "+app_picbg+ "'" : "");
		  str += "  <td width='18' align='center' valign='middle'" +blackbg+">" +curentries_next[0]+ "</td>\n";
		  str += "  <td width='44%' valign='top'>" +curentries_next[1]+ "</td>\n";
		  str += "</tr>\n";
      }
		
		first_row = (0==1);
    }

    str += "<tr>\n";
    str += "  <td colspan='5' width='100%' height='5'></td>\n";
    str += "</tr>\n";
    str    += "</table>\n";

    textEl.innerHTML = str;
	 appearanceinfo_setup = (0==0);
  }
} // end func setup_appearanceinfo




function hsp_cssinfo (el)
{
  if (el)
  {
    var str="";
    for (var k in el)
	 {
	   var t = typeof(el[k]);
	   if ((t != "object") && (t != "code") && (t != "function") && (k != "innerHTML") && (k != "outerHTML") && (k != "textContent"))
		{
	     str += k + " (" +typeof(el[k])+ ") => " +el[k]+" || ";
		}
	 }
	 alert(str);
  }
}



function gui_clearselect (f)
{
  /* hSP: doing it backwards works.. doing it forward (counting 0 to 511 with (f[i]) check doesn't all the time... wtf.... */
  for (var i = f.length-1; i >= 0; i--)
  {
    if (f[i])  f.options[i] = null;
  }
} // end func gui_clearselect






function cookie_updatecsscolor()
{
  if (css_colchosen == "") css_colchosen = css_coldefault;

  var foobared = new Date();  foobared = new Date (foobared.getTime() + 24*365.25 * 5);    // + 5 years
  setCookie("csscolor", css_colchosen, foobared);
}





/* new design */

function menu_headerclick(el)
{
  var id = el.id;
  var myid = id.substr(id.length-1);
  if ((myid > 0) && (myid < menu_headers.length))
  {
    sel_menu_header = -1;
    reset_all_menuheaders ();
    el.className="winfgcol winbgcol menuhead menuheadsel menuheadselborder normalcursor";

	 /* show stuff for selection */
	 for (var i=1; i < menu_headers.length; i++)
	 {
	   el = document.getElementById (menu_headers[i]);
		if (el)
		{
		  if (i == myid)
		  {
		    /* show */
		    _show_element (el, (0==0));
			 /* and initialize if need be */
			 if (menu_headers_init[i] != "") toggle_tab (menu_headers_init[i], 1);
			 sel_menu_header = i;
		  }
		  else
		  {
		    _show_element (el, (0==1));
		  }
		}
    }
  }
}

function menu_hilight_mouseover(el)
{
  var id = el.id;
  var myid = id.substr(id.length-1);
  if ((myid > 0) && (myid < menu_headers.length))
  {
    reset_all_menuheaders();
	 if (sel_menu_header != myid) el.className="winfgcol winbgcol menuhead menuheadsel menuheadselborder pointatme";
  }
}

function menu_hilight_mouseout(el)
{
  reset_all_menuheaders();
}


function reset_all_menuheaders()
{
  for (var i=1; i < menu_headers.length; i++)
  {
    var el = document.getElementById("menuhead"+i);
	 if (el)
	 {
	   if (sel_menu_header != i)
		  el.className = "menuhead winbgfgcol winfgbgcol menuheadborder pointatme";
		else
		  el.className = "menuhead menuheadsel menuheadselborder winfgcol winbgcol menuheadborder normalcursor";
	 }
  }
}



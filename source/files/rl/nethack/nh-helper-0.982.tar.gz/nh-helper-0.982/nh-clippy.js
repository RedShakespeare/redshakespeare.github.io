
//
// Nethack Price Calculation
// (c) 2k5 by HiSPeed
//
// Offline usage and tinkering with the actual code is strictly allowed.
//
// Have fun.
//

// Clippy Mode AKA Newbie Mode with a few pointers to how the user has to use this page.

var clippy_width = 300;			// these two need to be inserted manually
var clippy_height = 56;			// until i find a way around it

var clippy_pos_1 = 0;			// default at array item no. 0
var clippy_pos_2 = 0;			// default at array's array item no. 0

var clippy_dontsavenewbiemode = false;

var clippy_maxtooltips = 1;

var clippy_lastchosenpos = -1;

var clippy_order = new Array();
clippy_order[0] = 'general';
clippy_order[1] = 'prices';
clippy_order[2] = 'spellbooks';						// leave this one out lateron.. just for debugging since most peeps will be interested in priceid
clippy_order[3] = 'results';

var clippy_items = new Array();

var cliptmp = new Array();
cliptmp[0] = 'nh_generalinfo1';						// 0		0			00
cliptmp[1] = 'nh_generalinfo2';						// 1		1			01
clippy_items['general'] = cliptmp;

var cliptmp = new Array();
cliptmp[0] = 'nh_prices1';								// 2a					10
cliptmp[1] = 'nh_prices2';								// 2b					11
cliptmp[2] = 'nh_getprice';							// 3					12
clippy_items['prices'] = cliptmp;

var cliptmp = new Array();
cliptmp[0] = 'nh_spellbooks';							// 		2			20
cliptmp[1] = 'nh_getspbk';								//			3			21
clippy_items['spellbooks'] = cliptmp;

var cliptmp = new Array();
cliptmp[0] = 'nh_results';								//						30
clippy_items['results'] = cliptmp;					//	4		4


var clippy_help = new Array();
clippy_help[0] = new Array();
clippy_help[0][0] = new Array ("Fill out these stats according to the lowest line on your nethack screen.", "#000");
clippy_help[0][1] = new Array ("Change these settings according to your character.", "#000");
clippy_help[1] = new Array();
clippy_help[1][0] = new Array ("Choose what type of price you are searching for (usually 'Buy').", "#000");
clippy_help[1][1] = new Array ("Insert one or two prices for a _single_ item of what you wish to id.", "#000");
clippy_help[1][2] = new Array ("Click here to start the price calculation.", "#000");
clippy_help[2] = new Array();
clippy_help[2][0] = new Array ("Choose the spellbook's level and whether you do/don't wear lenses while reading.", "#000");
clippy_help[2][1] = new Array ("Click here to get the success probabilities for reading spellbooks on your XL/Int.", "#000");
clippy_help[3] = new Array();
clippy_help[3][0] = new Array();
clippy_help[3][0][1] = new Array ("Click the prices listed as possible hits to get a fixed view of the items. Drag'n'drop as you wish.", "#000");
clippy_help[3][0][2] = new Array ("Hover over the probabilites to find out the probability for bad reading effects.", "#000");




function clippy_gethelp (text, col)
{
  var doBorder = (col != "");
  var opacity = .75;
  var mh = 54;			// -2
  var mw = 161;			// -2
  var placeholder1 = "<img src='./imgs/common/empty.gif' width='1' height='1' border='0' alt=''>";
  var placeholder2 = "<img src='./imgs/common/empty.gif' width='" +mw+"' height='1' border='0' alt=''>";
  var placeholder3 = "<img src='./imgs/common/empty.gif' width='1' height='" +mh+ "' border='0' alt=''>";

  var foo = new Array();
  foo = clippy_getnextpos (clippy_pos_1, clippy_pos_2);
  var nextClippyPos1 = foo['a'];
  var nextClippyPos2 = foo['b'];
  
  var closebutton = "<span class='pointatme' onClick='javascript:clippy_turnofftemp()' onMouseOver=\"window.status='Deactivate newbiemode temporarily!'; return true;\" onMouseOut=\"window.status=''; return true;\"><img alt='Deactivate newbiemode temporarily!' src='./imgs/common/nh_close.gif' border='0' style='float: right' width='14' height='14'></span>";
  var nextstepbutton = "<a href='javascript:clippy_setpos(" +nextClippyPos1+ "," +nextClippyPos2+ ")'><img src='./imgs/common/check.gif' alt='Next step!' border='0' onMouseOver='window.status=\"Move to next step!\"; return true' onMouseOut='window.status=\"\"; return true' style='float: right' width='15' height='15'></a>";
  
  var borderstyle_inner = " class='clippy_tc clippy_bgcol tooltipopacity' style='padding: 2px 2px 2px 2px'";
  //; filter:alpha(opacity = " +(opacity*100)+ "); -moz-opacity:"+opacity+ "; opacity:" +opacity+";'";

  var str = "\
  <table width='" +(mw+2)+ "' height='" +(mh+2)+ "' cellspacing='0' cellpadding='0' border='0'>\
  <tr>\
    <td width='1' height='1'" + ((doBorder) ? " class='clippy_bgcol1'":"")+ ">" +placeholder1+ "</td>\
	 <td width='"+mw+"'" +((doBorder) ? " class='clippy_bgcol2'":"")+ ">" +placeholder2+ "</td>\
	 <td width='1' height='1'" +((doBorder) ? " class='clippy_bgcol2'":"")+ ">" +placeholder1+ "</td>\
  </tr>\
  <tr>\
    <td width='1' height='"+mh+"'" +((doBorder) ? " class='clippy_bgcol1'":"")+ ">" +placeholder3+ "</td>\
	 <td width='"+mw+"' height='"+mh+"'>\
	   <table width='100%' height='100%' cellspacing='0' cellpadding='0' border='0'" +borderstyle_inner+ ">\
		<tr height='100%' width='100%'>\
		  <td height='100%' style='padding: 2px 0px 2px 2px;'>" +closebutton +text+ nextstepbutton+  "</td>\
		</tr>\
		</table>\
	 </td>\
    <td width='1' height='"+mh+"'" +((doBorder) ? " class='clippy_bgcol2'":"")+ ">" +placeholder3+ "</td>\
  </tr>\
  <tr>\
    <td width='1' height='1'" + ((doBorder) ? " class='clippy_bgcol1'":"")+ ">" +placeholder1+ "</td>\
	 <td width='"+mw+"'" +((doBorder) ? " class='clippy_bgcol1'":"")+ ">" +placeholder2+ "</td>\
	 <td width='1' height='1'" +((doBorder) ? " class'clippy_bgcol2'":"")+ ">" +placeholder1+ "</td>\
  </tr>\
  </table>"; 
  
  return (str);
}



function clippy_init()
{
  clippy_pos_1 = 0;
  clippy_pos_2 = 0;
  clippy_update();
}



function clippy_update()
{
//  clippy_updatenewbiemode();							// set newbie cookie

  var updateworked = false;

  //clippy_update_debug();
  var curr_order = clippy_order[clippy_pos_1];
  
  for (var i=0; i <= 0; i++)
  {
    var suggpos = new Array();
    suggpos = clippy_getpos (clippy_pos_1, clippy_pos_2);
    suggpos['n'] = i;										// use clippy tooltip no. 0 for testing

    var tmphelp = "";   var tmpcol = "";
	 if ( ((clippy_lastchosenpos == 1) || (clippy_lastchosenpos == 2)) && (clippy_pos_1 == 3) )
	 {
	   tmphelp = clippy_help[3][0][clippy_lastchosenpos][0];
	   tmpcol = clippy_help[3][0][clippy_lastchosenpos][1];
	 }
	 else if ((clippy_help[clippy_pos_1]) && (clippy_help[clippy_pos_1][clippy_pos_2]))
	 {
	   tmphelp = clippy_help[clippy_pos_1][clippy_pos_2][0];
	   tmpcol = clippy_help[clippy_pos_1][clippy_pos_2][1];
	 }
	
	 suggpos['t'] = clippy_gethelp (tmphelp);
	 suggpos['c'] = tmpcol;

    if (clippy_show (suggpos))
	 {
	   updateworked = true;
	 }
  }

  clippy_dontsavenewbiemode = false;

  return (updateworked);
}




function clippy_update_debug()
{
  var str = "pos " +clippy_pos_1+ ", " +clippy_pos_2+ ": ";
  str    += clippy_order[clippy_pos_1] + ", ";
  str    += clippy_items[clippy_order[clippy_pos_1]][clippy_pos_2];
  var elem = document.getElementById ("clippy_debug");
  elem.innerHTML = str;
}


function clippy_getpos (pos, pos_substep)
{
  var elemname = clippy_items [ clippy_order[pos] ] [ pos_substep ];
  var elem;
  var suggx = -1;
  var suggy = -1;
  
  if (elemname)
  {
    elem = document.getElementById (elemname);
  }
  
  if (elem)
  {
    var elemx  = gettipx(elem);
    var elemy  = gettipy(elem);
    var elemsx = gettipsx(elem);
    var elemsy = gettipsy(elem);
    var elemxs = elemx;   var elemxe = elemx+elemsx;
    var elemys = elemy;   var elemye = elemy+elemsy;


	 if ((elemxe - elemxs > 0) && (elemye - elemys > 0))			// stupid check for validity
	 {
	   suggx = elemxe + 30;  //(elemxe - elemxs) / 2 - clippy_width / 2;
	   suggy = elemys + (elemye - elemys) / 2;
	 }

    clippy_tmp_top = hsp_parseint(suggy);
	 suggy -= gettipsy(elem) / 2;
	 
    suggx = hsp_parseint(suggx);
    suggy = hsp_parseint(suggy);
  }
  
  var retarr = new Array();
  retarr['x'] = suggx;	retarr['y'] = suggy;

  return (retarr);
}



var clippy_tmp_el = -1;
var clippy_tmp_top = -1;

function clippy_show (posarr)
{
  var showworked = false;
  
  var valid_posarr = ((posarr['x'] != -1) && (posarr['y'] != -1));

  if ((posarr['n'] < 0) || (posarr['n'] > clippy_maxtooltips))
  {
    alert ("Too many clippy tooltips supplied (n=" +posarr['n']+ ").\n\nPlease contact the author via the 'Feedback' link!");
  }
  else
  {
	 var elem = document.getElementById ("clippytooltip"+posarr['n']);
	 var helpelem = document.getElementById ("clippytooltip"+posarr['n']+"_help");

	 clippy_tmp_el = elem;
	 window.setTimeout ("clippy_adjust_clippy()", 1);

	 if ((elem) && (helpelem))
	 {
	   elem.style.top = posarr['y'];
	   elem.style.left = posarr['x'];

	   if ((prefs['newbiemode'] == "yes") && (valid_posarr))		// the latter to hide unused clippy tooltips
	   {
	     elem.style.display = "";
	     elem.style.visibility = "visible";
		  helpelem.innerHTML = posarr['t'];
        showworked = true;
	   }
	   else
	   {
	     elem.style.display = "none";
	     elem.style.visibility = "hidden";
		  helpelem.innerHTML = "";
	   }
/*		
		if (posarr['c'] == "")
		{
		  helpelem.style.backgroundColor = "";
		}
		else
		{
		  helpelem.style.backgroundColor = posarr['c'];
		}
*/
	 }
  }

  return (showworked);
}

function clippy_adjust_clippy()
{
  if (clippy_tmp_el)
  {
    /* adjust y pos for current clippy height */
    var tmpclipheight = gettipsy( clippy_tmp_el );
	 var foo = hsp_parseint (clippy_tmp_top - tmpclipheight/2 + 1);
	 clippy_tmp_el.style.top = foo +"px";
	 clippy_tmp_el = false;
  }
}


function clippy_setpos (pos1, pos2)
{
  if (pos1 != -1) clippy_pos_1 = pos1;		//  else  { clippy_pos_1 = clippy_lastchosenpos; }
  if (pos2 != -1) clippy_pos_2 = pos2;

  if (!clippy_update())
  {
    // reset clippy pos
	 clippy_pos_1 = 0;
	 clippy_pos_2 = 0;
	 clippy_update();
  }
}


function clippy_debug_nextpos()
{
  var foo = new Array();
  foo = clippy_getnextpos (clippy_pos_1, clippy_pos_2);
  clippy_pos_1 = foo['a'];
  clippy_pos_2 = foo['b'];

  clippy_update();
}

function clippy_getnextpos (pos1, pos2)
{
  var foo = new Array();
  
  pos2++;
  if (pos2 >= clippy_items[clippy_order[pos1]].length)
  {
    pos2 = 0;
	 pos1++;
    if (pos1 >= clippy_order.length) pos1 = 0;
  }
  
  if ((prefs['priceidonly'] == "yes") && (pos1 == 2) && (pos2 == 0))
  {
    pos1 = 0;
	 pos2 = 0;
  }

  foo['a'] = pos1;
  foo['b'] = pos2;
  
  return (foo);
}



function clippy_getnewbiemode()
{
  var newbiemode = true;
  var tmpnm = getCookie("clippymode");
  if ((tmpnm) && (tmpnm != "") && (tmpnm != "null"))
  {
    if (tmpnm == "no") newbiemode = false;
  }
  else
  {
	 if (! clippy_dontsavenewbiemode)
	 {
      var foobared = new Date();  foobared = new Date (foobared.getTime() + 24*365.25 * 5);    // + 5 years
      setCookie("clippymode", "yes", foobared);
	 }
  }

  if (document.prefform.pref_newbiemode)
  {
    document.prefform.pref_newbiemode.checked = newbiemode;
  }

  prefs['newbiemode'] = newbiemode;
}


// turns off clippy temporarily (doesnt save in cookie)
function clippy_turnofftemp()
{
  clippy_dontsavenewbiemode = true;
  toggle_pref ('newbiemode', 0);
}


function clippy_updatenewbiemode()
{
  if (prefs['newbiemode'])
  {
    var newbiemode = "yes";
	 if (prefs['newbiemode'] == false) newbiemode = "no";
	 if (! clippy_dontsavenewbiemode)
	 {
      var foobared = new Date();  foobared = new Date (foobared.getTime() + 24*365.25 * 5);    // + 5 years
      setCookie("clippymode", newbiemode, foobared);
	 }
  }
}







<html>
<body>
<?php

if (isset($nickname))
{
  $nickname = preg_replace ("/([^0-9a-zA-Z_\ ])/", "", $nickname);
}

$nickname = mktime() ."_".$nickname; 
if (isset($_FILES['foobar']))
{
  if ((is_uploaded_file ($_FILES['foobar']['tmp_name'])) and ($_FILES['foobar']['size'] < 100000))
  {
    rename ($_FILES['foobar']['tmp_name'], "/tmp/nh-color-schemes/$nickname.css");
	 echo "File saved under $nickname<br>\n";
  }
  else
  {
    echo "File size too big (> 100k) !<br>";
  }
}
else
{
    echo "File size too big (> 100k) !<br>";
}


?>
<!--Upload color scheme here:
<form action="./uploadscheme.php" enctype="multipart/form-data" method="POST">
<input type="hidden" name="MAX_FILE_SIZE" value="100000">
Nickname: <input type="text" name="nickname" value=""><br>
CSS: <input type="file" name="foobar"><br>
<input type="submit" value="click me"><br>
<br-->
</body>
</html>

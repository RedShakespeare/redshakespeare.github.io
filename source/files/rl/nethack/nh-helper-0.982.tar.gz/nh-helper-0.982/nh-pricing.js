
//
// Nethack Price Calculation
// (c) 2k5 by HiSPeed
//
// Offline usage and tinkering with the actual code is strictly allowed.
//
// Have fun.
//

//
// TODO:    None
//

// Done: add probabilities divided by negative effects for spellreading in a tooltip (moussambani)


// var clippy_bc1 = '#a5a5a5';    var clippy_bc2 = '#d5d5d7';
var app_picbg = '#000';
var item_picbg = app_picbg;


var gTriggerImmediateShowing = 0;
var gTriggerPrice = -1;


var load_mozinnerhtml = (0==1);

if (/Konqueror/.test(navigator.userAgent))
{
	/*  if (! document.body.innerHTML) alert ("no innerhtml");			// cant be used to check for availability of innerHTML (although it s there like in 3.4.2 => 3.4!) */ 
	
  /*
   * XXX   - add croak message on loading mozinnerhtml for konq to bug me about it.. changing ver nums and stuff
	*/

  var verreg = /Konqueror\/([\d\.]+);/;
  var ver = verreg.exec (navigator.userAgent)
  /* oldest known version with innerHTML: 3.4.2 */
  /* in 3.5 it croaks on loading mozinnerhtml */
  if (Number(ver[1]) < 3.5) load_mozinnerhtml = true;
}

if (/(Mozilla\/5\.0|Opera)/.test(navigator.userAgent))
{
  if (!/Firefox/.test(navigator.userAgent)) load_mozinnerhtml = (0==0);
}


if (load_mozinnerhtml)
{
  document.write('<script type="text/javascript" src="./mozInnerHTML.js"></sc' + 'ript>');
}


/*
 *  AND ANOTHER BROWSERCHECK in nh-pricing-gui.js for Mozilla.*X11.*Linux.*Firefox (changed alchemy select size to remedy stupid browser behaviour)
 */


var dbg = "";

var startup_done = 0;
var tooltip_frame = "ttPrice";
var tooltip_content = tooltip_frame +"_Content";
var tooltip_permanent = 0;
var tooltip_notmove = 0;

var appearanceinfo_setup = (0==1);

var first_generation = false;
var tooltip_currentlyshown_itemclasses = new Array();
var selects = document.getElementsByTagName("SELECT");

var adjust_tooltip = 0;
var adjust_tooltip_running = false;

var imgroot = "./imgs/";
var imgcommon = imgroot + "common/";
var imgnethack = imgroot + "nethack/";
var itemclass_open = "nh_folder_on.gif";
var itemclass_close = "nh_folder_off.gif";
var itemclass_entry = "nh_file.gif";
var itemclass_entrylast = "nh_file_last.gif";

var tooltip_width = 800;

var lastx = -1;
var lasty = -1;

var normod = 2;		// only give 50% while selling
var toumod = 3;
var surmod = 3;
var dunmod = 3;
var cantpaymod = 9;

var bookdelays = new Array();
bookdelays[1] = new Array();
bookdelays[1][0] = 1;				// minimum delay
bookdelays[1][1] = 3;				// maximum delay
bookdelays[2] = new Array();
bookdelays[2][0] = 2;
bookdelays[2][1] = 3;
bookdelays[3] = new Array();
bookdelays[3][0] = 1;
bookdelays[3][1] = 6;
bookdelays[4] = new Array();
bookdelays[4][0] = 4;
bookdelays[4][1] = 7;
bookdelays[5] = new Array();
bookdelays[5][0] = 6;
bookdelays[5][1] = 7;
bookdelays[6] = new Array();
bookdelays[6][0] = 6;
bookdelays[6][1] = 8;
bookdelays[7] = new Array();
bookdelays[7][0] = 8;
bookdelays[7][1] = 10;

var chamod = new Array();
chamod [ 1] = .5;		// +100%
chamod [ 2] = .5;
chamod [ 3] = .5;
chamod [ 4] = .5;
chamod [ 5] = .5;
chamod [ 6] = 2;		// +50%
chamod [ 7] = 2;
chamod [ 8] = 3;		// +33%
chamod [ 9] = 3;
chamod [10] = 3;
chamod [11] = 1;		// 0%
chamod [12] = 1;
chamod [13] = 1;
chamod [14] = 1;
chamod [15] = 1;
chamod [16] = -4;	//-25%
chamod [17] = -4;
chamod [18] = -3;	//-33%
chamod [19] = 2;	//-50%
chamod [20] = 2;
chamod [21] = 2;
chamod [22] = 2;
chamod [23] = 2;
chamod [24] = 2;
chamod [25] = 2;

var chamodtype = new Array();
chamodtype [ 1] = 1;		// multiplying/dividing
chamodtype [ 2] = 1;
chamodtype [ 3] = 1;
chamodtype [ 4] = 1;
chamodtype [ 5] = 1;
chamodtype [ 6] = 0;		// adding substracting fraction of
chamodtype [ 7] = 0;
chamodtype [ 8] = 0;
chamodtype [ 9] = 0;
chamodtype [10] = 0;
chamodtype [11] = 1;		// multiply / divide
chamodtype [12] = 1;
chamodtype [13] = 1;
chamodtype [14] = 1;
chamodtype [15] = 1;
chamodtype [16] = 0;		// add / sub
chamodtype [17] = 0;
chamodtype [18] = 0;
chamodtype [19] = 1;		// mul / div
chamodtype [20] = 1;
chamodtype [21] = 1;
chamodtype [22] = 1;
chamodtype [23] = 1;
chamodtype [24] = 1;
chamodtype [25] = 1;




startup_done = 1;

function nice_get_price (f)
{
  var price1= Number(f.price1.value);
  var price2= Number(f.price2.value);

  var gotinfo = ((price1 != 0) || (price2 != 0));
  if (gotinfo)
  {
    get_price(f);
  }
}




if (document.layers) document.captureEvents (Event.KEYPRESS);  /* NN4 */



var ie = (document.all);
var nn4 = ((!ie) && (document.layers));
var moz = ((!ie) && (document.getElementById));



document.onkeypress = function (evt)
{
  if (nhhelper_loaded != true) { return false; }

  /* IE 6+: event and window.event seem to be the same */
/*
  var str = "event:<br>\n";
  for (var ik in window.event)
  {
    str += ik +" => " +window.event[ik]+ "<br>\n";
  }
  document.getElementById("clippy_debug").innerHTML = str;
  return true;
*/
  if (ie) evt = window.event;

  /* we can't check the existance of event (mozilla) or window.event (IE5+) without bailing out?! WTF?! */
  var gotourtarget = (0==1);
  if ((nn4) || (moz)) gotourtarget = (evt && evt.target && (typeof evt.target.name != "undefined")) && ((evt.target.name == "price1") || (evt.target.name == "price2"));
  if (ie) gotourtarget = (evt && evt.srcElement && (typeof evt.srcElement.name != "undefined")) && ((evt.srcElement.name == "price1") || (evt.srcElement.name == "price2"));

  if (gotourtarget)
  {
    var keyCode = -2;
    if (nn4) keyCode = evt.which;
    if (ie) keyCode = evt.keyCode;
    if (moz) keyCode = evt.keyCode ? evt.keyCode : evt.which ? evt.which : evt.charCode;

    if (keyCode == 13)
    {
      nice_get_price(document.nh);
      return false;
    }
    else
    {
      return true;
    }
  }
  else
  {
    return true;
  }
}



function list_shit(f)
{
  var str = "shit ("+f+"):<br>\n";
  for (var k in f)
  {
    str += k +" => " +f[k] +"<br>\n";
  }
  document.getElementById("clippy_debug").innerHTML=str;
}

function submit_our_form (what, f)
{
  if (what == "price")
  {
    get_price (f);
  }
  else if (what == "spbk")
  {
    get_spellbook_prob (f);
  }
  
  return false;
}

function get_price (f)
{
  if (!startup_done) return;

  if (enabletip) reset_tooltip();

  var cha   = Number(f.cha.value);
  var tou   = f.tou.checked;
  var dun   = f.dun.checked;
  var eshk  = f.eshk.checked;
  var shkbroke = f.shkbroke.checked;
  var price1= Number(f.price1.value);
  var price2= Number(f.price2.value);
  var type  = f.typ.value;
  
  if (isNaN(price1)) price1 = 0;
  if (isNaN(price2)) price2 = 0;

  if ((cha == "") || (cha < 1) || (cha > 25))
  {
    alert ("Invalid Charisma Value supplied.");
  }
  else if ((price1 == "") && (price2 == ""))
  {
    alert ("You have to supply at least one price quote from the shopkeeper.");
  }
  else if (((price1 != "") && ((price1 < 1) || (price1 > 10000))) || ((price2 != "") && ((price2 < 1) || (price2 > 10000))))
  {
    alert ("Invalid Price supplied.");
  }
  else
  {
//    alert ("Charisma:"+cha+", Tourist? "+ (tou?"yes":"no")+ ", Dunce cap: " +(dun?"yes":"no")+ ", Enraged Shopkeeper? " +(eshk?"yes":"no")+ ", Price:"+price+", Type:"+type);

	 // now the price calculations
	 var output = calc_price (cha, tou, dun, eshk, price1, price2, type, shkbroke);
	 document.getElementById("restab2").innerHTML = output;

	 if (gTriggerImmediateShowing == 1) { permanent_tooltip (gTriggerPrice, 1); }

    clippy_lastchosenpos = 1;			// hard override!
	 clippy_setpos (3,0);
  } // end if everything looks ok
}




function get_spellbook_prob(f)
{
  if (!startup_done) return;

  if (enabletip) reset_tooltip();

  var xl     = f.xl.value;
  var intl   = f.intl.value;
  var lenses = f.lenses.checked;
  var spbkl  = f.spbkl.value;


  if ((spbkl < 1) || (spbkl > 7))
  {
    alert ("Invalid spellbook level supplied (must be 1 to 7)");
  }
  else
  {
    var output = calc_spellbook_prob (xl, intl, lenses, spbkl);
	 document.getElementById("resinfo").innerHTML = output;

    clippy_lastchosenpos = 2;				// hard override
	 clippy_setpos (3,0);
  }
}



var spbkProbNeg = new Array();

function calc_spellbook_prob (xl, intl, lenses, spbkl)
{
  var out = "";

  var probs = new Array();
  var delays = new Array();

  spbkProbNeg = new Array();		// reset negative probabilities

  for (var i = 1; i < 8; i++)
  {
    var tmpdelaymin = -1;
    var tmpdelaymax = -1;
    if ((i == 1) || (i == 2))
    {
      tmpdelaymin = bookdelays[i][0];
      tmpdelaymax = bookdelays[i][1];
		tmpdelaymin = tmpdelaymin;
		tmpdelaymax = tmpdelaymax;
    }
    else if ((i == 3) || (i == 4))
    {
      tmpdelaymin = bookdelays[i][0];
      tmpdelaymax = bookdelays[i][1];
		tmpdelaymin = (i-1) * tmpdelaymin;
		tmpdelaymax = (i-1) * tmpdelaymax;
    }
    else if ((i == 5) || (i == 6))
	 {
      tmpdelaymin = bookdelays[i][0];
      tmpdelaymax = bookdelays[i][1];
		tmpdelaymin = i * tmpdelaymin;
		tmpdelaymax = i * tmpdelaymax;
	 }
    else if (i == 7)
    {
      tmpdelaymin = bookdelays[i][0];
      tmpdelaymax = bookdelays[i][1];
		tmpdelaymin = 8 * tmpdelaymin;
		tmpdelaymax = 8 * tmpdelaymax;
    }

	 delays[i] = hsp_parseint(tmpdelaymin) +" - "+ hsp_parseint(tmpdelaymax);
	 probs[i] = ((hsp_parseint(intl) + 4 + hsp_parseint(hsp_parseint(xl)/2) - (2*hsp_parseint(i)) + hsp_parseint(lenses ? 2 : 0)) / 20)*100;

    probs[i] = hsp_parseint(probs[i]*100) / 100;
    var neg_part = Number(100-probs[i]);
	 var tmprnd = 1;
	 
	 var tmp = new Array();
	 tmp ['teleport']								= hsp_parseint(neg_part * ((i >= tmprnd++) ? (1/i) : 0) * 100) / 100;
	 tmp ['aggravate monsters']				= hsp_parseint(neg_part * ((i >= tmprnd++) ? (1/i) : 0) * 100) / 100;
	 tmp ['blind for 100-250 more turns']	= hsp_parseint(neg_part * ((i >= tmprnd++) ? (1/i) : 0) * 100) / 100;
	 tmp ['take all gold']						= hsp_parseint(neg_part * ((i >= tmprnd++) ? (1/i) : 0) * 100) / 100;
	 tmp ['confuse for 7-16 more turns']	= hsp_parseint(neg_part * ((i >= tmprnd++) ? (1/i) : 0) * 100) / 100;
	 tmp ['contact poison']						= hsp_parseint(neg_part * ((i >= tmprnd++) ? (1/i) : 0) * 100) / 100;
	 tmp ['book explodes (lose 5-25 hp)']	= hsp_parseint(neg_part * ((i >= tmprnd++) ? (1/i) : 0) * 100) / 100;
    spbkProbNeg[i] = tmp;

  }

  out = "<ta" + "ble width='100%' cellspacing=0 cellpadding=0 border=0 style='font-size: 16px' id='nh_results'>";
  out +="<t" +"r class='resfgcol'><t"+ "d width=10% class='resheader resheadertop' align=center'>Spell level</t" + "d><t" + "d class='resheader resheadertop' width=47% align=center'>Success probability</t" +"d><t" +"d class='resheader resheadertop' width=5%>&nbsp;</t" +"d><t" +"d width=25% class='resheader resheadertop'>Delay (min-max)</t" +"d><td width='13%' class='resheader resheadertop'>&nbsp;</td></t"+ "r>";
  for (var i = 1; i < 8; i++)
  {
    var emph = ((Number(spbkl) == Number(i)) ? " style='font-size: 18px; font-weight: 800'":"");
    out +="<t"+ "r class='resfgcol' onMouseOver='show_spbk_tooltip("+i+")' onMouseOut='hide_spbk_tooltip("+i+")'><t" +"d class='resrow resfgcol' width=10% align=center"+emph+">" +i+ "</t" +"d><t"+ "d class='resrow resfgcol' width=47% align=center"+emph+">" +probs[i]+ "%</t" +"d><t" +"d class='resrow resfgcol' width=5%></t"+ "d><t" +"d class='resrow resfgcol' width=25%"+emph+">" +delays[i]+ "</t" +"d><td class='resrow resfgcol' width=13%><span style='text-decoration: underline'>reading effects</span></td></t" +"r>";
  }
  out += "</ta"+ "ble>";
  
  return (out);
}





function calc_price (cha, tou, dun, eshk, price1, price2, type, shkbroke)
{
 
  var out = "";

  var use_baseprice = (0==1);

  if (type == "bb")		// base price
  {
	 type = "b";
	 cha = 14;					// no change due to charisma
	 tou = dun = eshk = 0;	// no additional changes
	 use_baseprice = (0==0);
  }

  var out1 = "";  var out2 = "";  var out_hits = "";
  
  if (type == "b")		// buy
  {
     var valid_prices = new Array();
	  
	  var eshk_removed1 = (eshk ? price1 / 4 * 3 - 2/3 : price1);
	  var cha_removed1 = eshk_removed1 *
	  		(chamodtype[cha] ?
				chamod[cha]
			:	(chamod[cha] != 0 ?
					(chamod[cha] > 0 ? (chamod[cha] / (chamod[cha]+1)) : (chamod[cha] / (chamod[cha]+1))) : 1));
					
	  var toudun_removed1 = (tou ? cha_removed1 * (toumod / (toumod+1)) : ( dun ? cha_removed1 * (dunmod / (dunmod+1)) : cha_removed1));
	  var sur_removed1 = toudun_removed1 * (surmod / (surmod+1));

	  var eshk_removed2 = (eshk ? price2 / 4 * 3 - 2/3 : price2);
	  var cha_removed2 = eshk_removed2 *
	  		(chamodtype[cha] ?
				chamod[cha]
			:	(chamod[cha] != 0 ?
					(chamod[cha] > 0 ? (chamod[cha] / (chamod[cha]+1)) : (chamod[cha] / (chamod[cha]+1))) : 1));
// old buggy:	(chamod[cha] > 0 ? ((chamod[cha]+1) / chamod[cha]) : (chamod[cha] / (chamod[cha]+1))) : 1));
	  var toudun_removed2 = (tou ? cha_removed2 * (toumod / (toumod+1)) : ( dun ? cha_removed2 * (dunmod / (dunmod+1)) : cha_removed2));
	  var sur_removed2 = toudun_removed2 * (surmod / (surmod+1));

	  cha_removed1 = hsp_parseint(cha_removed1);			cha_removed2 = hsp_parseint(cha_removed2);
	  eshk_removed1 = hsp_parseint(eshk_removed1);			eshk_removed2 = hsp_parseint(eshk_removed2);
	  toudun_removed1 = hsp_parseint(toudun_removed1);	toudun_removed2 = hsp_parseint(toudun_removed2);
     sur_removed1 = hsp_parseint(sur_removed1);			sur_removed2 = hsp_parseint(sur_removed2);
	  
	  if ((!(tou||dun)) && (cha_removed1 > 0)) valid_prices[valid_prices.length] = cha_removed1;
	  if ((!(tou||dun)) && (cha_removed2 > 0)) valid_prices[valid_prices.length] = cha_removed2;
	  if ((tou||dun) && (toudun_removed1 > 0)) valid_prices[valid_prices.length] = toudun_removed1;
	  if ((tou||dun) && (toudun_removed2 > 0)) valid_prices[valid_prices.length] = toudun_removed2;

	  if (!use_baseprice)
	  {
	    if (sur_removed1 > 0) valid_prices[valid_prices.length] = sur_removed1;
	    if (sur_removed2 > 0) valid_prices[valid_prices.length] = sur_removed2;
	  }
	  
	  var out_price1  = hsp_parseint(price1) + "z";	  var out_eshk1   = Number(eshk_removed1) + "z";	  var out_cha1    = Number(cha_removed1) + "z";	  var out_toudun1 = Number(toudun_removed1) + "z";	  var out_sur1    = Number(sur_removed1) + "z";
	  var out_price2  = hsp_parseint(price2) + "z";	  var out_eshk2   = Number(eshk_removed2) + "z";	  var out_cha2    = Number(cha_removed2) + "z";	  var out_toudun2 = Number(toudun_removed2) + "z";	  var out_sur2    = Number(sur_removed2) + "z";
  
     out1 = "";
	  if (price1 != "")
	  {
		 var header = "Calculation for price: " +out_price1+ " (Buy)";
		 var content = "";
		 if (!use_baseprice)
		 {
		   if (eshk) content += "- Enraged Shopkeeper: " +out_eshk1+ "<br/>\n";
         content += ((!(tou||dun)) ? "?":"-") + " Charisma: " +((!(tou||dun)) ? "<b>":"")+ out_cha1+ ((!(tou||dun)) ? "</b>":"")+ "<br/>\n";
	      if (tou || dun) content += ((tou||dun) ? "?":"-") + " Tourist/Duncecap: " +((tou||dun)?"<b>":"")+ out_toudun1+ ((tou||dun)?"</b>":"")+ "<br/>\n";
	      content += "? Surcharge: <b>" +out_sur1+ "</b>";
		 }
		 else
		 {
		   content = "<br/>\nNone.<br/>\n";
		 }

		 out1 = _get_res_tab (header, content);
	  }
	  
	  out2 = "";
	  if ((price2 != "") && (price1 != price2))
	  {
	    var header = "Calculation for price: " +out_price2+ " (Buy)";
		 var content = "";
		 if (!use_baseprice)
		 {
	      if (eshk) content += "- Enraged Shopkeeper: " +out_eshk2+ "<br/>\n";
	      content += ((!(tou||dun)) ? "?":"-") + " Charisma: " +((!(tou||dun)) ? "<b>":"")+ out_cha2+ ((!(tou||dun)) ? "</b>":"")+ "<br/>\n";
	      if (tou || dun) content += ((tou||dun) ? "?":"-") + " Tourist/Duncecap: " +((tou||dun)?"<b>":"")+ out_toudun2+ ((tou||dun)?"</b>":"")+ "<br/>\n";
	      content += "? Surcharge: <b>" +out_sur2+ "</b>";
		 }
		 else
		 {
		   content = "<br/>\nNone.<br/>\n";
		 }
		 
		 out2 = _get_res_tab (header, content);
	  }

	  out_hits = "";
	  if ((out1 != "") || (out2 != "")) out_hits = get_possible_hits (price1, price2, valid_prices);
	  // now the comparison
	  
  } // end if buy
  else if (type == "s")	// sell
  {
  
     var shkbroke1 = (shkbroke ? price1 * ((cantpaymod + 1) / cantpaymod) : price1);
	  var toudun_removed1 = (tou ? shkbroke1 * toumod : ( dun ? shkbroke1 * dunmod : shkbroke1));
	  var norm_removed1 = ((!(tou||dun)) ? shkbroke1 * normod : shkbroke1);
	  var sur_removed1 = ((tou||dun) ? toudun_removed1 : norm_removed1) * ((surmod+1) / surmod);
     var shkbroke2 = (shkbroke ? price2 * ((cantpaymod + 1) / cantpaymod) : price2);
	  var toudun_removed2 = (tou ? shkbroke2 * toumod : ( dun ? shkbroke2 * dunmod : shkbroke2));
	  var norm_removed2 = ((!(tou||dun)) ? shkbroke2 * normod : shkbroke2);
	  var sur_removed2 = ((tou||dun) ? toudun_removed2 : norm_removed2) * ((surmod+1) / surmod);

	  var valid_prices = new Array();
	  norm_removed1 = hsp_parseint(norm_removed1);		norm_removed2 = hsp_parseint(norm_removed2);
     sur_removed1 = hsp_parseint(sur_removed1);			sur_removed2 = hsp_parseint(sur_removed2);

     if (! (tou||dun))
	  {
	    if (norm_removed1 > 0) valid_prices[valid_prices.length] = norm_removed1;
	    if (norm_removed2 > 0) valid_prices[valid_prices.length] = norm_removed2;
	  }
	  else
	  {
	    if (toudun_removed1 > 0)  valid_prices[valid_prices.length] = toudun_removed1;
	    if (toudun_removed2 > 0)  valid_prices[valid_prices.length] = toudun_removed2;
	  }
	  if (sur_removed1 > 0)  valid_prices[valid_prices.length] = sur_removed1;
	  if (sur_removed2 > 0)  valid_prices[valid_prices.length] = sur_removed2;

	  var out_price1  = hsp_parseint(price1) + "z";  var out_norm1  = hsp_parseint(norm_removed1) + "z";  var out_toudun1 = hsp_parseint(toudun_removed1) + "z";  var out_sur1   = hsp_parseint(sur_removed1) + "z";  var out_shkbroke1 = hsp_parseint(shkbroke1) +"z";
	  var out_price2  = hsp_parseint(price2) + "z";  var out_norm2  = hsp_parseint(norm_removed2) + "z";  var out_toudun2 = hsp_parseint(toudun_removed2) + "z";  var out_sur2   = hsp_parseint(sur_removed2) + "z";  var out_shkbroke2 = hsp_parseint(shkbroke2) +"z";

	  out1 = "";
	  if (price1 != "")
	  {
	    var header = "Calculation for price: "+out_price1+ " (Sell)";
		 var content = "";
		 if (shkbroke) content += "- cant pay: " +out_shkbroke1+ "<br/>\n";
	    if (!(tou||dun)) content += "? Normal reduce: " +((!(tou||dun))?"<b>":"")+ out_norm1+ ((!(tou||dun))?"</b>":"")+ "<br/>\n";
	    if (tou||dun) content += "? Tourist/Duncecap: " +((tou||dun)?"<b>":"")+ out_toudun1+ ((tou||dun)?"</b>":"")+ "<br/>\n";
	    content += "? Surcharge: <b>" +out_sur1+ "</b></span><br/>\n";
		 
		 out1 = _get_res_tab (header, content);
	  }

	  out2 = "";
	  if ((price2 != "") && (price1 != price2))
	  {
	    var header = "Calculation for price: "+out_price2+ " (Sell)";
		 var content = "";
		 if (shkbroke) content += "- cant pay: " +out_shkbroke2+ "<br/>\n";
	    if (!(tou||dun)) content += "? Normal reduce: " +((!(tou||dun))?"<b>":"")+ out_norm2+ ((!(tou||dun))?"</b>":"")+ "<br/>\n";
	    if (tou||dun) content += "? Tourist/Duncecap: " +((tou||dun)?"<b>":"")+ out_toudun2+ ((tou||dun)?"</b>":"")+ "<br/>\n";
	    content += "? Surcharge: <b>" +out_sur2+ "</b></span><br/>\n";

		 out2 = _get_res_tab (header, content);
	  }

	  out_hits = "";
	  if ((out1 != "") || (out2 != "")) out_hits = get_possible_hits (price1, price2, valid_prices);

  } // end if sell

  if ((out1 != "") || (out2 != "") || (out_hits != ""))
  {
    out = "<table cellspacing=0 cellpadding=0 border=0 width=100%><tr>";
    if (out1 != "")      out += "<td align='left' valign='top' width=40%>"+out1+"&nbsp;</td>";
    if (out2 != "")      out += "<td align='left' valign='top' width=40%>"+out2+"&nbsp;</td>";
    if (out_hits != "")  out += "<td align='center' valign='top' width=20%>"+out_hits+"&nbsp;</td>";
    out += "</tr></table>";
  }
  // clear shown status
  first_generation = true;

//  alert ("price: "+price+"\nehsk rem: "+eshk_removed+"\ncha rem: "+cha_removed+"\ntoudun rem: "+toudun_removed+"\nsur rem: "+sur_removed);
  return (out);
}




function _get_res_tab (header, content)
{
  var out = "";
  out += "<table width=100% border=0 cellspacing=0 cellpadding=0>\n";
  out += "<tr class='resfgcol'><td class='resheader resheadertop' width='96%'>" +header+ "</td><td class='resheader resheadertop' width=4%>&nbsp;</td></tr>\n";
  out += "<tr class='resfgcol'><td class='resrow' width='96%'>" +content+ "</td><td class='resrow' width='4%'>&nbsp;</td></tr>\n";
  out += "</table>\n";

  return (out);
}


function NumSort (a,b) { return (a-b); }


function get_possible_hits (price1, price2, arr)
{
  var out_hits = "";
  if (price1 != price2)
  {
    var max_diff1 = price1*.05;	// 5% variance
    var max_diff2 = price2*.05;	// 5% variance
    var used_maxdiff = (max_diff1 > max_diff2 ? max_diff1 : max_diff2) * 2;	// use greater variance for checking times 2
	 if (used_maxdiff < 2) used_maxdiff = 2;
//	 alert ("d1 "+max_diff1+", d2 "+max_diff2+" = " +used_maxdiff);

    arr.sort(NumSort);
    var old_price = -99999;
    var possible_hits = new Array();
    for (var i=0; i < arr.length; i++)
    {
	   if ((price1 == 0) || (price2 == 0))
		{
//	     dbg += "" + arr[i]+ ", ";
		  var xy = hsp_parseint(arr[i] / 5)*5;      // set to a %5=0 value (forget about cheapo shit)
		  if ((known_prices[xy]) && (known_prices[xy] == true) && (typeof possible_hits[xy] == "undefined"))  possible_hits[xy] = true;
//		  dbg += "xy " +xy+ " (in db? " +((known_prices[xy] == true) ? "true":"false")+ ") is " +((typeof possible_hits[xy] == "undefined") ? "unknown":"known")+ " (" +(typeof(possible_hits[xy]))+ "), ";
        if ((Number(arr[i]) - used_maxdiff) < old_price)
        {
//		    if (xy == 0) xy = "negligible";
        }
        old_price = arr[i];
		}
		else
		{
//		  dbg += "" + arr[i]+ ", ";
		  if ((Number(arr[i]) - used_maxdiff) < old_price)
		  {
		    var xy = hsp_parseint(arr[i] / 5)*5;      // set to a %5=0 value (forget about cheapo shit)
		    if ((known_prices[xy] == true) && (typeof possible_hits[xy] == "undefined"))  possible_hits[xy] = true;
	     }
	     old_price = arr[i];
	   } // end if got two prices
																					 
    }

	 gTriggerImmediateShowing = 0; gTriggerPrice = -1;

    var posshits_length = 0;
	 for (curprice in possible_hits)   { posshits_length++; }

	 if (posshits_length == 1) { gTriggerImmediateShowing = 1; gTriggerPrice = curprice; }
	 
	 var elo = document.getElementById("restab2");
	 /*
	 var a = "res:<br>\n";
	 var asd = 0;
	 for (var x in elo)
	 {
	   a += "  --"+x+":";
		if (elo[x])
		{
		  var y = elo[x].toString();
		  y.replace (/\n/, " ");
		  a += y;
		}
	   if (asd++ % 4 == 0) a += "<br>\n";
	 }
    var el2 = document.getElementById("clippy_debug");
	 el2.innerHTML = a;
	 */
	 var resx = elo.clientWidth;
	 var resy = elo.clientHeight;
    if (resy <= 0) resy = 155;		/* px default, see css */

	 // what we doing here  is basically this:
	 // find out inner width of the id="resinfo" div
	 // remove 2 because of the border-bottom in the first line
	 // remove .resheader line-height for every line
	 // then divide by num of results + 1 to add stuff like eg. begin-spacer-info1-spacer-info2-spacer-end

    if (posshits_length > 0)
    {
	   var res_height = resy-2;
      out_hits += "<table cellspacing=0 cellpadding=0 width=100% border=0>\n";
		out_hits += "<tr class='resfgcol'><td class='resheader resheadertop' width=100% align='center'><b>Possible Hits</b></td></tr>\n";
		res_height -= 13;
//		out_hits += "<tr height=15><td height=15 width=100%></td></tr>\n";
		res_height -= 15;

		var curprice = -1;
		var foobarbaz = hsp_parseint(posshits_length/2) + 1;
		if (foobarbaz >= posshits_length) foobarbaz = 1;
		
      out_hits += "<tr class='resfgcol'><td width='100%' height='" +res_height+ "' align='center' valign='middle'>\n";
		out_hits += "<table class='resfgcol' width='100%' height='" +res_height+ "' cellspacing=0 cellpadding=0 border=0>\n";
		
	   var posshits_cnt = 0;
		var spacersize = hsp_parseint((res_height - 16*posshits_length) / (posshits_length+1));

//		alert ("resleft: " +res_height+ "\nspacer: " +spacersize+ "\nposshitlen:" +posshits_length);
		
		out_hits += "<tr height='" +spacersize+"'><td height='"+spacersize+"'></td></tr>\n";
      for (curprice in possible_hits)
      {
		  posshits_cnt++;
		  
		  if (prefs['pricetooltip'] == "yes")
          out_hits += "<tr" +((posshits_cnt == foobarbaz) ? " id='nh_results'":"")+ "><td class='resrow' align=center onClick='permanent_tooltip("+curprice+", 0)' onMouseOut='hide_tooltip()' onMouseOver='show_tooltip(" +curprice+ ")'>"+curprice+"z (<u>item info</u>)</td></tr>\n";
		  else
          out_hits += "<tr" +((posshits_cnt == foobarbaz) ? " id='nh_results'":"")+ "><td class='resrow pointatme' align=center onClick='show_tooltip("+curprice+")'>"+curprice+"z (<u>item info</u>)</td></tr>\n";
			 
		  out_hits += "<tr height='" +spacersize+"'><td height='"+spacersize+"'></td></tr>\n";
      }
      out_hits += "</table>\n";
		out_hits += "</td></tr>\n";
		out_hits += "</table>\n";
    }
  }
  return (out_hits);
}




// the item tooltips

function _show_tooltip(price)
{
  if (tipobj == null)
  {
    if (ie||ns6)
    {
      tipobj = (document.all ? document.all["dhtmltooltip"] : (document.getElementById ? document.getElementById("dhtmltooltip") : "") );
    }
  }
  

    var outcolcls = (prefs['pricetooltip'] == "yes") ? "item" : "res";
	 
    var curclass = "";
	 var out = (prefs['pricetooltip'] == "yes") ? 
      "<table class='winbgfgcol' height=18 width=100% cellspacing=0 cellpadding=0 border=0><tr class='winbgfgcol' height=18 width=100%><td id='dhtml_movebar' class='winbgfgcol' height=18 width=100% align=right valign=middle style='cursor: move;'><a href='javascript:reset_tooltip()'><img src='" +imgcommon+ "nh_close.gif' alt='Close window' border=0 width='14' height='14'></a> </td></tr></table>"
		:
		"";

    if (first_generation == true)   tooltip_currentlyshown_itemclasses = new Array();		// reset array
	 
    // get info from items hash
    for (var ic in items)
    {
	   if (items[ic][price])	// if array exists for price
	   {
        if (curclass != ic)		// if new class found, add header
	     {
		    if (curclass != "") out += "</table></div>\n";
		    curclass = ic;
			 if (first_generation == true) tooltip_currentlyshown_itemclasses[curclass] = false;

			 var num_of_items = items[ic][price].length;

			 var imgfname = imgcommon + (( (tooltip_currentlyshown_itemclasses[curclass]) && (tooltip_currentlyshown_itemclasses[curclass] == true)) ? itemclass_open : itemclass_close);
			 var myexplimage = "<img border='0' id='menuimg_"+curclass+"' src='" +imgfname+"' width='30' height='16'>";
			 var visibclass = (( (tooltip_currentlyshown_itemclasses[curclass]) && (tooltip_currentlyshown_itemclasses[curclass] == true)) ? "visible" : "hidden");
		    out += "<span class='pointatme' onClick='toggle_itemclass("+price+", \"" +curclass+ "\")'><span valign='middle' class='pointatme itemhead "+outcolcls+"fgcol'>" +myexplimage+ " <u><b>" +ic+" for " +price+"z (" +num_of_items+ " item" + ((num_of_items > 1) ? "s":"") +")</b></u></span></span><br>\n";
	       out += "<div id='itemtable_"+curclass+"' style='visibility: " +visibclass+ "'><table width='100%' cellspacing=0 cellpadding=0 border=0><tr height=2><td class='itemrow "+outcolcls+"fgcol' height=2 colspan=6></td></tr>";
		  }

		  if ( (tooltip_currentlyshown_itemclasses[curclass]) && (tooltip_currentlyshown_itemclasses[curclass] == true) )
		  {
		    for (var i=0; i < items[ic][price].length; i++)
		    {
		      var curentry = items[ic][price][i];
				var itemData = curentry.split ("\|");
				var itemName = itemData[0]; var itemInfo = itemData[1]; var itemSymbol = itemData[2]; var itemImage = itemData[3]; var itemBaseprice = itemData[4];

			   var last_entry = (i == (items[ic][price].length-1));
				var mytmpimage = "";
				if (prefs['showtextitems'] == false)
				{
				  mytmpimage = "<img src='" +imgnethack+ itemImage+ "' alt='" +itemSymbol+ "' width='8' height='12'>";
				}
				else
				{
				  var searchy = itemData[3].substr( itemData[3].indexOf("_")+1 );
				  var nhsymcol = "nhsym" +itemscolinfo [searchy];
				  mytmpimage = "<span class='objsym " +nhsymcol+ "'>" +itemSymbol+ "</span>";
				}
				var imgfname = imgcommon + (last_entry ? itemclass_entrylast : itemclass_entry);
				var myexplimage = "<img src='" +imgfname+ "' width='30' height='16'>";

		      out += "<tr width='100%' class='itemrow "+outcolcls+"fgcol'><td class='itemrow "+outcolcls+"fgcol' align='left' width='4%'>" +myexplimage+ "</td><td class='itemrow "+outcolcls+"fgcol' width='3'></td><td align='center' style='background-color: " +item_picbg+ "' class='itemrow "+outcolcls+"fgcol'>" +mytmpimage+ "</td><td width='3' class='itemrow "+outcolcls+"fgcol'></td><td align='left' width='35%' class='itemrow "+outcolcls+"fgcol'> " +itemName+ "</td><td width='57%' align='left' class='itemrow "+outcolcls+"fgcol'>" +itemInfo+ "</td></tr>\n";
//				dbg += "" +i+ ". "+itemName+" ("+imgnethack + itemImage+")\n";
		    }
		  } // end if itemclass is shown
	   }
    }
	 out += "<tr height=3><td height=3 class='itemrow "+outcolcls+"fgcol' colspan=6></td></tr>\n";
    out += "</table>\n";

	 if (prefs['pricetooltip'] == "yes")
	 {
      if (!enabletip) ddrivetip(out, tooltip_width);
      else tipobj.innerHTML = out;
      tipobj.style.width = tooltip_width+"px";
	 }
	 else
	 {
      var el = document.getElementById("resinfo");
	   if (el)
	   {
	     el.innerHTML = out;
	   }

		el = document.getElementById("resinfoheader");
		if (el)
		{
		  el.innerHTML = "<b>Items for "+price+"z</b>";
		}
	 }

  first_generation = false;

} // end _show_tooltip



// the spellbook tooltip

function show_spbk_tooltip(lvl)
{
  if (tipobj == null)
  {
    if (ie||ns6)
    {
      tipobj = (document.all ? document.all["dhtmltooltip"] : (document.getElementById ? document.getElementById("dhtmltooltip") : "") );
    }
  }
  

  var out = "<div class='resfgcol' id='spbkinfo_"+lvl+"'><table width='100%' cellspacing=0 cellpadding=0 border=0>";
  out += "<tr class='winbgcol' width='100%'><td class='winbgcol winfgcol' colspan='2' width='100%' id='resheader'><b>Spellbook level "+lvl+"</b> <span style='text-font: Arial,Helvetica; font-size: 12px;'>(when reading fails &nbsp;the reading delay effectively becomes paralysis)</span></td></tr>\n";
	 
  if (first_generation == true)   tooltip_currentlyshown_itemclasses = new Array();		// reset array
	 
  // get info from items hash
  for (var desc in spbkProbNeg[lvl])
  {
    var prob = spbkProbNeg[lvl][desc];
	 if (prob <= 0) prob = 0;

    out += "<tr class='winbgcol' width='100%'><td class='winbgcol winfgcol' align='left' width='39%' id='resheader2' style='padding: 0px 0px 0px 2px'>" +prob+ "%</td><td width='60%' align='left' id='resrow' class='winbgcol winfgcol'>" +desc+ "</td></tr>\n";
  }
  out += "</table></div>\n";
		
  if (!enabletip) ddrivetip(out, tooltip_width);
  else tipobj.innerHTML = out;

  first_generation = false;
}


function show_tooltip(price)
{
//  alert ("showttip " +price+ ": enable? " +((enabletip) ? "yes":"no")+ ", perm? " +((tooltip_permanent)?"yes":"no")+ ", notmove? " +((tooltip_notmove)?"yes":"no"));
  if ((!enabletip) || (tooltip_permanent == 1))
  {
    _show_tooltip(price);

    adjust_tooltip_running = true;
    adjust_tooltip = window.setInterval ("adjust_tipobj("+price+")", 50);
//    while (adjust_tipobj(price)) { _show_tooltip(price); alert ("adjusting"); }
  }
}




function toggle_itemclass(price, cls)
{
  tooltip_currentlyshown_itemclasses[cls] = ((tooltip_currentlyshown_itemclasses[cls] == true) ? false : true);
  _show_tooltip(price);
  hide_selects();
} // end func toggle_itemclass





function setup_feedback()
{
  var manfbdiv = document.getElementById("nh_feedbacktab");
  if (manfbform == null)  manfbform = _get_manfbform();
  manfbform.nickname.focus();
}


function feedback_sent()
{
/* XXX maybe i should do feedback in a window still.. or save the last pos to switch back when sent 
  var manfbdiv = document.getElementById("nh_feedbacktab");
  manfbdiv.style.visibility = "hidden";
*/
}


// my .toFixed(0) workaround
function hsp_parseint (v)
{
  return ( parseInt(Number(v) +.5) );			// round
}



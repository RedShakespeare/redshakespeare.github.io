
var itemsinfo = new Array();

// potions
var tmp = new Array();
tmp[tmp.length] = 'potion_red.png|puce, ruby|!';
tmp[tmp.length] = 'potion_brown.png|brown, murky, swirly|!';
tmp[tmp.length] = 'potion_orange.png|orange|!';
tmp[tmp.length] = 'potion_yellow.png|golden, yellow|!';
tmp[tmp.length] = 'potion_green.png|dark green|!';
tmp[tmp.length] = 'potion_bright_green.png|emerald|!';
tmp[tmp.length] = 'potion_cyan.png|clear, cyan, fizzy, sky blue|!';
tmp[tmp.length] = 'potion_bright_blue.png|brilliant blue|!';
tmp[tmp.length] = 'potion_magenta.png|magenta, purple-red|!';
tmp[tmp.length] = 'potion_bright_magenta.png|pink|!';
tmp[tmp.length] = 'potion_gray.png|black, dark, effervescent, smoky|!';
tmp[tmp.length] = 'potion_white.png|bubbly, cloudy, milky, white|!';
itemsinfo ['potions'] = tmp;

// wands
tmp = new Array();
tmp[tmp.length] = 'wand_cyan.png|aluminium, curved, hexagonal, iron, long, runed|/';
tmp[tmp.length] = 'wand_white.png|platinum|/';
tmp[tmp.length] = 'wand_cyan.png|short, steel, tin, uranium, zinc|/';
tmp[tmp.length] = 'wand_yellow.png|brass, copper|/';
tmp[tmp.length] = 'wand_bright_cyan.png|crystal, glass, iridium|/';
tmp[tmp.length] = 'wand_brown.png|balsa, ebony, maple, oak, pine|/';
tmp[tmp.length] = 'wand_gray.png|silver|/';
itemsinfo ['wands'] = tmp;

// rings
tmp = new Array();
// rot orange gelb gruen blau indigo violet blauviolett=indigo
tmp[tmp.length] = "ring_red.png|agate, clay, ruby|=";
tmp[tmp.length] = "ring_brown.png|tiger eye, wooden|=";
tmp[tmp.length] = "ring_orange.png|coral|=";
tmp[tmp.length] = "ring_yellow.png|brass, bronze, copper, gold|=";
tmp[tmp.length] = "ring_green.png|jade|=";
tmp[tmp.length] = "ring_bright_green.png|emerald|=";
tmp[tmp.length] = "ring_cyan.png|engagement, iron, steel, topaz, twisted, wire|=";
tmp[tmp.length] = "ring_bright_cyan.png|shiny|=";
tmp[tmp.length] = "ring_blue.png|sapphire|=";
tmp[tmp.length] = "ring_white.png|diamond, ivory, pearl|=";
tmp[tmp.length] = "ring_gray.png|black onyx, granite, moonstone, opal, silver|=";
itemsinfo ['rings'] = tmp;

// spellbooks
tmp = new Array();
tmp[tmp.length] = 'spellbook_red.png|red|+';
tmp[tmp.length] = 'spellbook_brown.png|cloth, dark brown, leather, light brown, tan|+';
tmp[tmp.length] = 'spellbook_orange.png|orange|+';
tmp[tmp.length] = 'spellbook_yellow.png|bronze, copper, gold, yellow|+';
tmp[tmp.length] = 'spellbook_green.png|dark green, plaid|+';
tmp[tmp.length] = 'spellbook_bright_green.png|light green|+';
tmp[tmp.length] = 'spellbook_cyan.png|cyan|+';
tmp[tmp.length] = 'spellbook_bright_cyan.png|turquoise|+';
tmp[tmp.length] = 'spellbook_blue.png|dark blue, indigo|+';
tmp[tmp.length] = 'spellbook_bright_blue.png|light blue|+';
tmp[tmp.length] = 'spellbook_magenta.png|magenta, purple, velvet, violet|+';
tmp[tmp.length] = 'spellbook_bright_magenta.png|pink|+';
tmp[tmp.length] = 'spellbook_white.png|shining, stained, thin, thick, vellum, white, wrinkled|+';
tmp[tmp.length] = 'spellbook_gray.png|gray, silver|+';
tmp[tmp.length] = 'spellbook_white.png|dog eared, dull, dusty, glittering, mottled, parchment, ragged|+';
itemsinfo ['spellbooks'] = tmp;


/* now the info to translate imgfilename to color */

var itemscolinfo = new Array();

// potions
itemscolinfo['red.png'] = "red";
itemscolinfo['brown.png'] = "brown";
itemscolinfo['orange.png'] = "lightred";
itemscolinfo['yellow.png'] = "yellow";
itemscolinfo['green.png'] = "green";
itemscolinfo['bright_green.png'] = "lightgreen";
itemscolinfo['cyan.png'] = "cyan";
itemscolinfo['bright_cyan.png'] = "lightcyan";
itemscolinfo['blue.png'] = "lightblue";
itemscolinfo['bright_blue.png'] = "lightblue";
itemscolinfo['magenta.png'] = "violet";
itemscolinfo['bright_magenta.png'] = "lightviolet";
itemscolinfo['gray.png'] = "gray";
itemscolinfo['white.png'] = "white";




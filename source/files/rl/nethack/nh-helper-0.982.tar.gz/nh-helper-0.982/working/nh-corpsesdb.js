

//
// Nethack pricing info, compiled by HiSPeed (partially Clippy @ nethack.roy.org data & pics)
//

// hSP: original data graciously provided by http://www.geocities.com/dcorbett42/nethack/corpse.htm




var corpses = new Array();


// abbot
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
    tmp4['Hallucination'] = 100;
  tmp['name'] = 'abbot';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['abbot'] = tmp;

// acid blob
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'acid blob';
  tmp['nutr'] = 10;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['acid blob'] = tmp;

// acolyte
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'acolyte';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['acolyte'] = tmp;

// aligned priest
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'aligned priest';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['aligned priest'] = tmp;

// ape
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'ape';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['ape'] = tmp;

// apprentice
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'apprentice';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['apprentice'] = tmp;

// Arch Priest
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Arch Priest';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Arch Priest'] = tmp;

// archeologist
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'archeologist';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['archeologist'] = tmp;

// attendant
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'attendant';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['attendant'] = tmp;

// baby black dragon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'baby black dragon';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baby black dragon'] = tmp;

// baby blue dragon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'baby blue dragon';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baby blue dragon'] = tmp;

// baby crocodile
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'baby crocodile';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baby crocodile'] = tmp;

// baby gray dragon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'baby gray dragon';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baby gray dragon'] = tmp;

// baby green dragon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'baby green dragon';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baby green dragon'] = tmp;

// baby long worm
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'baby long worm';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baby long worm'] = tmp;

// baby orange dragon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'baby orange dragon';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baby orange dragon'] = tmp;

// baby purple worm
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'baby purple worm';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baby purple worm'] = tmp;

// baby red dragon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'baby red dragon';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baby red dragon'] = tmp;

// baby silver dragon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'baby silver dragon';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baby silver dragon'] = tmp;

// baby white dragon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'baby white dragon';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baby white dragon'] = tmp;

// baby yellow dragon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'baby yellow dragon';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baby yellow dragon'] = tmp;

// baluchitherium
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'baluchitherium';
  tmp['nutr'] = 800;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['baluchitherium'] = tmp;

// barbarian
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'barbarian';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['barbarian'] = tmp;

// bat
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Stun'] = 100;
  tmp['name'] = 'bat';
  tmp['nutr'] = 20;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['bat'] = tmp;

// black dragon
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Disintegration'] = 100;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'black dragon';
  tmp['nutr'] = 1500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['black dragon'] = tmp;

// black naga
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 53;
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'black naga';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['black naga'] = tmp;

// black naga hatchling
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 20;
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'black naga hatchling';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['black naga hatchling'] = tmp;

// black pudding
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 22;
    tmp2['Poison'] = 22;
    tmp2['Shock'] = 22;
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'black pudding';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['black pudding'] = tmp;

// black unicorn
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 27;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'black unicorn';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['black unicorn'] = tmp;

// blue dragon
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Shock'] = 100;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'blue dragon';
  tmp['nutr'] = 1500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['blue dragon'] = tmp;

// blue jelly
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 13;
    tmp2['Poison'] = 13;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'blue jelly';
  tmp['nutr'] = 20;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['blue jelly'] = tmp;

// brown mold
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 3;
    tmp2['Poison'] = 3;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'brown mold';
  tmp['nutr'] = 30;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['brown mold'] = tmp;

// brown pudding
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 11;
    tmp2['Poison'] = 11;
    tmp2['Shock'] = 11;
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'brown pudding';
  tmp['nutr'] = 250;
  tmp['veggy'] = 1;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['brown pudding'] = tmp;

// bugbear
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'bugbear';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['bugbear'] = tmp;

// captain
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'captain';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['captain'] = tmp;

// carnivorous ape
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'carnivorous ape';
  tmp['nutr'] = 550;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['carnivorous ape'] = tmp;

// cave spider
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 7;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'cave spider';
  tmp['nutr'] = 50;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['cave spider'] = tmp;

// caveman
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'caveman';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['caveman'] = tmp;

// cavewoman
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'cavewoman';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['cavewoman'] = tmp;

// centipede
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 13;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'centipede';
  tmp['nutr'] = 50;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['centipede'] = tmp;

// chameleon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Polymorph'] = 100;
  tmp['name'] = 'chameleon';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['chameleon'] = tmp;

// chickatrice
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 27;
var tmp3 = new Array();
    tmp3['Petrify'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'chickatrice';
  tmp['nutr'] = 10;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['chickatrice'] = tmp;

// chieftain
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'chieftain';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['chieftain'] = tmp;

// Chromatic Dragon
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 17;
    tmp2['Disintegration'] = 17;
    tmp2['Fire'] = 17;
    tmp2['Poison'] = 17;
    tmp2['Shock'] = 17;
    tmp2['Sleep'] = 17;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Chromatic Dragon';
  tmp['nutr'] = 1700;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Chromatic Dragon'] = tmp;

// cobra
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 40;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'cobra';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['cobra'] = tmp;

// cockatrice
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 33;
var tmp3 = new Array();
    tmp3['Petrify'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'cockatrice';
  tmp['nutr'] = 30;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['cockatrice'] = tmp;

// coyote
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'coyote';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['coyote'] = tmp;

// crocodile
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'crocodile';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['crocodile'] = tmp;

// Croesus
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Croesus';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Croesus'] = tmp;

// Cyclops
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Strength'] = 100;
  tmp['name'] = 'Cyclops';
  tmp['nutr'] = 700;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Cyclops'] = tmp;

// Death
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['DIE'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Death';
  tmp['nutr'] = 1;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Death'] = tmp;

// dingo
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'dingo';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['dingo'] = tmp;

// disenchanter
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'disenchanter';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['disenchanter'] = tmp;

// dog
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Aggravate'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'dog';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['dog'] = tmp;

// doppelganger
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
    tmp4['Polymorph'] = 100;
  tmp['name'] = 'doppelganger';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['doppelganger'] = tmp;

// dwarf
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Dwarf'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'dwarf';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['dwarf'] = tmp;

// dwarf king
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Dwarf'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'dwarf king';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['dwarf king'] = tmp;

// dwarf lord
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Dwarf'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'dwarf lord';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['dwarf lord'] = tmp;

// electric eel
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Shock'] = 47;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'electric eel';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['electric eel'] = tmp;

// elf
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Sleep'] = 67;
var tmp3 = new Array();
    tmp3['Elf'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'elf';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['elf'] = tmp;

// elf-lord
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Sleep'] = 53;
var tmp3 = new Array();
    tmp3['Elf'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'elf-lord';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['elf-lord'] = tmp;

// Elvenking
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Sleep'] = 60;
var tmp3 = new Array();
    tmp3['Elf'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Elvenking';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Elvenking'] = tmp;

// ettin
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'ettin';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['ettin'] = tmp;

// Famine
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['DIE'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Famine';
  tmp['nutr'] = 1;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Famine'] = tmp;

// fire ant
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Fire'] = 20;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'fire ant';
  tmp['nutr'] = 10;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['fire ant'] = tmp;

// fire giant
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Strength'] = 100;
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Strength'] = 100;
  tmp['name'] = 'fire giant';
  tmp['nutr'] = 750;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['fire giant'] = tmp;

// flesh golem
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 12;
    tmp2['Fire'] = 12;
    tmp2['Poison'] = 12;
    tmp2['Shock'] = 12;
    tmp2['Sleep'] = 12;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'flesh golem';
  tmp['nutr'] = 600;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['flesh golem'] = tmp;

// floating eye
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Telepathy'] = 100;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'floating eye';
  tmp['nutr'] = 10;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['floating eye'] = tmp;

// forest centaur
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'forest centaur';
  tmp['nutr'] = 600;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['forest centaur'] = tmp;

// fox
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'fox';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['fox'] = tmp;

// frost giant
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 33;
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Strength'] = 100;
  tmp['name'] = 'frost giant';
  tmp['nutr'] = 750;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['frost giant'] = tmp;

// gargoyle
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'gargoyle';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['gargoyle'] = tmp;

// garter snake
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'garter snake';
  tmp['nutr'] = 60;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['garter snake'] = tmp;

// gecko
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'gecko';
  tmp['nutr'] = 20;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['gecko'] = tmp;

// gelatinous cube
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 10;
    tmp2['Fire'] = 10;
    tmp2['Shock'] = 10;
    tmp2['Sleep'] = 10;
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'gelatinous cube';
  tmp['nutr'] = 150;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['gelatinous cube'] = tmp;

// giant
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Strength'] = 100;
  tmp['name'] = 'giant';
  tmp['nutr'] = 750;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['giant'] = tmp;

// giant ant
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'giant ant';
  tmp['nutr'] = 10;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['giant ant'] = tmp;

// giant bat
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Stun'] = 100;
  tmp['name'] = 'giant bat';
  tmp['nutr'] = 30;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['giant bat'] = tmp;

// giant beetle
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 33;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'giant beetle';
  tmp['nutr'] = 10;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['giant beetle'] = tmp;

// giant eel
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'giant eel';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['giant eel'] = tmp;

// giant mimic
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Mimic'] = 100;
  tmp['name'] = 'giant mimic';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['giant mimic'] = tmp;

// giant rat
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'giant rat';
  tmp['nutr'] = 30;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['giant rat'] = tmp;

// giant spider
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 33;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'giant spider';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['giant spider'] = tmp;

// glass piercer
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'glass piercer';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['glass piercer'] = tmp;

// gnome
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Gnome'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'gnome';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['gnome'] = tmp;

// gnome king
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Gnome'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'gnome king';
  tmp['nutr'] = 150;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['gnome king'] = tmp;

// gnome lord
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Gnome'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'gnome lord';
  tmp['nutr'] = 120;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['gnome lord'] = tmp;

// gnomish wizard
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Gnome'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'gnomish wizard';
  tmp['nutr'] = 120;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['gnomish wizard'] = tmp;

// goblin
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'goblin';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['goblin'] = tmp;

// golden naga
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 67;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'golden naga';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['golden naga'] = tmp;

// golden naga hatchling
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 20;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'golden naga hatchling';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['golden naga hatchling'] = tmp;

// Grand Master
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Grand Master';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Grand Master'] = tmp;

// gray dragon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'gray dragon';
  tmp['nutr'] = 1500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['gray dragon'] = tmp;

// gray ooze
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 7;
    tmp2['Fire'] = 7;
    tmp2['Poison'] = 7;
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'gray ooze';
  tmp['nutr'] = 250;
  tmp['veggy'] = 1;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['gray ooze'] = tmp;

// gray unicorn
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 27;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'gray unicorn';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['gray unicorn'] = tmp;

// green dragon
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 100;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'green dragon';
  tmp['nutr'] = 1500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['green dragon'] = tmp;

// green mold
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'green mold';
  tmp['nutr'] = 30;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['green mold'] = tmp;

// green slime
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
    tmp3['Poisonous'] = 100;
    tmp3['Slime'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'green slime';
  tmp['nutr'] = 150;
  tmp['veggy'] = 1;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['green slime'] = tmp;

// Green-elf
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Sleep'] = 33;
var tmp3 = new Array();
    tmp3['Elf'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Green-elf';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Green-elf'] = tmp;

// gremlin
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 33;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'gremlin';
  tmp['nutr'] = 20;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['gremlin'] = tmp;

// Grey-elf
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Sleep'] = 40;
var tmp3 = new Array();
    tmp3['Elf'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Grey-elf';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Grey-elf'] = tmp;

// guard
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'guard';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['guard'] = tmp;

// guardian naga
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 80;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'guardian naga';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['guardian naga'] = tmp;

// guardian naga hatchling
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 20;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'guardian naga hatchling';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['guardian naga hatchling'] = tmp;

// guide
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'guide';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['guide'] = tmp;

// healer
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'healer';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['healer'] = tmp;

// hell hound
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Fire'] = 80;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'hell hound';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['hell hound'] = tmp;

// hell hound pup
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Fire'] = 47;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'hell hound pup';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['hell hound pup'] = tmp;

// high priest
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'high priest';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['high priest'] = tmp;

// hill giant
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Strength'] = 100;
  tmp['name'] = 'hill giant';
  tmp['nutr'] = 700;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['hill giant'] = tmp;

// hill orc
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'hill orc';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['hill orc'] = tmp;

// Hippocrates
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Hippocrates';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Hippocrates'] = tmp;

// hobbit
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'hobbit';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['hobbit'] = tmp;

// hobgoblin
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'hobgoblin';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['hobgoblin'] = tmp;

// homunculus
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 7;
    tmp2['Sleep'] = 7;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'homunculus';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['homunculus'] = tmp;

// horse
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'horse';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['horse'] = tmp;

// housecat
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Aggravate'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'housecat';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['housecat'] = tmp;

// human
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'human';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['human'] = tmp;

// hunter
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'hunter';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['hunter'] = tmp;

// ice troll
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 60;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'ice troll';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['ice troll'] = tmp;

// iguana
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'iguana';
  tmp['nutr'] = 30;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['iguana'] = tmp;

// imp
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'imp';
  tmp['nutr'] = 10;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['imp'] = tmp;

// iron piercer
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'iron piercer';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['iron piercer'] = tmp;

// Ixoth
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Fire'] = 100;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'Ixoth';
  tmp['nutr'] = 1600;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Ixoth'] = tmp;

// jabberwock
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'jabberwock';
  tmp['nutr'] = 600;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['jabberwock'] = tmp;

// jackal
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'jackal';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['jackal'] = tmp;

// jaguar
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'jaguar';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['jaguar'] = tmp;

// jellyfish
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 20;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'jellyfish';
  tmp['nutr'] = 20;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['jellyfish'] = tmp;

// Keystone Kop
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Keystone Kop';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Keystone Kop'] = tmp;

// killer bee
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 30;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'killer bee';
  tmp['nutr'] = 5;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['killer bee'] = tmp;

// King Arthur
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'King Arthur';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['King Arthur'] = tmp;

// kitten
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Aggravate'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'kitten';
  tmp['nutr'] = 150;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['kitten'] = tmp;

// knight
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'knight';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['knight'] = tmp;

// kobold
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'kobold';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['kobold'] = tmp;

// kobold lord
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'kobold lord';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['kobold lord'] = tmp;

// kobold shaman
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'kobold shaman';
  tmp['nutr'] = 150;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['kobold shaman'] = tmp;

// Kop Kaptain
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Kop Kaptain';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Kop Kaptain'] = tmp;

// Kop Lieutenant
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Kop Lieutenant';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Kop Lieutenant'] = tmp;

// Kop Sergeant
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Kop Sergeant';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Kop Sergeant'] = tmp;

// kraken
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'kraken';
  tmp['nutr'] = 1000;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['kraken'] = tmp;

// large cat
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Aggravate'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'large cat';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['large cat'] = tmp;

// large dog
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Aggravate'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'large dog';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['large dog'] = tmp;

// large kobold
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'large kobold';
  tmp['nutr'] = 150;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['large kobold'] = tmp;

// large mimic
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Mimic'] = 100;
  tmp['name'] = 'large mimic';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['large mimic'] = tmp;

// leocrotta
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'leocrotta';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['leocrotta'] = tmp;

// leprechaun
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Teleportitis'] = 50;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'leprechaun';
  tmp['nutr'] = 30;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['leprechaun'] = tmp;

// lichen
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'lichen';
  tmp['nutr'] = 200;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['lichen'] = tmp;

// lieutenant
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'lieutenant';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['lieutenant'] = tmp;

// little dog
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Aggravate'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'little dog';
  tmp['nutr'] = 150;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['little dog'] = tmp;

// lizard
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Cure stoning'] = 100;
var tmp4 = new Array();
    tmp4['Reduce confusion'] = 100;
    tmp4['Reduce stunning'] = 100;
  tmp['name'] = 'lizard';
  tmp['nutr'] = 40;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['lizard'] = tmp;

// long worm
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'long worm';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['long worm'] = tmp;

// Lord Carnarvon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Lord Carnarvon';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Lord Carnarvon'] = tmp;

// Lord Sato
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Lord Sato';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Lord Sato'] = tmp;

// Lord Surtur
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Fire'] = 50;
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Strength'] = 100;
  tmp['name'] = 'Lord Surtur';
  tmp['nutr'] = 850;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Lord Surtur'] = tmp;

// lurker above
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'lurker above';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['lurker above'] = tmp;

// lynx
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'lynx';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['lynx'] = tmp;

// Master Assassin
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Master Assassin';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Master Assassin'] = tmp;

// Master Kaen
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 100;
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Master Kaen';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Master Kaen'] = tmp;

// master mind flayer
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Telepathy'] = 100;
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Intelligence'] = 100;
  tmp['name'] = 'master mind flayer';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['master mind flayer'] = tmp;

// Master of Thieves
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Master of Thieves';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Master of Thieves'] = tmp;

// mastodon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'mastodon';
  tmp['nutr'] = 800;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['mastodon'] = tmp;

// Medusa
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 100;
var tmp3 = new Array();
    tmp3['Petrify'] = 100;
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Medusa';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Medusa'] = tmp;

// mind flayer
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Telepathy'] = 100;
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Intelligence'] = 100;
  tmp['name'] = 'mind flayer';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['mind flayer'] = tmp;

// minotaur
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'minotaur';
  tmp['nutr'] = 700;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['minotaur'] = tmp;

// monk
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'monk';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['monk'] = tmp;

// monkey
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'monkey';
  tmp['nutr'] = 50;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['monkey'] = tmp;

// Mordor orc
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'Mordor orc';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Mordor orc'] = tmp;

// mountain centaur
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'mountain centaur';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['mountain centaur'] = tmp;

// mountain nymph
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Teleportitis'] = 30;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'mountain nymph';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['mountain nymph'] = tmp;

// mumak
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'mumak';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['mumak'] = tmp;

// neanderthal
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'neanderthal';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['neanderthal'] = tmp;

// Neferet the Green
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Neferet the Green';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Neferet the Green'] = tmp;

// newt
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Energy'] = 67;
  tmp['name'] = 'newt';
  tmp['nutr'] = 20;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['newt'] = tmp;

// ninja
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'ninja';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['ninja'] = tmp;

// Norn
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Norn';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Norn'] = tmp;

// nurse
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 73;
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
    tmp4['Heal'] = 100;
  tmp['name'] = 'nurse';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['nurse'] = tmp;

// ochre jelly
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'ochre jelly';
  tmp['nutr'] = 20;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['ochre jelly'] = tmp;

// ogre
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'ogre';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['ogre'] = tmp;

// ogre king
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'ogre king';
  tmp['nutr'] = 750;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['ogre king'] = tmp;

// ogre lord
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'ogre lord';
  tmp['nutr'] = 700;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['ogre lord'] = tmp;

// Olog-hai
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'Olog-hai';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Olog-hai'] = tmp;

// Oracle
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Oracle';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Oracle'] = tmp;

// orange dragon
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Sleep'] = 100;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'orange dragon';
  tmp['nutr'] = 1500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['orange dragon'] = tmp;

// orc
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'orc';
  tmp['nutr'] = 150;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['orc'] = tmp;

// orc shaman
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'orc shaman';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['orc shaman'] = tmp;

// orc-captain
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'orc-captain';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['orc-captain'] = tmp;

// Orion
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Orion';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Orion'] = tmp;

// owlbear
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'owlbear';
  tmp['nutr'] = 700;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['owlbear'] = tmp;

// page
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'page';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['page'] = tmp;

// panther
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'panther';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['panther'] = tmp;

// Pelias
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Pelias';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Pelias'] = tmp;

// Pestilence
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['DIE'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Pestilence';
  tmp['nutr'] = 1;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Pestilence'] = tmp;

// piranha
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'piranha';
  tmp['nutr'] = 30;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['piranha'] = tmp;

// pit viper
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 40;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'pit viper';
  tmp['nutr'] = 60;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['pit viper'] = tmp;

// plains centaur
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'plains centaur';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['plains centaur'] = tmp;

// pony
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'pony';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['pony'] = tmp;

// priest
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'priest';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['priest'] = tmp;

// priestess
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'priestess';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['priestess'] = tmp;

// prisoner
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'prisoner';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['prisoner'] = tmp;

// purple worm
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'purple worm';
  tmp['nutr'] = 700;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['purple worm'] = tmp;

// pyrolisk
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Fire'] = 20;
    tmp2['Poison'] = 20;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'pyrolisk';
  tmp['nutr'] = 30;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['pyrolisk'] = tmp;

// python
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'python';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['python'] = tmp;

// quantum mechanic
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
    tmp4['Toggles intrinsic speed'] = 100;
  tmp['name'] = 'quantum mechanic';
  tmp['nutr'] = 20;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['quantum mechanic'] = tmp;

// quasit
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 20;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'quasit';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['quasit'] = tmp;

// queen bee
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 60;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'queen bee';
  tmp['nutr'] = 5;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['queen bee'] = tmp;

// quivering blob
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 33;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'quivering blob';
  tmp['nutr'] = 100;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['quivering blob'] = tmp;

// rabid rat
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'rabid rat';
  tmp['nutr'] = 5;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['rabid rat'] = tmp;

// ranger
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'ranger';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['ranger'] = tmp;

// raven
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'raven';
  tmp['nutr'] = 20;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['raven'] = tmp;

// red dragon
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Fire'] = 100;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'red dragon';
  tmp['nutr'] = 1500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['red dragon'] = tmp;

// red mold
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Fire'] = 3;
    tmp2['Poison'] = 3;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'red mold';
  tmp['nutr'] = 30;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['red mold'] = tmp;

// red naga
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Fire'] = 20;
    tmp2['Poison'] = 20;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'red naga';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['red naga'] = tmp;

// red naga hatchling
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Fire'] = 10;
    tmp2['Poison'] = 10;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'red naga hatchling';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['red naga hatchling'] = tmp;

// rock mole
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'rock mole';
  tmp['nutr'] = 30;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['rock mole'] = tmp;

// rock piercer
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'rock piercer';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['rock piercer'] = tmp;

// rock troll
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'rock troll';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['rock troll'] = tmp;

// rogue
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'rogue';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['rogue'] = tmp;

// roshi
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'roshi';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['roshi'] = tmp;

// rothe
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'rothe';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['rothe'] = tmp;

// rust monster
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'rust monster';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['rust monster'] = tmp;

// salamander
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Fire'] = 53;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'salamander';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['salamander'] = tmp;

// samurai
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'samurai';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['samurai'] = tmp;

// sasquatch
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'sasquatch';
  tmp['nutr'] = 750;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['sasquatch'] = tmp;

// scorpion
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 50;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'scorpion';
  tmp['nutr'] = 100;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['scorpion'] = tmp;

// Scorpius
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 100;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Scorpius';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Scorpius'] = tmp;

// sergeant
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'sergeant';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['sergeant'] = tmp;

// sewer rat
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'sewer rat';
  tmp['nutr'] = 12;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['sewer rat'] = tmp;

// Shaman Karnov
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Shaman Karnov';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Shaman Karnov'] = tmp;

// shark
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'shark';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['shark'] = tmp;

// shopkeeper
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'shopkeeper';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['shopkeeper'] = tmp;

// shrieker
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 20;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'shrieker';
  tmp['nutr'] = 100;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['shrieker'] = tmp;

// silver dragon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'silver dragon';
  tmp['nutr'] = 1500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['silver dragon'] = tmp;

// small mimic
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Mimic'] = 100;
  tmp['name'] = 'small mimic';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['small mimic'] = tmp;

// snake
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 27;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'snake';
  tmp['nutr'] = 80;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['snake'] = tmp;

// soldier
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'soldier';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['soldier'] = tmp;

// soldier ant
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 20;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'soldier ant';
  tmp['nutr'] = 5;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['soldier ant'] = tmp;

// spotted jelly
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'spotted jelly';
  tmp['nutr'] = 20;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['spotted jelly'] = tmp;

// stalker
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Invisibility'] = 100;
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Stun'] = 100;
  tmp['name'] = 'stalker';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['stalker'] = tmp;

// stone giant
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Strength'] = 100;
  tmp['name'] = 'stone giant';
  tmp['nutr'] = 750;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['stone giant'] = tmp;

// storm giant
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Shock'] = 50;
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Strength'] = 100;
  tmp['name'] = 'storm giant';
  tmp['nutr'] = 750;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['storm giant'] = tmp;

// student
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'student';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['student'] = tmp;

// tengu
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 13;
    tmp2['Teleport control'] = 17;
    tmp2['Teleportitis'] = 20;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'tengu';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['tengu'] = tmp;

// thug
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'thug';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['thug'] = tmp;

// tiger
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'tiger';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['tiger'] = tmp;

// titan
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'titan';
  tmp['nutr'] = 900;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['titan'] = tmp;

// titanothere
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'titanothere';
  tmp['nutr'] = 650;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['titanothere'] = tmp;

// tourist
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'tourist';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['tourist'] = tmp;

// trapper
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'trapper';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['trapper'] = tmp;

// troll
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'troll';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['troll'] = tmp;

// Twoflower
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Twoflower';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Twoflower'] = tmp;

// umber hulk
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'umber hulk';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['umber hulk'] = tmp;

// Uruk-hai
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'Uruk-hai';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Uruk-hai'] = tmp;

// valkyrie
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'valkyrie';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['valkyrie'] = tmp;

// vampire bat
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'vampire bat';
  tmp['nutr'] = 20;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['vampire bat'] = tmp;

// violet fungus
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 20;
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Hallucination'] = 100;
  tmp['name'] = 'violet fungus';
  tmp['nutr'] = 100;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['violet fungus'] = tmp;

// warg
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'warg';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['warg'] = tmp;

// warhorse
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'warhorse';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['warhorse'] = tmp;

// warrior
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'warrior';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['warrior'] = tmp;

// watch captain
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'watch captain';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['watch captain'] = tmp;

// watchman
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'watchman';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['watchman'] = tmp;

// water moccasin
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 27;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'water moccasin';
  tmp['nutr'] = 80;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['water moccasin'] = tmp;

// water nymph
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Teleportitis'] = 30;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'water nymph';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['water nymph'] = tmp;

// water troll
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'water troll';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['water troll'] = tmp;

// werejackal
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Lycanthropy'] = 100;
var tmp3 = new Array();
    tmp3['Human'] = 100;
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'werejackal';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['werejackal'] = tmp;

// wererat
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Lycanthropy'] = 100;
var tmp3 = new Array();
    tmp3['Human'] = 100;
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'wererat';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['wererat'] = tmp;

// werewolf
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Lycanthropy'] = 100;
var tmp3 = new Array();
    tmp3['Human'] = 100;
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'werewolf';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['werewolf'] = tmp;

// white dragon
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 100;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'white dragon';
  tmp['nutr'] = 1500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['white dragon'] = tmp;

// white unicorn
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 27;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'white unicorn';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['white unicorn'] = tmp;

// winged gargoyle
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'winged gargoyle';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['winged gargoyle'] = tmp;

// winter wolf
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 47;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'winter wolf';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['winter wolf'] = tmp;

// winter wolf cub
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 33;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'winter wolf cub';
  tmp['nutr'] = 200;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['winter wolf cub'] = tmp;

// wizard
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'wizard';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['wizard'] = tmp;

// Wizard of Yendor
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Fire'] = 25;
    tmp2['Poison'] = 25;
    tmp2['Teleport control'] = 25;
    tmp2['Teleportitis'] = 25;
var tmp3 = new Array();
    tmp3['Human'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Wizard of Yendor';
  tmp['nutr'] = 400;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Wizard of Yendor'] = tmp;

// wolf
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'wolf';
  tmp['nutr'] = 250;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['wolf'] = tmp;

// wood nymph
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Teleportitis'] = 30;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'wood nymph';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['wood nymph'] = tmp;

// woodchuck
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'woodchuck';
  tmp['nutr'] = 30;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['woodchuck'] = tmp;

// Woodland-elf
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Sleep'] = 27;
var tmp3 = new Array();
    tmp3['Elf'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'Woodland-elf';
  tmp['nutr'] = 350;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['Woodland-elf'] = tmp;

// wraith
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
    tmp4['Gain level'] = 100;
  tmp['name'] = 'wraith';
  tmp['nutr'] = 0;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['wraith'] = tmp;

// wumpus
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'wumpus';
  tmp['nutr'] = 500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['wumpus'] = tmp;

// xan
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 47;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'xan';
  tmp['nutr'] = 300;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['xan'] = tmp;

// xorn
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'xorn';
  tmp['nutr'] = 700;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['xorn'] = tmp;

// yellow dragon
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
    tmp3['Acidic'] = 100;
var tmp4 = new Array();
  tmp['name'] = 'yellow dragon';
  tmp['nutr'] = 1500;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['yellow dragon'] = tmp;

// yellow mold
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Poison'] = 7;
var tmp3 = new Array();
    tmp3['Poisonous'] = 100;
var tmp4 = new Array();
    tmp4['Hallucination'] = 100;
  tmp['name'] = 'yellow mold';
  tmp['nutr'] = 30;
  tmp['veggy'] = 1;
  tmp['vegan'] = 1;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['yellow mold'] = tmp;

// yeti
var tmp = new Array();
var tmp2 = new Array();
    tmp2['Cold'] = 33;
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'yeti';
  tmp['nutr'] = 700;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['yeti'] = tmp;

// zruty
var tmp = new Array();
var tmp2 = new Array();
var tmp3 = new Array();
var tmp4 = new Array();
  tmp['name'] = 'zruty';
  tmp['nutr'] = 600;
  tmp['veggy'] = 0;
  tmp['vegan'] = 0;
  tmp['intrinsics'] = tmp2;
  tmp['effects-init'] = tmp3;
  tmp['effects-final'] = tmp4;
corpses['zruty'] = tmp;




var effects = new Array();

var tmp = new Array();
  tmp[tmp.length] = 'acid blob';
  tmp[tmp.length] = 'baby yellow dragon';
  tmp[tmp.length] = 'black naga';
  tmp[tmp.length] = 'black naga hatchling';
  tmp[tmp.length] = 'black pudding';
  tmp[tmp.length] = 'brown pudding';
  tmp[tmp.length] = 'gelatinous cube';
  tmp[tmp.length] = 'gray ooze';
  tmp[tmp.length] = 'green mold';
  tmp[tmp.length] = 'green slime';
  tmp[tmp.length] = 'ochre jelly';
  tmp[tmp.length] = 'spotted jelly';
  tmp[tmp.length] = 'yellow dragon';
effects['Acidic'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'dog';
  tmp[tmp.length] = 'housecat';
  tmp[tmp.length] = 'kitten';
  tmp[tmp.length] = 'large cat';
  tmp[tmp.length] = 'large dog';
  tmp[tmp.length] = 'little dog';
effects['Aggravate'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'lizard';
effects['Cure stoning'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'Death';
  tmp[tmp.length] = 'Famine';
  tmp[tmp.length] = 'Pestilence';
effects['DIE'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'dwarf';
  tmp[tmp.length] = 'dwarf king';
  tmp[tmp.length] = 'dwarf lord';
effects['Dwarf'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'elf';
  tmp[tmp.length] = 'elf-lord';
  tmp[tmp.length] = 'Elvenking';
  tmp[tmp.length] = 'Green-elf';
  tmp[tmp.length] = 'Grey-elf';
  tmp[tmp.length] = 'Woodland-elf';
effects['Elf'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'newt';
effects['Energy'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'wraith';
effects['Gain level'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'gnome';
  tmp[tmp.length] = 'gnome king';
  tmp[tmp.length] = 'gnome lord';
  tmp[tmp.length] = 'gnomish wizard';
effects['Gnome'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'abbot';
  tmp[tmp.length] = 'violet fungus';
  tmp[tmp.length] = 'yellow mold';
effects['Hallucination'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'nurse';
effects['Heal'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'abbot';
  tmp[tmp.length] = 'acolyte';
  tmp[tmp.length] = 'aligned priest';
  tmp[tmp.length] = 'apprentice';
  tmp[tmp.length] = 'Arch Priest';
  tmp[tmp.length] = 'archeologist';
  tmp[tmp.length] = 'attendant';
  tmp[tmp.length] = 'barbarian';
  tmp[tmp.length] = 'captain';
  tmp[tmp.length] = 'caveman';
  tmp[tmp.length] = 'cavewoman';
  tmp[tmp.length] = 'chieftain';
  tmp[tmp.length] = 'Croesus';
  tmp[tmp.length] = 'doppelganger';
  tmp[tmp.length] = 'Grand Master';
  tmp[tmp.length] = 'guard';
  tmp[tmp.length] = 'guide';
  tmp[tmp.length] = 'healer';
  tmp[tmp.length] = 'high priest';
  tmp[tmp.length] = 'Hippocrates';
  tmp[tmp.length] = 'human';
  tmp[tmp.length] = 'hunter';
  tmp[tmp.length] = 'Keystone Kop';
  tmp[tmp.length] = 'King Arthur';
  tmp[tmp.length] = 'knight';
  tmp[tmp.length] = 'Kop Kaptain';
  tmp[tmp.length] = 'Kop Lieutenant';
  tmp[tmp.length] = 'Kop Sergeant';
  tmp[tmp.length] = 'lieutenant';
  tmp[tmp.length] = 'Lord Carnarvon';
  tmp[tmp.length] = 'Lord Sato';
  tmp[tmp.length] = 'Master Assassin';
  tmp[tmp.length] = 'Master Kaen';
  tmp[tmp.length] = 'Master of Thieves';
  tmp[tmp.length] = 'monk';
  tmp[tmp.length] = 'neanderthal';
  tmp[tmp.length] = 'Neferet the Green';
  tmp[tmp.length] = 'ninja';
  tmp[tmp.length] = 'Norn';
  tmp[tmp.length] = 'nurse';
  tmp[tmp.length] = 'Oracle';
  tmp[tmp.length] = 'Orion';
  tmp[tmp.length] = 'page';
  tmp[tmp.length] = 'Pelias';
  tmp[tmp.length] = 'priest';
  tmp[tmp.length] = 'priestess';
  tmp[tmp.length] = 'prisoner';
  tmp[tmp.length] = 'ranger';
  tmp[tmp.length] = 'rogue';
  tmp[tmp.length] = 'roshi';
  tmp[tmp.length] = 'samurai';
  tmp[tmp.length] = 'sergeant';
  tmp[tmp.length] = 'Shaman Karnov';
  tmp[tmp.length] = 'shopkeeper';
  tmp[tmp.length] = 'soldier';
  tmp[tmp.length] = 'student';
  tmp[tmp.length] = 'thug';
  tmp[tmp.length] = 'tourist';
  tmp[tmp.length] = 'Twoflower';
  tmp[tmp.length] = 'valkyrie';
  tmp[tmp.length] = 'warrior';
  tmp[tmp.length] = 'watch captain';
  tmp[tmp.length] = 'watchman';
  tmp[tmp.length] = 'werejackal';
  tmp[tmp.length] = 'wererat';
  tmp[tmp.length] = 'werewolf';
  tmp[tmp.length] = 'wizard';
  tmp[tmp.length] = 'Wizard of Yendor';
effects['Human'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'master mind flayer';
  tmp[tmp.length] = 'mind flayer';
effects['Intelligence'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'giant mimic';
  tmp[tmp.length] = 'large mimic';
  tmp[tmp.length] = 'small mimic';
effects['Mimic'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'chickatrice';
  tmp[tmp.length] = 'cockatrice';
  tmp[tmp.length] = 'Medusa';
effects['Petrify'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'baby green dragon';
  tmp[tmp.length] = 'Chromatic Dragon';
  tmp[tmp.length] = 'cobra';
  tmp[tmp.length] = 'giant beetle';
  tmp[tmp.length] = 'giant spider';
  tmp[tmp.length] = 'green dragon';
  tmp[tmp.length] = 'green slime';
  tmp[tmp.length] = 'gremlin';
  tmp[tmp.length] = 'guardian naga';
  tmp[tmp.length] = 'homunculus';
  tmp[tmp.length] = 'jellyfish';
  tmp[tmp.length] = 'killer bee';
  tmp[tmp.length] = 'kobold';
  tmp[tmp.length] = 'kobold lord';
  tmp[tmp.length] = 'kobold shaman';
  tmp[tmp.length] = 'large kobold';
  tmp[tmp.length] = 'Medusa';
  tmp[tmp.length] = 'pit viper';
  tmp[tmp.length] = 'quantum mechanic';
  tmp[tmp.length] = 'queen bee';
  tmp[tmp.length] = 'rabid rat';
  tmp[tmp.length] = 'salamander';
  tmp[tmp.length] = 'scorpion';
  tmp[tmp.length] = 'Scorpius';
  tmp[tmp.length] = 'snake';
  tmp[tmp.length] = 'soldier ant';
  tmp[tmp.length] = 'vampire bat';
  tmp[tmp.length] = 'water moccasin';
  tmp[tmp.length] = 'werejackal';
  tmp[tmp.length] = 'wererat';
  tmp[tmp.length] = 'werewolf';
  tmp[tmp.length] = 'xan';
  tmp[tmp.length] = 'yellow mold';
effects['Poisonous'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'chameleon';
  tmp[tmp.length] = 'doppelganger';
effects['Polymorph'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'lizard';
effects['Reduce confusion'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'lizard';
effects['Reduce stunning'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'green slime';
effects['Slime'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'Cyclops';
  tmp[tmp.length] = 'fire giant';
  tmp[tmp.length] = 'frost giant';
  tmp[tmp.length] = 'giant';
  tmp[tmp.length] = 'hill giant';
  tmp[tmp.length] = 'Lord Surtur';
  tmp[tmp.length] = 'stone giant';
  tmp[tmp.length] = 'storm giant';
effects['Strength'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'bat';
  tmp[tmp.length] = 'giant bat';
  tmp[tmp.length] = 'stalker';
effects['Stun'] = tmp;




var intrinsics = new Array();

var tmp = new Array();
  tmp[tmp.length] = 'black pudding';
  tmp[tmp.length] = 'blue jelly';
  tmp[tmp.length] = 'brown mold';
  tmp[tmp.length] = 'brown pudding';
  tmp[tmp.length] = 'Chromatic Dragon';
  tmp[tmp.length] = 'flesh golem';
  tmp[tmp.length] = 'frost giant';
  tmp[tmp.length] = 'gelatinous cube';
  tmp[tmp.length] = 'gray ooze';
  tmp[tmp.length] = 'ice troll';
  tmp[tmp.length] = 'white dragon';
  tmp[tmp.length] = 'winter wolf';
  tmp[tmp.length] = 'winter wolf cub';
  tmp[tmp.length] = 'yeti';
intrinsics['Cold'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'black dragon';
  tmp[tmp.length] = 'Chromatic Dragon';
intrinsics['Disintegration'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'Chromatic Dragon';
  tmp[tmp.length] = 'fire ant';
  tmp[tmp.length] = 'flesh golem';
  tmp[tmp.length] = 'gelatinous cube';
  tmp[tmp.length] = 'gray ooze';
  tmp[tmp.length] = 'hell hound';
  tmp[tmp.length] = 'hell hound pup';
  tmp[tmp.length] = 'Ixoth';
  tmp[tmp.length] = 'Lord Surtur';
  tmp[tmp.length] = 'pyrolisk';
  tmp[tmp.length] = 'red dragon';
  tmp[tmp.length] = 'red mold';
  tmp[tmp.length] = 'red naga';
  tmp[tmp.length] = 'red naga hatchling';
  tmp[tmp.length] = 'salamander';
  tmp[tmp.length] = 'Wizard of Yendor';
intrinsics['Fire'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'stalker';
intrinsics['Invisibility'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'werejackal';
  tmp[tmp.length] = 'wererat';
  tmp[tmp.length] = 'werewolf';
intrinsics['Lycanthropy'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'black naga';
  tmp[tmp.length] = 'black naga hatchling';
  tmp[tmp.length] = 'black pudding';
  tmp[tmp.length] = 'black unicorn';
  tmp[tmp.length] = 'blue jelly';
  tmp[tmp.length] = 'brown mold';
  tmp[tmp.length] = 'brown pudding';
  tmp[tmp.length] = 'cave spider';
  tmp[tmp.length] = 'centipede';
  tmp[tmp.length] = 'chickatrice';
  tmp[tmp.length] = 'Chromatic Dragon';
  tmp[tmp.length] = 'cobra';
  tmp[tmp.length] = 'cockatrice';
  tmp[tmp.length] = 'flesh golem';
  tmp[tmp.length] = 'giant beetle';
  tmp[tmp.length] = 'giant spider';
  tmp[tmp.length] = 'golden naga';
  tmp[tmp.length] = 'golden naga hatchling';
  tmp[tmp.length] = 'gray ooze';
  tmp[tmp.length] = 'gray unicorn';
  tmp[tmp.length] = 'green dragon';
  tmp[tmp.length] = 'gremlin';
  tmp[tmp.length] = 'guardian naga';
  tmp[tmp.length] = 'guardian naga hatchling';
  tmp[tmp.length] = 'homunculus';
  tmp[tmp.length] = 'jellyfish';
  tmp[tmp.length] = 'killer bee';
  tmp[tmp.length] = 'Master Kaen';
  tmp[tmp.length] = 'Medusa';
  tmp[tmp.length] = 'nurse';
  tmp[tmp.length] = 'pit viper';
  tmp[tmp.length] = 'pyrolisk';
  tmp[tmp.length] = 'quasit';
  tmp[tmp.length] = 'queen bee';
  tmp[tmp.length] = 'quivering blob';
  tmp[tmp.length] = 'red mold';
  tmp[tmp.length] = 'red naga';
  tmp[tmp.length] = 'red naga hatchling';
  tmp[tmp.length] = 'scorpion';
  tmp[tmp.length] = 'Scorpius';
  tmp[tmp.length] = 'shrieker';
  tmp[tmp.length] = 'snake';
  tmp[tmp.length] = 'soldier ant';
  tmp[tmp.length] = 'tengu';
  tmp[tmp.length] = 'violet fungus';
  tmp[tmp.length] = 'water moccasin';
  tmp[tmp.length] = 'white unicorn';
  tmp[tmp.length] = 'Wizard of Yendor';
  tmp[tmp.length] = 'xan';
  tmp[tmp.length] = 'yellow mold';
intrinsics['Poison'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'black pudding';
  tmp[tmp.length] = 'blue dragon';
  tmp[tmp.length] = 'brown pudding';
  tmp[tmp.length] = 'Chromatic Dragon';
  tmp[tmp.length] = 'electric eel';
  tmp[tmp.length] = 'flesh golem';
  tmp[tmp.length] = 'gelatinous cube';
  tmp[tmp.length] = 'storm giant';
intrinsics['Shock'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'Chromatic Dragon';
  tmp[tmp.length] = 'elf';
  tmp[tmp.length] = 'elf-lord';
  tmp[tmp.length] = 'Elvenking';
  tmp[tmp.length] = 'flesh golem';
  tmp[tmp.length] = 'gelatinous cube';
  tmp[tmp.length] = 'Green-elf';
  tmp[tmp.length] = 'Grey-elf';
  tmp[tmp.length] = 'homunculus';
  tmp[tmp.length] = 'orange dragon';
  tmp[tmp.length] = 'Woodland-elf';
intrinsics['Sleep'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'fire giant';
intrinsics['Strength'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'floating eye';
  tmp[tmp.length] = 'master mind flayer';
  tmp[tmp.length] = 'mind flayer';
intrinsics['Telepathy'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'tengu';
  tmp[tmp.length] = 'Wizard of Yendor';
intrinsics['Teleport control'] = tmp;

var tmp = new Array();
  tmp[tmp.length] = 'leprechaun';
  tmp[tmp.length] = 'mountain nymph';
  tmp[tmp.length] = 'tengu';
  tmp[tmp.length] = 'water nymph';
  tmp[tmp.length] = 'Wizard of Yendor';
  tmp[tmp.length] = 'wood nymph';
intrinsics['Teleportitis'] = tmp;



var veggy = new Array();

veggy[veggy.length] = 'acid blob';
veggy[veggy.length] = 'blue jelly';
veggy[veggy.length] = 'brown mold';
veggy[veggy.length] = 'brown pudding';
veggy[veggy.length] = 'gelatinous cube';
veggy[veggy.length] = 'gray ooze';
veggy[veggy.length] = 'green mold';
veggy[veggy.length] = 'green slime';
veggy[veggy.length] = 'lichen';
veggy[veggy.length] = 'ochre jelly';
veggy[veggy.length] = 'quivering blob';
veggy[veggy.length] = 'red mold';
veggy[veggy.length] = 'shrieker';
veggy[veggy.length] = 'spotted jelly';
veggy[veggy.length] = 'violet fungus';
veggy[veggy.length] = 'yellow mold';



var vegan = new Array();

vegan[vegan.length] = 'acid blob';
vegan[vegan.length] = 'blue jelly';
vegan[vegan.length] = 'brown mold';
vegan[vegan.length] = 'gelatinous cube';
vegan[vegan.length] = 'green mold';
vegan[vegan.length] = 'lichen';
vegan[vegan.length] = 'ochre jelly';
vegan[vegan.length] = 'quivering blob';
vegan[vegan.length] = 'red mold';
vegan[vegan.length] = 'shrieker';
vegan[vegan.length] = 'spotted jelly';
vegan[vegan.length] = 'violet fungus';
vegan[vegan.length] = 'yellow mold';





//
// Nethack Price Calculation
// (c) 2k5 by HiSPeed
//
// Offline usage and tinkering with the actual code is strictly allowed.
//
// Have fun.
//

// Alchemy Helper

// the user selects the potions he has.
// the helper will show every possible combination between those.
//
// TODO: add a "wanted potion" field eg. try to make !oFullHealing from my potions.
// TODO: round robin mode: show possible alchemy (except for random potions) from my stash of potions until nothing's left ;)

// XXX: problem when resetting the alchemy window lines on click at "Alchemy Helper".. implement a full reset.
// XXX: on deerpark 1.5.0 the less/more button shows up outside the <div> tag's area? o_O .. i ll leave this as a beta browser's problem and hope they ll fix it.. besides  who else uses this beast except for me? :)

var alchemy_potions = new Array();
alchemy_potions[-1] = "other combination (50% evaporates, 25% sickness, 12.5% random potion, 12.5% water)";
alchemy_potions[0] = "none selected";
alchemy_potions[1] = "acid (250z)";
alchemy_potions[2] = "blindness (150z)";
alchemy_potions[3] = "booze (50z)";
alchemy_potions[4] = "confusion (100z)";
alchemy_potions[5] = "enlightenment (200z)";
alchemy_potions[6] = "extra healing (100z)";
alchemy_potions[7] = "full healing (200z)";
alchemy_potions[8] = "fruit juice (50z)";
alchemy_potions[9] = "gain ability (300z)";
alchemy_potions[10] = "gain energy (150z)";
alchemy_potions[11] = "gain level (300z)";
alchemy_potions[12] = "hallucination (100z)";
alchemy_potions[13] = "healing (100z)";
alchemy_potions[14] = "invisibility (150z)";
alchemy_potions[15] = "levitation (200z)";
alchemy_potions[16] = "monster detection (150z)";
alchemy_potions[17] = "object detection (150z)";
alchemy_potions[18] = "oil (250z)";
alchemy_potions[19] = "paralysis (300z)";
alchemy_potions[20] = "polymorph (200z)";
alchemy_potions[21] = "restore ability (100z)";
alchemy_potions[22] = "see invisible (50z)";
alchemy_potions[23] = "sickness (50z)";
alchemy_potions[24] = "sleeping (100z)";
alchemy_potions[25] = "speed (200z)";
alchemy_potions[26] = "water";
alchemy_potions[27] = "amethyst";
alchemy_potions[28] = "unicorn horn";

var alchemy_mixes = new Array();
alchemy_mixes ["3-5"]   = new Array ( new Array ( 4, 1)  );
alchemy_mixes ["3-10"]  = new Array ( new Array (12, 1)  );
alchemy_mixes ["3-11"]  = new Array ( new Array (12, 1)  );
alchemy_mixes ["4-10"]  = new Array ( new Array ( 5, 1/3), new Array (3, 2/3) );
alchemy_mixes ["4-11"]  = new Array ( new Array ( 5, 1/3), new Array (3, 2/3) );
alchemy_mixes ["5-8"]   = new Array ( new Array ( 3, 1)  );
alchemy_mixes ["5-15"]  = new Array ( new Array (11, 2/3), new Array (-1, 1/3) );
alchemy_mixes ["6-10"]  = new Array ( new Array ( 7, 1)  );
alchemy_mixes ["6-11"]  = new Array ( new Array ( 7, 1)  );
alchemy_mixes ["7-10"]  = new Array ( new Array ( 9, 1)  );
alchemy_mixes ["7-11"]  = new Array ( new Array ( 9, 1)   );
alchemy_mixes ["8-5"]   = new Array ( new Array ( 3, 1)  );
alchemy_mixes ["8-10"]  = new Array ( new Array (22, 1)  );
alchemy_mixes ["8-11"]  = new Array ( new Array (22, 1)  );
alchemy_mixes ["8-23"]  = new Array ( new Array (23, 1)  );
alchemy_mixes ["8-25"]  = new Array ( new Array ( 3, 1)  );
alchemy_mixes ["10-13"] = new Array ( new Array ( 6, 1)  );
alchemy_mixes ["11-13"] = new Array ( new Array ( 6, 1)  );
alchemy_mixes ["13-25"] = new Array ( new Array ( 6, 1)  );
alchemy_mixes ["2-28"]  = new Array ( new Array (26, 1)  );
alchemy_mixes ["4-28"]  = new Array ( new Array (26, 1)  );
alchemy_mixes ["12-28"] = new Array ( new Array (26, 1)  );
alchemy_mixes ["23-28"] = new Array ( new Array ( 8, 1)  );
alchemy_mixes ["3-27"]  = new Array ( new Array ( 8, 1)  );



var alchemy_shownpotionlines = 1;



function alchemy_start()
{
  var selection = alchemy_getselection();
  var permutations = alchemy_getuniquepermutation (selection);
  
  var alchemy_text = alchemy_getdirecthits (permutations);
  var el = document.getElementById("resinfo");
  el.innerHTML = alchemy_text;
}


function alchemy_getdirecthits (arr)
{
  var out = "<table cellspacing=0 cellpadding=0 border=0 width='100%' style='padding: 2px 2px 2px 2px;'>\n";
  out +=    "<tr class='resfgcol'><td colspan='5' width='100%' class='resfgcol resheader resheadertop'>Alchemy results:</td></tr>\n";
  
  var myfontsize = ((myxres == "") ? 10 : ((myxres == 1152) ? 8 : 7.1));	/* 1280 = 10, 1152 = 8, 1024 = 7 */
  var hitstyle = " style='font-size: "+myfontsize+"pt; font-style: bold'"; /* on 1024, max ie 6 = 7.8, ff = 7.1 */
  var nonestyle = " style='font-size: "+myfontsize+"pt; font-style: bold'";

  var outnone = "";
  var outhit = "";
 
  for (var perm in arr)
  {
    var doitalic = false;
	 if (! alchemy_mixes[perm]) { doitalic = true; }

	 var curstyle = ((doitalic) ? nonestyle : hitstyle);

    var tmpstr = "";
    tmpstr += "<tr class='resfgcol'>\n";
	 tmpstr += "  <td class='resfgcol' width='25%' id='resrow'"+curstyle+">" +alchemy_potions[ arr[perm][0] ]+ "</td>\n";
	 tmpstr += "  <td class='resfgcol' width='4%' id='resrow'"+curstyle+">+</td>\n";
	 tmpstr += "  <td class='resfgcol' width='22%' id='resrow'"+curstyle+">" +alchemy_potions[ arr[perm][1] ]+ "</td>\n";

	 if (alchemy_mixes[ perm ])						// if result found
	 {
	   tmpstr += "  <td class='resfgcol' width='4%' id='resrow'"+curstyle+">=></td>\n";
	   tmpstr += "  <td class='resfgcol' width='47%'"+curstyle+">";
	   for (var i=0; i < alchemy_mixes[perm].length; i++)
	   {
	     var tmparr = alchemy_mixes[perm][i];
	     tmpstr += (Math.floor(tmparr[1]*10000)/100)+ "% " +alchemy_potions [ Number(tmparr[0]) ] +", ";
	   }
      tmpstr = tmpstr.substring (0, tmpstr.length-2);
	 }
	 else
	 {
	 }
    tmpstr += "</td></tr>\n";

	 if (doitalic)
	 {
	   if (document.alchemyform.showothercombinations.checked == true)
		{
        outnone += tmpstr;
      }
    }
    else
	 {
      outhit += tmpstr;
	 }
  }

  if (outnone != "")
  {
    var tmpfoo = "";
    tmpfoo += "<tr class='resfgcol'>\n";
	 tmpfoo += "  <td class='resfgcol' width='100%' colspan='5' id='resrow'"+nonestyle+"><br/>For the following only &quot;" +alchemy_potions[-1]+ "&quot;:</td>\n";
	 tmpfoo += "</tr>\n";
    outnone = tmpfoo + outnone;
  }
  
  out += outhit;
  out += outnone;

  if ((!outhit) || (outhit == ""))		/* && (! document.alchemyform.showothercombinations.checked)) */
  {
    if (outnone == "") out += "<tr class='resfgcol'>\n  <td class='resfgcol' colspan='5'>None.</td>\n</tr>\n";
  }

  out += "</table>\n";
  return (out);
}


function alchemy_getselection()
{
  var arrSelection = new Array();
  
  for (var i=1; i <= 4; i++)
  {
//	 if ((el) && (el.style.visibility != "hidden"))								// only get visible lines
    if (i <= alchemy_shownpotionlines)
	 {
	   for (var j=(i-1)*4 +1; j < i*4 +1; j++)											// only check for current line
		{
		  var currval = -1;
		  eval ("currval = document.alchemyform.potion"+j+".value;");
		  if ((currval >= 1) && (currval <= alchemy_potions.length))		// only use selected items
		  {
		    arrSelection[arrSelection.length] = currval;
		  }
		}
	 }
  }

//  var str = "";  for (var foo in arrSelection) { str += foo+" => " +alchemy_potions[foo]+ "\n"; } alert (str);
  
  function Numsort (a,b) { return (a-b); }
  
  arrSelection.sort(Numsort);
  return (arrSelection);
}


function alchemy_getuniquepermutation (arr)
{
  var perms = new Array();
  for (var i=0; i < arr.length; i++)
  {
    for (var j=0; j < arr.length; j++)
	 {
	   if (arr[i] != arr[j])
		{
		  var permstr = "";
		  if (arr[i] < arr[j])
		    { permstr = arr[i] +"-"+ arr[j]; }
		  else
		    { permstr = arr[j] +"-"+ arr[i]; }
		  
		  if (! perms[permstr])
		  {
		    perms[ arr[i]+"-"+arr[j] ] = new Array (arr[i], arr[j]);
		  }
		}
	 }
  }

//  var str = "";  for (var foo in perms) { str += foo+"\n"; } alert (str);
  
  return (perms);
}



function alchemy_reset()
{
  for (var i=1; i <= 16; i++)
  {
    eval ("document.alchemyform.potion"+i+".selectedIndex = 0;");
  }
  document.alchemyform.showothercombinations.checked = false;
}


function alchemy_togglepotions(num)
{
  if (alchemy_shownpotionlines == num)
  {
    alchemy_shownpotionlines = num+1;
  }
  else if (alchemy_shownpotionlines > num)
  {
    alchemy_shownpotionlines = num;
  }

  if (alchemy_shownpotionlines < 0) alchemy_shownpotionlines = 1;

  alchemy_updatelines();
}


function alchemy_updatelines()
{
  var imgMore = "./imgs/common/nh_more.gif";
  var imgLess = "./imgs/common/nh_less.gif";
  var imgNone = "./imgs/common/empty.gif";
  
  for (var i=1; i <= 4; i++)
  {
    var rowEl = document.getElementById("alchemyline"+i);
	 if (rowEl)
	 {
	   if (i <= alchemy_shownpotionlines)
		{
		  rowEl.style.visibility = "visible";
		  rowEl.style.display    = "";
		}
		else
		{
		  rowEl.style.visibility = "hidden";
		  rowEl.style.display    = "none";
		}

		var imgEl = document.getElementById("alchemyimg"+i);
	   if (imgEl)
	   {
		  var imgsrc = "";
		  if ((i == alchemy_shownpotionlines) && (i != 4))
		  {
		    imgsrc = imgMore;
		  }
		  else if (i == alchemy_shownpotionlines -1)
		  {
		    imgsrc = imgLess;
		  }
		  else
		  {
		    imgsrc = imgNone;
		  }
		  
		  imgEl.src = imgsrc;
	   }
	 }
  }
/*
  // now for the single potions in each of the (4) lines
//  var dbg = "alchemypotionlines (shown " +alchemy_shownpotionlines+ "):<br>\n";
  for (var j=1; j <= 16; j++)
  {
    var el = document.getElementById ("potion"+j);
    if (el)
	 {
	   if ( (parseInt(j/4)+1) <= alchemy_shownpotionlines)
	   {
//		  dbg += "potion"+j+" visible";
	     el.style.visibility = "visible";
	     el.style.display = "";
	   }
	   else
	   {
//		  dbg += "potion"+j+" hidden";
	     el.style.visibility = "hidden";
	     el.style.display = "none";
	   }
    }
//	 dbg += "<br>\n";
  }
// document.getElementById("clippy_debug").innerHTML = dbg;
*/
  /* to show/hide the form fields in case it gets opened below the window (but wasnt left that way when last closed */
  if (document.getElementById("dhtmltooltip").style.visibility != "hidden") hide_selects();
}






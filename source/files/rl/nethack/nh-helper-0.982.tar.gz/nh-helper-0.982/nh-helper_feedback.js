var prog_name = "nh-helper";
var prog_ver = "0.982";
var orig_url = "http://nethack.no-ip.biz/nh-helper-public/";
var orig_url_part = "http://nethack.no-ip.biz";



char datestring[] = "Mon Dec 17 1984";
